export function instalarNavegacionPremium() {
  let loader = document.querySelector(".page-loader");
  if (!loader) {
    loader = document.createElement("div");
    loader.className = "page-loader";
    loader.textContent = "Cargando Service Office Control...";
    document.body.appendChild(loader);
  }

  document.addEventListener("click", (e) => {
    const link = e.target.closest("a[href]");
    if (!link) return;

    const href = link.getAttribute("href");
    if (!href || href.startsWith("#") || href.startsWith("http")) return;

    loader.classList.add("show");
  });
}