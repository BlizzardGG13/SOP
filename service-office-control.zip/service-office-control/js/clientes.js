import { supabaseClient, requireAuth, setupLogout } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let clientes = [];
let direcciones = [];
let clienteActualDirecciones = null;

const form = document.getElementById("clienteForm");
const tabla = document.getElementById("clientesTabla");
const buscar = document.getElementById("buscarCliente");
const msg = document.getElementById("clienteMsg");
const cancelEdit = document.getElementById("cancelEdit");

async function init() {
  user = await requireAuth();
  if (!user) return;

  perfil = await protegerModulo(user, "clientes");
  if (!perfil) return;
  setupLogout();
  await cargarClientes();

  form.addEventListener("submit", guardarCliente);
  buscar.addEventListener("input", renderClientes);
  cancelEdit.addEventListener("click", limpiarForm);

  document.getElementById("cerrarDirecciones").addEventListener("click", cerrarPanelDirecciones);
  document.getElementById("direccionForm").addEventListener("submit", guardarDireccion);
  document.getElementById("cancelarDireccion").addEventListener("click", limpiarFormDireccion);
}

async function cargarClientes() {
  const { data, error } = await supabaseClient
    .from("clientes")
    .select("*")
    .eq("activo", true)
    .order("creado_en", { ascending: false });

  if (error) {
    msg.textContent = error.message;
    msg.className = "message error";
    return;
  }

  clientes = data || [];
  renderClientes();
}

function renderClientes() {
  const q = buscar.value.toLowerCase().trim();

  const filtrados = clientes.filter(c =>
    `${c.nombre} ${c.telefono || ""} ${c.nit || ""} ${c.correo || ""} ${c.direccion || ""}`
      .toLowerCase()
      .includes(q)
  );

  if (!filtrados.length) {
    tabla.innerHTML = `<tr><td colspan="5">No hay clientes registrados.</td></tr>`;
    return;
  }

  tabla.innerHTML = filtrados.map(c => `
    <tr>
      <td>
        <strong>${c.nombre}</strong>
        ${c.direccion ? `<br><small>${c.direccion}</small>` : ""}
      </td>
      <td>${c.telefono || "-"}</td>
      <td>${c.nit || "CF"}</td>
      <td>${c.correo || "-"}</td>
      <td class="actions">
        <button class="btn btn-small" onclick="editarCliente('${c.id}')">Editar</button>
        <button class="btn btn-small btn-secondary" onclick="abrirDirecciones('${c.id}')">Direcciones</button>
        ${perfil?.rol === "admin" ? `<button class="btn btn-small btn-danger" onclick="borrarCliente('${c.id}')">Borrar</button>` : ""}
      </td>
    </tr>
  `).join("");
}

async function guardarCliente(e) {
  e.preventDefault();

  const id = document.getElementById("clienteId").value;

  const payload = {
    nombre: document.getElementById("nombre").value.trim(),
    telefono: document.getElementById("telefono").value.trim(),
    nit: document.getElementById("nit").value.trim() || "CF",
    correo: document.getElementById("correo").value.trim(),
    direccion: document.getElementById("direccion").value.trim(),
    notas: document.getElementById("notas").value.trim()
  };

  let result;

  if (id) {
    result = await supabaseClient.from("clientes").update(payload).eq("id", id);
  } else {
    result = await supabaseClient.from("clientes").insert([payload]).select().single();
  }

  if (result.error) {
    msg.textContent = result.error.message;
    msg.className = "message error";
    return;
  }

  if (!id && payload.direccion && result.data?.id) {
    await supabaseClient.from("cliente_direcciones").insert([{
      cliente_id: result.data.id,
      etiqueta: "Principal",
      direccion: payload.direccion,
      referencia: "",
      telefono_contacto: payload.telefono,
      es_principal: true
    }]);
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "clientes",
    accion: id ? "actualizar_cliente" : "crear_cliente",
    descripcion: payload.nombre
  });

  msg.textContent = id ? "Cliente actualizado." : "Cliente guardado.";
  msg.className = "message success";
  limpiarForm();
  await cargarClientes();
}

window.editarCliente = function(id) {
  const c = clientes.find(x => x.id === id);
  if (!c) return;

  document.getElementById("formTitle").textContent = "Editar cliente";
  document.getElementById("clienteId").value = c.id;
  document.getElementById("nombre").value = c.nombre || "";
  document.getElementById("telefono").value = c.telefono || "";
  document.getElementById("nit").value = c.nit || "CF";
  document.getElementById("correo").value = c.correo || "";
  document.getElementById("direccion").value = c.direccion || "";
  document.getElementById("notas").value = c.notas || "";
  window.scrollTo({ top: 0, behavior: "smooth" });
};

window.borrarCliente = async function(id) {
  if (perfil?.rol !== "admin") {
    alert("Solo admin puede borrar/desactivar clientes.");
    return;
  }

  const confirmar = confirm("¿Seguro que deseas borrar este cliente?");
  if (!confirmar) return;

  const { error } = await supabaseClient
    .from("clientes")
    .update({ activo: false })
    .eq("id", id);

  if (error) {
    alert(error.message);
    return;
  }

  await cargarClientes();
};

function limpiarForm() {
  form.reset();
  document.getElementById("clienteId").value = "";
  document.getElementById("nit").value = "CF";
  document.getElementById("formTitle").textContent = "Nuevo cliente";
}

window.abrirDirecciones = async function(clienteId) {
  const cliente = clientes.find(c => c.id === clienteId);
  if (!cliente) return;

  clienteActualDirecciones = cliente;
  document.getElementById("direccionesPanel").style.display = "block";
  document.getElementById("direccionesTitulo").textContent = `Direcciones de ${cliente.nombre}`;
  document.getElementById("direccionClienteId").value = cliente.id;
  document.getElementById("direccionTelefono").value = cliente.telefono || "";

  await cargarDirecciones(cliente.id);
  document.getElementById("direccionesPanel").scrollIntoView({ behavior: "smooth" });
};

function cerrarPanelDirecciones() {
  clienteActualDirecciones = null;
  direcciones = [];
  limpiarFormDireccion();
  document.getElementById("direccionesPanel").style.display = "none";
}

async function cargarDirecciones(clienteId) {
  const { data, error } = await supabaseClient
    .from("cliente_direcciones")
    .select("*")
    .eq("cliente_id", clienteId)
    .eq("activo", true)
    .order("es_principal", { ascending: false })
    .order("creado_en", { ascending: true });

  if (error) {
    mostrarMsgDireccion(error.message, "error");
    return;
  }

  direcciones = data || [];
  renderDirecciones();
}

function renderDirecciones() {
  const tbody = document.getElementById("direccionesTabla");

  if (!direcciones.length) {
    tbody.innerHTML = `<tr><td colspan="6">Este cliente todavía no tiene direcciones guardadas.</td></tr>`;
    return;
  }

  tbody.innerHTML = direcciones.map(d => `
    <tr>
      <td>${d.etiqueta || "Dirección"}</td>
      <td>${d.direccion}</td>
      <td>${d.referencia || "-"}</td>
      <td>${d.telefono_contacto || "-"}</td>
      <td>${d.es_principal ? "⭐ Sí" : "No"}</td>
      <td class="actions">
        <button class="btn btn-small" onclick="editarDireccion('${d.id}')">Editar</button>
        ${!d.es_principal ? `<button class="btn btn-small btn-secondary" onclick="marcarPrincipal('${d.id}')">Principal</button>` : ""}
        <button class="btn btn-small btn-danger" onclick="borrarDireccion('${d.id}')">Borrar</button>
      </td>
    </tr>
  `).join("");
}

async function guardarDireccion(e) {
  e.preventDefault();

  const id = document.getElementById("direccionId").value;
  const clienteId = document.getElementById("direccionClienteId").value;
  const esPrincipal = document.getElementById("direccionPrincipal").checked;

  const payload = {
    cliente_id: clienteId,
    etiqueta: document.getElementById("direccionEtiqueta").value.trim() || "Dirección",
    direccion: document.getElementById("direccionTexto").value.trim(),
    referencia: document.getElementById("direccionReferencia").value.trim(),
    telefono_contacto: document.getElementById("direccionTelefono").value.trim(),
    es_principal: esPrincipal,
    actualizado_en: new Date().toISOString()
  };

  if (!payload.direccion) {
    mostrarMsgDireccion("La dirección es obligatoria.", "error");
    return;
  }

  if (esPrincipal) {
    await supabaseClient
      .from("cliente_direcciones")
      .update({ es_principal: false })
      .eq("cliente_id", clienteId);
  }

  let result;

  if (id) {
    result = await supabaseClient.from("cliente_direcciones").update(payload).eq("id", id);
  } else {
    result = await supabaseClient.from("cliente_direcciones").insert([payload]);
  }

  if (result.error) {
    mostrarMsgDireccion(result.error.message, "error");
    return;
  }

  if (esPrincipal) {
    await supabaseClient
      .from("clientes")
      .update({
        direccion: payload.direccion,
        telefono: payload.telefono_contacto || clienteActualDirecciones?.telefono || ""
      })
      .eq("id", clienteId);
  }

  mostrarMsgDireccion(id ? "Dirección actualizada." : "Dirección guardada.", "success");
  limpiarFormDireccion();
  await cargarDirecciones(clienteId);
  await cargarClientes();
}

window.editarDireccion = function(id) {
  const d = direcciones.find(x => x.id === id);
  if (!d) return;

  document.getElementById("direccionId").value = d.id;
  document.getElementById("direccionEtiqueta").value = d.etiqueta || "";
  document.getElementById("direccionTexto").value = d.direccion || "";
  document.getElementById("direccionReferencia").value = d.referencia || "";
  document.getElementById("direccionTelefono").value = d.telefono_contacto || "";
  document.getElementById("direccionPrincipal").checked = !!d.es_principal;
};

window.marcarPrincipal = async function(id) {
  const d = direcciones.find(x => x.id === id);
  if (!d) return;

  await supabaseClient
    .from("cliente_direcciones")
    .update({ es_principal: false })
    .eq("cliente_id", d.cliente_id);

  const { error } = await supabaseClient
    .from("cliente_direcciones")
    .update({ es_principal: true, actualizado_en: new Date().toISOString() })
    .eq("id", id);

  if (error) {
    mostrarMsgDireccion(error.message, "error");
    return;
  }

  await supabaseClient
    .from("clientes")
    .update({
      direccion: d.direccion,
      telefono: d.telefono_contacto || clienteActualDirecciones?.telefono || ""
    })
    .eq("id", d.cliente_id);

  mostrarMsgDireccion("Dirección marcada como principal.", "success");
  await cargarDirecciones(d.cliente_id);
  await cargarClientes();
};

window.borrarDireccion = async function(id) {
  const confirmar = confirm("¿Seguro que deseas borrar esta dirección?");
  if (!confirmar) return;

  const d = direcciones.find(x => x.id === id);

  const { error } = await supabaseClient
    .from("cliente_direcciones")
    .update({ activo: false })
    .eq("id", id);

  if (error) {
    mostrarMsgDireccion(error.message, "error");
    return;
  }

  mostrarMsgDireccion("Dirección eliminada.", "success");
  if (d) await cargarDirecciones(d.cliente_id);
};

function limpiarFormDireccion() {
  const f = document.getElementById("direccionForm");
  f.reset();
  document.getElementById("direccionId").value = "";
  document.getElementById("direccionClienteId").value = clienteActualDirecciones?.id || "";
  document.getElementById("direccionEtiqueta").value = "Principal";
  document.getElementById("direccionTelefono").value = clienteActualDirecciones?.telefono || "";
  document.getElementById("direccionPrincipal").checked = false;
}

function mostrarMsgDireccion(texto, tipo) {
  const el = document.getElementById("direccionMsg");
  el.textContent = texto;
  el.className = `message ${tipo}`;
}

instalarNavegacionPremium();
init();