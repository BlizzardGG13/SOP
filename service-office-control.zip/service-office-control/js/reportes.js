import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;

async function init(){
  user = await requireAuth();
  if(!user) return;

  setupLogout();

  perfil = await protegerModulo(user, "reportes");
  if(!perfil) return;

  await cargarReportes();
}

async function cargarReportes(){
  const hoy = new Date().toISOString().slice(0,10);

  const { data: ventas } = await supabaseClient
    .from("ventas")
    .select("*")
    .gte("creado_en", `${hoy}T00:00:00`)
    .lte("creado_en", `${hoy}T23:59:59`);

  const ventasTotal = (ventas || []).reduce((s,v)=>s+Number(v.total||0),0);
  document.getElementById("ventasHoy").textContent = money(ventasTotal);

  const { data: impresiones } = await supabaseClient
    .from("impresiones")
    .select("*")
    .gte("creado_en", `${hoy}T00:00:00`)
    .lte("creado_en", `${hoy}T23:59:59`);

  const impresionesTotal = (impresiones || []).reduce((s,i)=>s+Number(i.total||0),0);
  document.getElementById("impresionesHoy").textContent = money(impresionesTotal);

  const { data: movs } = await supabaseClient
    .from("movimientos_caja")
    .select("*")
    .gte("creado_en", `${hoy}T00:00:00`)
    .lte("creado_en", `${hoy}T23:59:59`)
    .order("creado_en", { ascending:false })
    .limit(50);

  const ingresos = (movs || []).filter(m=>m.tipo==="ingreso").reduce((s,m)=>s+Number(m.monto||0),0);
  const egresos = (movs || []).filter(m=>m.tipo==="egreso").reduce((s,m)=>s+Number(m.monto||0),0);

  document.getElementById("ingresosCaja").textContent = money(ingresos);
  document.getElementById("egresosCaja").textContent = money(egresos);

  renderMovimientos(movs || []);

  const { data: productos } = await supabaseClient
    .from("inventario_productos")
    .select("*")
    .eq("activo", true);

  const bajos = (productos || []).filter(p => Number(p.stock||0) <= Number(p.stock_minimo||1));
  document.getElementById("productosBajos").textContent = bajos.length;
  renderProductosBajos(bajos);

  const { data: instalaciones } = await supabaseClient
    .from("camaras_instalaciones")
    .select("*")
    .in("estado", ["pendiente_instalar", "en_camino", "instalando"]);

  document.getElementById("instalacionesPendientes").textContent = (instalaciones || []).length;
}

function renderMovimientos(movs){
  const tbody = document.getElementById("movimientosTabla");

  if(!movs.length){
    tbody.innerHTML = `<tr><td colspan="4">Sin movimientos hoy.</td></tr>`;
    return;
  }

  tbody.innerHTML = movs.map(m => `
    <tr>
      <td>${new Date(m.creado_en).toLocaleString("es-GT")}</td>
      <td>${m.tipo}</td>
      <td>${m.categoria}</td>
      <td><strong>${money(m.monto)}</strong></td>
    </tr>
  `).join("");
}

function renderProductosBajos(lista){
  const cont = document.getElementById("productosBajosLista");

  if(!lista.length){
    cont.innerHTML = `<div class="alert-item"><span>✅ Sin productos bajos</span></div>`;
    return;
  }

  cont.innerHTML = lista.slice(0,10).map(p => `
    <div class="alert-item warning">
      <span><strong>${p.nombre}</strong><br><small>Stock: ${p.stock} · mínimo: ${p.stock_minimo}</small></span>
    </div>
  `).join("");
}

instalarNavegacionPremium();
init();
