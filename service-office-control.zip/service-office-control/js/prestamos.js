import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { validarEfectivoDisponible, mostrarErrorCaja } from "./caja-utils.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let cajaActual = null;
let prestamos = [];
let prestamoSeleccionado = null;

const estadoCaja = document.getElementById("estadoCaja");
const prestamoForm = document.getElementById("prestamoForm");
const prestamoMsg = document.getElementById("prestamoMsg");
const buscarPrestamo = document.getElementById("buscarPrestamo");
const prestamosTabla = document.getElementById("prestamosTabla");

const abonoPanel = document.getElementById("abonoPanel");
const abonoForm = document.getElementById("abonoForm");
const abonoMsg = document.getElementById("abonoMsg");
const abonoTitulo = document.getElementById("abonoTitulo");

const historialPanel = document.getElementById("historialPanel");
const historialTitulo = document.getElementById("historialTitulo");
const abonosTabla = document.getElementById("abonosTabla");

async function init() {
  user = await requireAuth();
  if (!user) return;

  perfil = await protegerModulo(user, "prestamos");
  if (!perfil) return;

  setupLogout();

  prestamoForm.addEventListener("submit", guardarPrestamo);
  abonoForm.addEventListener("submit", guardarAbono);
  buscarPrestamo.addEventListener("input", renderPrestamos);
  document.getElementById("cancelarAbono").addEventListener("click", cerrarAbono);
  document.getElementById("cerrarHistorial").addEventListener("click", () => {
    historialPanel.style.display = "none";
  });

  await cargarCaja();
  await cargarPrestamos();
}

async function cargarCaja() {
  const { data } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  cajaActual = data;

  if (cajaActual) {
    estadoCaja.textContent = "Caja abierta";
    estadoCaja.className = "status-pill ok";
  } else {
    estadoCaja.textContent = "Caja cerrada";
    estadoCaja.className = "status-pill danger";
  }
}

async function cargarPrestamos() {
  const { data, error } = await supabaseClient
    .from("prestamos")
    .select("*")
    .order("creado_en", { ascending: false });

  if (error) {
    alert(error.message);
    return;
  }

  prestamos = data || [];
  renderPrestamos();
  calcularResumen();
}

function calcularResumen() {
  const pendientes = prestamos.filter(p => p.estado === "pendiente");
  const pagados = prestamos.filter(p => p.estado === "pagado").length;

  const totalNosDeben = pendientes
    .filter(p => p.tipo === "entregado")
    .reduce((sum, p) => sum + Number(p.saldo || 0), 0);

  const totalDebemos = pendientes
    .filter(p => p.tipo === "recibido")
    .reduce((sum, p) => sum + Number(p.saldo || 0), 0);

  document.getElementById("totalNosDeben").textContent = money(totalNosDeben);
  document.getElementById("totalDebemos").textContent = money(totalDebemos);
  document.getElementById("totalPendientes").textContent = money(totalNosDeben + totalDebemos);
  document.getElementById("totalPagados").textContent = pagados;
}

function renderPrestamos() {
  const q = buscarPrestamo.value.toLowerCase().trim();

  const filtrados = prestamos.filter(p => {
    const texto = `
      ${p.tipo}
      ${p.persona}
      ${p.telefono || ""}
      ${p.descripcion || ""}
      ${p.estado}
    `.toLowerCase();

    return texto.includes(q);
  });

  if (!filtrados.length) {
    prestamosTabla.innerHTML = `<tr><td colspan="7">No hay préstamos registrados.</td></tr>`;
    return;
  }

  prestamosTabla.innerHTML = filtrados.map(p => {
    const tipoTexto = p.tipo === "recibido"
      ? "Recibido / Debemos"
      : "Entregado / Nos deben";

    const estadoClass = p.estado === "pagado" ? "ok" : "danger";

    return `
      <tr>
        <td><span class="badge ${p.tipo === "recibido" ? "ok" : "danger"}">${tipoTexto}</span></td>
        <td>
          <strong>${p.persona}</strong>
          <br><small>${p.descripcion || ""}</small>
        </td>
        <td>${money(p.monto_total)}</td>
        <td><strong>${money(p.saldo)}</strong></td>
        <td><span class="badge ${estadoClass}">${p.estado}</span></td>
        <td>${p.fecha_limite || "-"}</td>
        <td class="actions">
          ${p.estado === "pendiente" ? `<button class="btn btn-small" onclick="abrirAbono('${p.id}')">Abonar</button>` : ""}
          <button class="btn btn-small btn-secondary" onclick="verAbonos('${p.id}')">Historial</button>
        </td>
      </tr>
    `;
  }).join("");
}

async function guardarPrestamo(e) {
  e.preventDefault();

  prestamoMsg.textContent = "";

  await cargarCaja();

  if (!cajaActual) {
    prestamoMsg.textContent = "Primero debes abrir caja para registrar un préstamo.";
    prestamoMsg.className = "message error";
    return;
  }

  const tipo = document.getElementById("tipoPrestamo").value;
  const persona = document.getElementById("persona").value.trim();
  const telefono = document.getElementById("telefono").value.trim();
  const montoTotal = Number(document.getElementById("montoTotal").value || 0);
  const fechaLimite = document.getElementById("fechaLimite").value || null;
  const descripcion = document.getElementById("descripcion").value.trim();

  if (montoTotal <= 0) {
    prestamoMsg.textContent = "El monto debe ser mayor a Q0.00.";
    prestamoMsg.className = "message error";
    return;
  }

  if (tipo === "entregado") {
    const validacion = await validarEfectivoDisponible(cajaActual.id, montoTotal);

    if (!validacion.ok) {
      mostrarErrorCaja(prestamoMsg, validacion);
      return;
    }
  }

  const { data: prestamo, error: prestamoError } = await supabaseClient
    .from("prestamos")
    .insert([{
      caja_id: cajaActual.id,
      usuario_id: user.id,
      tipo,
      persona,
      telefono,
      descripcion,
      monto_total: montoTotal,
      saldo: montoTotal,
      estado: "pendiente",
      fecha_limite: fechaLimite
    }])
    .select()
    .single();

  if (prestamoError) {
    prestamoMsg.textContent = prestamoError.message;
    prestamoMsg.className = "message error";
    return;
  }

  const movimiento = {
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo: tipo === "recibido" ? "ingreso" : "egreso",
    categoria: tipo === "recibido" ? "prestamo_recibido" : "prestamo_entregado",
    persona,
    monto: montoTotal,
    descripcion: tipo === "recibido"
      ? `Préstamo recibido de ${persona}. ${descripcion}`
      : `Préstamo entregado a ${persona}. ${descripcion}`
  };

  const { error: movError } = await supabaseClient
    .from("movimientos_caja")
    .insert([movimiento]);

  if (movError) {
    prestamoMsg.textContent = "El préstamo se guardó, pero no se pudo crear movimiento de caja: " + movError.message;
    prestamoMsg.className = "message error";
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "prestamos",
    accion: "registrar_prestamo",
    descripcion: `${tipo} · ${persona} · ${money(montoTotal)}`
  });

  prestamoMsg.textContent = "Préstamo registrado y movimiento de caja creado.";
  prestamoMsg.className = "message success";
  prestamoForm.reset();

  await cargarPrestamos();
}

window.abrirAbono = function(id) {
  const p = prestamos.find(x => x.id === id);
  if (!p) return;

  prestamoSeleccionado = p;
  document.getElementById("prestamoIdAbono").value = p.id;
  document.getElementById("montoAbono").value = "";
  document.getElementById("notaAbono").value = "";

  const accion = p.tipo === "recibido"
    ? "Pago que hacemos"
    : "Abono que recibimos";

  abonoTitulo.textContent = `${accion}: ${p.persona} · saldo ${money(p.saldo)}`;
  abonoMsg.textContent = "";
  abonoPanel.style.display = "block";
  abonoPanel.scrollIntoView({ behavior: "smooth" });
};

function cerrarAbono() {
  prestamoSeleccionado = null;
  abonoForm.reset();
  abonoPanel.style.display = "none";
}

async function guardarAbono(e) {
  e.preventDefault();

  abonoMsg.textContent = "";

  await cargarCaja();

  if (!cajaActual) {
    abonoMsg.textContent = "Primero debes abrir caja para registrar un abono.";
    abonoMsg.className = "message error";
    return;
  }

  const prestamoId = document.getElementById("prestamoIdAbono").value;
  const prestamo = prestamos.find(p => p.id === prestamoId);

  if (!prestamo) {
    abonoMsg.textContent = "No se encontró el préstamo seleccionado.";
    abonoMsg.className = "message error";
    return;
  }

  const monto = Number(document.getElementById("montoAbono").value || 0);
  const nota = document.getElementById("notaAbono").value.trim();

  if (monto <= 0) {
    abonoMsg.textContent = "El abono debe ser mayor a Q0.00.";
    abonoMsg.className = "message error";
    return;
  }

  if (monto > Number(prestamo.saldo)) {
    abonoMsg.textContent = `El abono no puede ser mayor al saldo pendiente: ${money(prestamo.saldo)}.`;
    abonoMsg.className = "message error";
    return;
  }

  if (prestamo.tipo === "recibido") {
    const validacion = await validarEfectivoDisponible(cajaActual.id, monto);

    if (!validacion.ok) {
      mostrarErrorCaja(abonoMsg, validacion);
      return;
    }
  }

  const nuevoSaldo = Number(prestamo.saldo) - monto;
  const nuevoEstado = nuevoSaldo <= 0 ? "pagado" : "pendiente";

  const { error: abonoError } = await supabaseClient
    .from("abonos_prestamos")
    .insert([{
      prestamo_id: prestamo.id,
      caja_id: cajaActual.id,
      usuario_id: user.id,
      monto,
      nota
    }]);

  if (abonoError) {
    abonoMsg.textContent = abonoError.message;
    abonoMsg.className = "message error";
    return;
  }

  const { error: updateError } = await supabaseClient
    .from("prestamos")
    .update({
      saldo: nuevoSaldo,
      estado: nuevoEstado,
      pagado_en: nuevoEstado === "pagado" ? new Date().toISOString() : null
    })
    .eq("id", prestamo.id);

  if (updateError) {
    abonoMsg.textContent = updateError.message;
    abonoMsg.className = "message error";
    return;
  }

  const movimiento = {
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo: prestamo.tipo === "recibido" ? "egreso" : "ingreso",
    categoria: prestamo.tipo === "recibido" ? "pago_prestamo" : "abono_prestamo_recibido",
    persona: prestamo.persona,
    monto,
    descripcion: prestamo.tipo === "recibido"
      ? `Pago de préstamo a ${prestamo.persona}. ${nota}`
      : `Abono recibido de ${prestamo.persona}. ${nota}`
  };

  const { error: movError } = await supabaseClient
    .from("movimientos_caja")
    .insert([movimiento]);

  if (movError) {
    abonoMsg.textContent = "El abono se guardó, pero no se pudo crear movimiento de caja: " + movError.message;
    abonoMsg.className = "message error";
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "prestamos",
    accion: "registrar_abono_prestamo",
    descripcion: `${prestamo.persona} · ${money(monto)}`
  });

  abonoMsg.textContent = nuevoEstado === "pagado"
    ? "Abono registrado. El préstamo quedó pagado."
    : `Abono registrado. Saldo pendiente: ${money(nuevoSaldo)}.`;
  abonoMsg.className = "message success";

  await cargarPrestamos();

  if (nuevoEstado === "pagado") {
    setTimeout(cerrarAbono, 800);
  }
}

window.verAbonos = async function(id) {
  const p = prestamos.find(x => x.id === id);
  if (!p) return;

  historialTitulo.textContent = `Historial de abonos: ${p.persona}`;

  const { data, error } = await supabaseClient
    .from("abonos_prestamos")
    .select("*")
    .eq("prestamo_id", id)
    .order("creado_en", { ascending: false });

  if (error) {
    alert(error.message);
    return;
  }

  if (!data?.length) {
    abonosTabla.innerHTML = `<tr><td colspan="3">No hay abonos registrados.</td></tr>`;
  } else {
    abonosTabla.innerHTML = data.map(a => `
      <tr>
        <td>${new Date(a.creado_en).toLocaleString("es-GT")}</td>
        <td>${money(a.monto)}</td>
        <td>${a.nota || "-"}</td>
      </tr>
    `).join("");
  }

  historialPanel.style.display = "block";
  historialPanel.scrollIntoView({ behavior: "smooth" });
};

instalarNavegacionPremium();
init();