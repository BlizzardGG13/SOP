import { money, supabaseClient } from "./supabase.js";

export function folio(prefix = "SO") {
  return `${prefix}-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
}

export function documentoCompletoHTML(titulo, html) {
  return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>${titulo}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 32px; color: #111; background:#fff; }
        .doc { max-width: 760px; margin: auto; border: 1px solid #ddd; padding: 28px; border-radius: 14px; }
        h1 { color: #d71920; margin: 0 0 4px; }
        h2 { margin: 0 0 18px; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th, td { border-bottom: 1px solid #e5e7eb; padding: 9px; text-align: left; }
        th { background: #f3f4f6; }
        .right { text-align: right; }
        .muted { color: #666; font-size: 12px; }
        .total { font-size: 20px; font-weight: 800; }
        @media print { body { margin: 0; } .doc { border: none; } .no-print { display: none; } }
      </style>
    </head>
    <body>
      <div class="doc">${html}</div>
    </body>
    </html>
  `;
}

export function abrirPDFDesdeHTML(titulo, html) {
  const win = window.open("", "_blank", "width=900,height=700");
  if (!win) {
    alert("El navegador bloqueó la ventana. Permite popups para guardar PDF.");
    return;
  }

  win.document.write(`
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>${titulo}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 32px; color: #111; }
        .doc { max-width: 760px; margin: auto; border: 1px solid #ddd; padding: 28px; border-radius: 14px; }
        h1 { color: #d71920; margin: 0 0 4px; }
        h2 { margin: 0 0 18px; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th, td { border-bottom: 1px solid #e5e7eb; padding: 9px; text-align: left; }
        th { background: #f3f4f6; }
        .right { text-align: right; }
        .muted { color: #666; font-size: 12px; }
        .total { font-size: 20px; font-weight: 800; }
        @media print { body { margin: 0; } .doc { border: none; } .no-print { display: none; } }
      </style>
    </head>
    <body>
      <button class="no-print" onclick="window.print()" style="padding:12px 18px;margin-bottom:20px;">Imprimir / Guardar PDF</button>
      <div class="doc">${html}</div>
      <script>setTimeout(() => window.print(), 500);</script>
    </body>
    </html>
  `);

  win.document.close();
}

export async function subirComprobanteHTML({ documentoId, tipo, folio, html }) {
  try {
    const safeFolio = String(folio || Date.now()).replace(/[^a-zA-Z0-9-_]/g, "-");
    const path = `${tipo}/${safeFolio}.html`;
    const completo = documentoCompletoHTML(folio || "Comprobante", html);
    const blob = new Blob([completo], { type: "text/html;charset=utf-8" });

    const { error: uploadError } = await supabaseClient.storage
      .from("comprobantes")
      .upload(path, blob, {
        cacheControl: "3600",
        upsert: true
      });

    if (uploadError) throw uploadError;

    const { data } = supabaseClient.storage
      .from("comprobantes")
      .getPublicUrl(path);

    const publicUrl = data.publicUrl;

    await supabaseClient.from("documentos_pdf").insert([{
      documento_id: documentoId,
      storage_path: path,
      public_url: publicUrl,
      tipo
    }]);

    return publicUrl;
  } catch (error) {
    console.warn("No se pudo subir comprobante a Storage:", error);
    return null;
  }
}

export function linkWhatsApp({ folio, total, url }) {
  const texto = `Comprobante ${folio} por ${money(total)} - ${url || ""}`;
  return `https://wa.me/?text=${encodeURIComponent(texto)}`;
}

export function linkCorreo({ folio, total, url }) {
  const subject = encodeURIComponent(`Comprobante ${folio}`);
  const body = encodeURIComponent(`Hola, te comparto el comprobante ${folio} por ${money(total)}.\n\n${url || ""}`);
  return `mailto:?subject=${subject}&body=${body}`;
}

export function htmlComprobanteVenta(doc) {
  return `
    <h1>Service Office</h1>
    <p class="muted">Comprobante de venta</p>
    <h2>${doc.folio}</h2>

    <p><strong>Fecha:</strong> ${new Date(doc.fecha).toLocaleString("es-GT")}</p>
    <p><strong>Cliente:</strong> ${doc.cliente}</p>
    <p><strong>NIT:</strong> ${doc.nit || "CF"}</p>
    <p><strong>Vendedor:</strong> ${doc.vendedor || "-"}</p>

    <table>
      <thead>
        <tr><th>Producto / Servicio</th><th>Cant.</th><th class="right">Precio</th><th class="right">Total</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>${doc.producto}</td>
          <td>${doc.cantidad}</td>
          <td class="right">${money(doc.precio_unitario)}</td>
          <td class="right">${money(doc.total)}</td>
        </tr>
      </tbody>
    </table>

    <p><strong>Método de pago:</strong> ${doc.tipo_pago}</p>
    <p><strong>Total:</strong> <span class="total">${money(doc.total)}</span></p>
    <p><strong>Anticipo/Pagado:</strong> ${money(doc.pagado || 0)}</p>
    <p><strong>Saldo:</strong> ${money(doc.saldo || 0)}</p>
    <p><strong>Garantía:</strong> ${doc.garantia || "Según condiciones del producto o servicio."}</p>
    ${doc.public_url ? `<p><strong>Enlace:</strong> <a href="${doc.public_url}" target="_blank">${doc.public_url}</a></p>` : ""}

    <br><br>
    <p>Firma cliente: ______________________________</p>
  `;
}

export function htmlReciboImpresion(doc) {
  return `
    <h1>Service Office</h1>
    <p class="muted">Recibo de impresión / servicio</p>
    <h2>${doc.folio}</h2>

    <p><strong>Fecha:</strong> ${new Date(doc.fecha || Date.now()).toLocaleString("es-GT")}</p>
    <p><strong>Cliente:</strong> ${doc.cliente}</p>

    <table>
      <thead>
        <tr><th>Servicio</th><th>Cant.</th><th class="right">Precio</th><th class="right">Total</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>${doc.servicio}</td>
          <td>${doc.cantidad}</td>
          <td class="right">${money(doc.precio_unitario)}</td>
          <td class="right">${money(doc.total)}</td>
        </tr>
      </tbody>
    </table>

    <p><strong>Método de pago:</strong> ${doc.metodo_pago}</p>
    <p><strong>Total:</strong> <span class="total">${money(doc.total)}</span></p>
    <p><strong>Notas:</strong> ${doc.notas || "-"}</p>
    `;
}


export function htmlFacturaInterna(doc) {
  const fecha = doc.fecha ? new Date(doc.fecha).toLocaleString("es-GT") : new Date().toLocaleString("es-GT");
  const estado = (doc.estado || "emitida").toUpperCase();

  return `
    <div style="font-family:Arial,sans-serif;max-width:760px;margin:auto;border:1px solid #ddd;padding:28px;border-radius:18px;">
      <div style="display:flex;justify-content:space-between;gap:20px;align-items:flex-start;border-bottom:3px solid #e50914;padding-bottom:18px;">
        <div>
          <h1 style="margin:0;color:#e50914;font-size:28px;">SERVICE OFFICE</h1>
          <p style="margin:4px 0;color:#555;">Soluciones tecnológicas para todos</p>
          <p style="margin:4px 0;color:#555;">Comprobante interno / pre-factura</p>
        </div>
        <div style="text-align:right;">
          <h2 style="margin:0;color:#111;">FACTURA INTERNA</h2>
          <p style="margin:6px 0;"><strong>Folio:</strong> ${doc.folio || "-"}</p>
          <p style="margin:6px 0;"><strong>Estado:</strong> ${estado}</p>
          <p style="margin:6px 0;"><strong>Fecha:</strong> ${fecha}</p>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:22px 0;">
        <div style="background:#f8f8f8;padding:14px;border-radius:12px;">
          <h3 style="margin:0 0 8px;">Cliente</h3>
          <p style="margin:4px 0;"><strong>Nombre:</strong> ${doc.cliente || "Consumidor final"}</p>
          <p style="margin:4px 0;"><strong>NIT:</strong> ${doc.nit || "CF"}</p>
          <p style="margin:4px 0;"><strong>Teléfono:</strong> ${doc.telefono || "-"}</p>
        </div>
        <div style="background:#f8f8f8;padding:14px;border-radius:12px;">
          <h3 style="margin:0 0 8px;">Venta</h3>
          <p style="margin:4px 0;"><strong>Tipo de pago:</strong> ${doc.tipo_pago || "-"}</p>
          <p style="margin:4px 0;"><strong>Vendedor:</strong> ${doc.vendedor || "-"}</p>
          <p style="margin:4px 0;"><strong>Referencia:</strong> ${doc.venta_id || "-"}</p>
        </div>
      </div>

      <table style="width:100%;border-collapse:collapse;margin-top:20px;">
        <thead>
          <tr style="background:#111;color:white;">
            <th style="padding:10px;text-align:left;">Producto/Servicio</th>
            <th style="padding:10px;text-align:right;">Cantidad</th>
            <th style="padding:10px;text-align:right;">Precio</th>
            <th style="padding:10px;text-align:right;">Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding:10px;border-bottom:1px solid #eee;">${doc.producto || "-"}</td>
            <td style="padding:10px;border-bottom:1px solid #eee;text-align:right;">${doc.cantidad || 0}</td>
            <td style="padding:10px;border-bottom:1px solid #eee;text-align:right;">Q ${Number(doc.precio_unitario || 0).toFixed(2)}</td>
            <td style="padding:10px;border-bottom:1px solid #eee;text-align:right;">Q ${Number(doc.total || 0).toFixed(2)}</td>
          </tr>
        </tbody>
      </table>

      <div style="display:flex;justify-content:flex-end;margin-top:22px;">
        <div style="width:280px;background:#f8f8f8;padding:16px;border-radius:12px;">
          <p style="display:flex;justify-content:space-between;margin:6px 0;"><span>Total</span><strong>Q ${Number(doc.total || 0).toFixed(2)}</strong></p>
          <p style="display:flex;justify-content:space-between;margin:6px 0;"><span>Pagado</span><strong>Q ${Number(doc.pagado || 0).toFixed(2)}</strong></p>
          <p style="display:flex;justify-content:space-between;margin:6px 0;"><span>Saldo</span><strong>Q ${Number(doc.saldo || 0).toFixed(2)}</strong></p>
        </div>
      </div>

      <div style="margin-top:24px;padding:14px;border-radius:12px;background:#fff3f3;color:#8a0000;">
        <strong>Nota:</strong> Este documento es un comprobante interno del sistema. Para factura legal FEL/SAT se requiere conexión con proveedor certificado.
      </div>
    </div>
  `;
}


export function htmlReciboAbonoCredito(doc) {
  const fecha = doc.fecha ? new Date(doc.fecha).toLocaleString("es-GT") : new Date().toLocaleString("es-GT");
  const saldoAnterior = Number(doc.saldo_anterior || 0);
  const monto = Number(doc.monto || 0);
  const saldoNuevo = Number(doc.saldo_nuevo || 0);

  return `
    <div style="font-family:Arial,sans-serif;max-width:720px;margin:auto;border:1px solid #e5e7eb;padding:26px;border-radius:18px;">
      <div style="display:flex;justify-content:space-between;gap:18px;border-bottom:3px solid #e50914;padding-bottom:16px;margin-bottom:18px;">
        <div>
          <h1 style="margin:0;color:#e50914;font-size:28px;">SERVICE OFFICE</h1>
          <p style="margin:4px 0;color:#555;">Recibo de abono a crédito</p>
        </div>
        <div style="text-align:right;">
          <h2 style="margin:0;color:#111;">RECIBO</h2>
          <p style="margin:6px 0;"><strong>Folio:</strong> ${doc.folio || "-"}</p>
          <p style="margin:6px 0;"><strong>Fecha:</strong> ${fecha}</p>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
        <div style="background:#f8fafc;border-radius:12px;padding:14px;">
          <p style="margin:4px 0;color:#666;font-size:12px;font-weight:bold;">CLIENTE</p>
          <h3 style="margin:0;color:#111;">${doc.cliente || "Cliente"}</h3>
          <p style="margin:6px 0;color:#555;">NIT: ${doc.nit || "CF"}</p>
        </div>
        <div style="background:#f8fafc;border-radius:12px;padding:14px;">
          <p style="margin:4px 0;color:#666;font-size:12px;font-weight:bold;">REFERENCIA</p>
          <h3 style="margin:0;color:#111;">${doc.venta_folio || doc.credito_id || "-"}</h3>
          <p style="margin:6px 0;color:#555;">Cajero: ${doc.usuario || "-"}</p>
        </div>
      </div>

      <table style="width:100%;border-collapse:collapse;margin-top:12px;">
        <tbody>
          <tr>
            <td style="padding:12px;border-bottom:1px solid #eee;">Saldo anterior</td>
            <td style="padding:12px;border-bottom:1px solid #eee;text-align:right;"><strong>Q ${saldoAnterior.toFixed(2)}</strong></td>
          </tr>
          <tr>
            <td style="padding:12px;border-bottom:1px solid #eee;">Monto abonado</td>
            <td style="padding:12px;border-bottom:1px solid #eee;text-align:right;color:#16a34a;"><strong>Q ${monto.toFixed(2)}</strong></td>
          </tr>
          <tr>
            <td style="padding:12px;border-bottom:1px solid #eee;">Nuevo saldo</td>
            <td style="padding:12px;border-bottom:1px solid #eee;text-align:right;color:#e50914;"><strong>Q ${saldoNuevo.toFixed(2)}</strong></td>
          </tr>
        </tbody>
      </table>

      <div style="margin-top:18px;background:#f8fafc;border-radius:12px;padding:14px;">
        <strong>Nota:</strong> ${doc.nota || "Abono registrado correctamente."}
      </div>

      <p style="margin-top:22px;text-align:center;color:#666;font-size:12px;">
        Documento generado automáticamente por Service Office Control.
      </p>
    </div>
  `;
}
