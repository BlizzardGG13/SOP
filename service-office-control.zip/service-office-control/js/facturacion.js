import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";
import { abrirPDFDesdeHTML, htmlFacturaInterna } from "./documentos-utils.js";

let user = null;
let perfil = null;
let facturas = [];
let config = null;

const tabla = document.getElementById("facturasTabla");
const buscar = document.getElementById("buscarFactura");
const configMsg = document.getElementById("configMsg");

async function init() {
  user = await requireAuth();
  if (!user) return;

  setupLogout();

  perfil = await protegerModulo(user, "facturacion");
  if (!perfil) return;

  document.getElementById("recargarFacturas").addEventListener("click", cargarFacturas);
  document.getElementById("cerrarPreview").addEventListener("click", () => document.getElementById("previewPanel").style.display = "none");
  buscar.addEventListener("input", renderFacturas);
  document.getElementById("configFacturacionForm").addEventListener("submit", guardarConfig);

  await cargarConfig();
  await cargarFacturas();
}

async function cargarConfig() {
  const { data, error } = await supabaseClient
    .from("facturacion_config")
    .select("*")
    .limit(1)
    .maybeSingle();

  if (error) {
    console.warn(error.message);
    return;
  }

  config = data;

  if (config) {
    document.getElementById("autoInterna").checked = !!config.auto_factura_interna;
    document.getElementById("autoFel").checked = !!config.auto_factura_fel;
    document.getElementById("modoDatosCliente").value = config.modo_datos_cliente || "pendiente_si_faltan_datos";
  }
}

async function guardarConfig(e) {
  e.preventDefault();

  const payload = {
    auto_factura_interna: document.getElementById("autoInterna").checked,
    auto_factura_fel: document.getElementById("autoFel").checked,
    modo_datos_cliente: document.getElementById("modoDatosCliente").value,
    actualizado_por: user.id,
    actualizado_en: new Date().toISOString()
  };

  let error = null;

  if (config?.id) {
    ({ error } = await supabaseClient.from("facturacion_config").update(payload).eq("id", config.id));
  } else {
    const r = await supabaseClient.from("facturacion_config").insert([payload]).select().single();
    error = r.error;
    config = r.data;
  }

  if (error) {
    configMsg.textContent = error.message;
    configMsg.className = "message error";
    return;
  }

  configMsg.textContent = "Configuración guardada.";
  configMsg.className = "message success";

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "facturacion",
    accion: "guardar_configuracion",
    descripcion: "Actualización de configuración de facturación automática"
  });

  await cargarConfig();
}

async function cargarFacturas() {
  const { data, error } = await supabaseClient
    .from("facturas")
    .select("*")
    .order("creado_en", { ascending: false })
    .limit(200);

  if (error) {
    tabla.innerHTML = `<tr><td colspan="8">No se pudieron cargar facturas: ${error.message}</td></tr>`;
    return;
  }

  facturas = data || [];
  renderFacturas();
  resumen();
}

function resumen() {
  const emitidas = facturas.filter(f => f.estado !== "anulada");
  const total = emitidas.reduce((s, f) => s + Number(f.total || 0), 0);
  const pendientesFel = facturas.filter(f => f.estado === "pendiente_fel").length;
  const anuladas = facturas.filter(f => f.estado === "anulada").length;

  document.getElementById("totalFacturas").textContent = emitidas.length;
  document.getElementById("montoFacturado").textContent = money(total);
  document.getElementById("pendientesFel").textContent = pendientesFel;
  document.getElementById("facturasAnuladas").textContent = anuladas;
}

function renderFacturas() {
  const q = buscar.value.toLowerCase().trim();

  const filtradas = facturas.filter(f => {
    const texto = `${f.folio || ""} ${f.cliente_nombre || ""} ${f.nit || ""} ${f.estado || ""} ${f.tipo || ""}`.toLowerCase();
    return texto.includes(q);
  });

  if (!filtradas.length) {
    tabla.innerHTML = `<tr><td colspan="8">No hay facturas registradas.</td></tr>`;
    return;
  }

  tabla.innerHTML = filtradas.map(f => `
    <tr>
      <td>${f.creado_en ? new Date(f.creado_en).toLocaleString("es-GT") : "-"}</td>
      <td><strong>${f.folio || "-"}</strong></td>
      <td>${f.cliente_nombre || "Consumidor final"}</td>
      <td>${f.nit || "CF"}</td>
      <td><strong>${money(f.total || 0)}</strong></td>
      <td><span class="badge info">${formatearTipo(f.tipo)}</span></td>
      <td><span class="badge ${estadoClase(f.estado)}">${formatearEstado(f.estado)}</span></td>
      <td>
        <button class="btn btn-small" onclick="verFactura('${f.id}')">Ver</button>
        <button class="btn btn-small btn-secondary" onclick="pdfFactura('${f.id}')">PDF</button>
        ${perfil?.rol === "admin" && f.estado !== "anulada" ? `<button class="btn btn-small btn-danger" onclick="anularFactura('${f.id}')">Anular</button>` : ""}
      </td>
    </tr>
  `).join("");
}

window.verFactura = function(id) {
  const f = facturas.find(x => x.id === id);
  if (!f) return;

  const html = htmlFacturaInterna(f.contenido || f);
  document.getElementById("facturaPreview").innerHTML = html;
  document.getElementById("previewPanel").style.display = "block";
  document.getElementById("previewPanel").scrollIntoView({ behavior: "smooth" });
};

window.pdfFactura = function(id) {
  const f = facturas.find(x => x.id === id);
  if (!f) return;
  abrirPDFDesdeHTML("Factura interna", htmlFacturaInterna(f.contenido || f));
};

window.anularFactura = async function(id) {
  const f = facturas.find(x => x.id === id);
  if (!f || f.estado === "anulada") return;

  if (!confirm("¿Seguro que deseas anular esta factura interna? No anula la venta, solo el documento.")) return;

  const { error } = await supabaseClient
    .from("facturas")
    .update({
      estado: "anulada",
      anulado_en: new Date().toISOString(),
      anulado_por: user.id
    })
    .eq("id", id);

  if (error) {
    alert(error.message);
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "facturacion",
    accion: "anular_factura",
    descripcion: `Factura anulada: ${f.folio}`,
    referencia_id: id
  });

  await cargarFacturas();
};

function estadoClase(estado) {
  if (estado === "emitida") return "ok";
  if (estado === "pendiente_fel") return "warning";
  if (estado === "anulada") return "danger";
  return "info";
}

function formatearEstado(estado) {
  const map = {
    emitida: "Emitida",
    pendiente_fel: "Pendiente FEL",
    anulada: "Anulada",
    error: "Error"
  };
  return map[estado] || estado || "emitida";
}

function formatearTipo(tipo) {
  const map = {
    interna: "Interna",
    fel: "FEL/SAT"
  };
  return map[tipo] || tipo || "Interna";
}

instalarNavegacionPremium();
init();
