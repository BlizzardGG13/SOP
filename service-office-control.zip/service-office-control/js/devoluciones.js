import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { validarEfectivoDisponible } from "./caja-utils.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let clientes = [];
let ventasCliente = [];
let detallesVenta = [];
let productos = [];
let devoluciones = [];
let cajaActual = null;

const $ = (id) => document.getElementById(id);

async function init(){
  user = await requireAuth();
  if(!user) return;

  setupLogout();

  perfil = await protegerModulo(user, "devoluciones");
  if(!perfil) return;

  $("devolucionForm")?.addEventListener("submit", guardarDevolucion);
  $("buscarDevolucion")?.addEventListener("input", renderDevoluciones);

  $("clienteId").onchange = cargarVentasCliente;
  $("ventaId").onchange = cargarProductosDeVenta;
  $("productoId").onchange = seleccionarProductoDevuelto;

  await cargarClientesSeguro();
  await cargarProductos();
  await cargarDevoluciones();

  instalarNavegacionPremium();
}

function nombreCliente(c){
  if(!c) return "Cliente";
  return c.nombre_completo || [c.nombre, c.apellido].filter(Boolean).join(" ") || c.nombre || c.cliente || "Cliente";
}

async function cargarClientesSeguro(){
  const csel = $("clienteId");
  csel.innerHTML = `<option value="">Cargando clientes...</option>`;

  let data = null;
  let error = null;

  // 1) Consulta simple, sin activo y sin order para evitar errores por columnas faltantes.
  const intento1 = await supabaseClient
    .from("clientes")
    .select("*");

  if(intento1.error){
    error = intento1.error;
  }else{
    data = intento1.data || [];
  }

  if(error){
    csel.innerHTML = `<option value="">Error cargando clientes</option>`;
    mostrar("No se pudieron cargar clientes: " + error.message, "error");
    return;
  }

  clientes = (data || []).sort((a,b) => nombreCliente(a).localeCompare(nombreCliente(b)));

  if(!clientes.length){
    csel.innerHTML = `<option value="">No hay clientes registrados</option>`;
    mostrar("No hay clientes registrados o Supabase no los está devolviendo.", "warning");
    return;
  }

  csel.innerHTML = `<option value="">Seleccionar cliente</option>`;
  clientes.forEach(c => {
    const nit = c.nit ? ` · ${c.nit}` : "";
    csel.innerHTML += `<option value="${c.id}">${nombreCliente(c)}${nit}</option>`;
  });
}

async function cargarProductos(){
  const { data, error } = await supabaseClient
    .from("inventario_productos")
    .select("*");

  if(error){
    mostrar("No se pudieron cargar productos: " + error.message, "error");
    productos = [];
    return;
  }

  productos = data || [];
}

async function cargarVentasCliente(){
  const clienteId = $("clienteId").value;
  const ventaSel = $("ventaId");
  const psel = $("productoId");

  ventaSel.innerHTML = `<option value="">Cargando ventas...</option>`;
  psel.innerHTML = `<option value="">Primero selecciona una venta</option>`;
  $("productoNombre").value = "";
  $("monto").value = "";

  ventasCliente = [];
  detallesVenta = [];

  if(!clienteId){
    ventaSel.innerHTML = `<option value="">Seleccionar venta del cliente</option>`;
    return;
  }

  const { data, error } = await supabaseClient
    .from("ventas")
    .select("*")
    .eq("cliente_id", clienteId)
    .order("creado_en", { ascending:false })
    .limit(100);

  if(error){
    ventaSel.innerHTML = `<option value="">Error al cargar ventas</option>`;
    mostrar("No se pudieron cargar ventas del cliente: " + error.message, "error");
    return;
  }

  ventasCliente = data || [];

  if(!ventasCliente.length){
    ventaSel.innerHTML = `<option value="">Este cliente no tiene ventas registradas</option>`;
    return;
  }

  ventaSel.innerHTML = `<option value="">Seleccionar venta del cliente</option>`;
  ventasCliente.forEach(v => {
    const fecha = v.creado_en ? new Date(v.creado_en).toLocaleDateString("es-GT") : "";
    ventaSel.innerHTML += `<option value="${v.id}">${v.folio || String(v.id).slice(0,8)} · ${fecha} · ${money(Number(v.total || 0))}</option>`;
  });
}

async function cargarProductosDeVenta(){
  const ventaId = $("ventaId").value;
  const psel = $("productoId");

  psel.innerHTML = `<option value="">Cargando productos vendidos...</option>`;
  $("productoNombre").value = "";
  $("monto").value = "";
  detallesVenta = [];

  if(!ventaId){
    psel.innerHTML = `<option value="">Primero selecciona una venta</option>`;
    return;
  }

  const { data, error } = await supabaseClient
    .from("detalle_ventas")
    .select("*")
    .eq("venta_id", ventaId);

  if(error){
    psel.innerHTML = `<option value="">Error al cargar productos</option>`;
    mostrar("No se pudieron cargar productos vendidos: " + error.message, "error");
    return;
  }

  detallesVenta = data || [];

  if(!detallesVenta.length){
    psel.innerHTML = `<option value="">Esta venta no tiene detalle de productos</option>`;
    mostrar("Esta venta no tiene detalle_ventas guardado. No se puede devolver producto específico.", "warning");
    return;
  }

  psel.innerHTML = `<option value="">Seleccionar producto vendido</option>`;
  detallesVenta.forEach((d, idx) => {
    const nombre = d.nombre_producto || d.producto_nombre || d.nombre || "Producto";
    const cantidad = Number(d.cantidad || 0);
    const total = Number(d.total || ((Number(d.precio_unitario || 0) * cantidad) - Number(d.descuento || 0)));
    psel.innerHTML += `<option value="${idx}">${nombre} · Cant: ${cantidad} · ${money(total)}</option>`;
  });
}

function seleccionarProductoDevuelto(){
  const idx = $("productoId").value;
  const detalle = detallesVenta[Number(idx)];

  if(!detalle){
    $("productoNombre").value = "";
    $("monto").value = "";
    return;
  }

  const nombre = detalle.nombre_producto || detalle.producto_nombre || detalle.nombre || "Producto";
  const cantidadVendida = Number(detalle.cantidad || 1);
  const totalLinea = Number(detalle.total || ((Number(detalle.precio_unitario || 0) * cantidadVendida) - Number(detalle.descuento || 0)));
  const precioUnitario = cantidadVendida > 0 ? totalLinea / cantidadVendida : Number(detalle.precio_unitario || 0);

  $("productoNombre").value = nombre;
  $("cantidad").value = 1;
  $("cantidad").max = cantidadVendida;
  $("monto").value = precioUnitario.toFixed(2);
}

async function cargarCajaAbierta() {
  const { data, error } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    mostrar(error.message, "error");
    return null;
  }

  cajaActual = data || null;
  return cajaActual;
}

async function guardarDevolucion(e){
  e.preventDefault();

  const ventaId = $("ventaId").value || null;
  const detalleIdx = $("productoId").value;
  const detalleVenta = detallesVenta[Number(detalleIdx)];
  const productoId = detalleVenta?.producto_id || null;
  const producto = productos.find(p => String(p.id) === String(productoId));
  const cantidad = Number($("cantidad").value || 1);
  const cantidadVendida = Number(detalleVenta?.cantidad || 0);
  const reingresar = $("reingresarInventario").checked;

  if(!$("clienteId").value){
    mostrar("Primero selecciona un cliente.", "error");
    return;
  }

  if(!ventaId){
    mostrar("Primero selecciona la venta del cliente.", "error");
    return;
  }

  if(!detalleVenta){
    mostrar("Selecciona un producto que pertenezca a la venta.", "error");
    return;
  }

  if(cantidad <= 0 || cantidad > cantidadVendida){
    mostrar(`Cantidad inválida. Solo puedes devolver hasta ${cantidadVendida}.`, "error");
    return;
  }

  const devolverDinero = $("devolverDinero").checked;
  const montoDevolucion = Number($("monto").value || 0) * cantidad;

  if (devolverDinero) {
    if (montoDevolucion <= 0) {
      mostrar("Para devolver dinero, el monto debe ser mayor a Q0.00.", "error");
      return;
    }

    const caja = await cargarCajaAbierta();

    if (!caja) {
      mostrar("Primero debes tener una caja abierta para devolver dinero.", "error");
      return;
    }

    const validacion = await validarEfectivoDisponible(caja.id, montoDevolucion);

    if (!validacion.ok) {
      mostrar(validacion.mensaje, "error");
      return;
    }
  }

  const payload = {
    cliente_id: $("clienteId").value || null,
    venta_id: ventaId,
    producto_id: productoId,
    usuario_id: user.id,
    producto_nombre: $("productoNombre").value.trim() || detalleVenta?.nombre_producto || detalleVenta?.producto_nombre || producto?.nombre || "Producto",
    cantidad,
    monto: montoDevolucion,
    motivo: $("motivo").value.trim(),
    tipo: $("tipo").value,
    estado: "solicitada",
    reingresar_inventario: reingresar,
    devolver_dinero: devolverDinero
  };

  const { data: devolucionCreada, error } = await supabaseClient
    .from("devoluciones")
    .insert([payload])
    .select()
    .single();

  if(error){
    mostrar(error.message, "error");
    return;
  }

  if (devolverDinero) {
    const { error: movError } = await supabaseClient.from("movimientos_caja").insert([{
      caja_id: cajaActual.id,
      usuario_id: user.id,
      tipo: "egreso",
      categoria: "devolucion",
      persona: nombreCliente(clientes.find(c => c.id === payload.cliente_id)),
      monto: montoDevolucion,
      descripcion: `Devolución de dinero: ${payload.producto_nombre} · ${payload.motivo || "Sin motivo"}`,
      referencia_id: devolucionCreada.id
    }]);

    if (movError) {
      await supabaseClient
        .from("devoluciones")
        .update({
          estado: "error_caja",
          motivo: `${payload.motivo || ""} | ERROR CAJA: ${movError.message}`
        })
        .eq("id", devolucionCreada.id);

      mostrar("La devolución se registró, pero NO se pudo descontar caja: " + movError.message, "error");
      return;
    }
  }

  if(reingresar && producto){
    const stockNuevo = Number(producto.stock || 0) + cantidad;
    await supabaseClient.from("inventario_productos").update({ stock: stockNuevo }).eq("id", producto.id);
    await supabaseClient.from("movimientos_inventario").insert([{
      producto_id: producto.id,
      usuario_id: user.id,
      tipo: "devolucion",
      cantidad,
      stock_anterior: producto.stock,
      stock_nuevo: stockNuevo,
      descripcion: "Reingreso por devolución"
    }]);
  }

  await registrarAuditoria({
    usuario:user,
    perfil,
    modulo:"devoluciones",
    accion:"registrar_devolucion",
    descripcion:`${payload.producto_nombre} · ${money(payload.monto)}`
  });

  mostrar(devolverDinero ? "Devolución registrada y dinero descontado de caja." : "Devolución registrada.", "success");
  e.target.reset();

  $("ventaId").innerHTML = `<option value="">Seleccionar venta del cliente</option>`;
  $("productoId").innerHTML = `<option value="">Primero selecciona una venta</option>`;
  await cargarDevoluciones();
}

async function cargarDevoluciones(){
  const { data, error } = await supabaseClient
    .from("devoluciones")
    .select("*")
    .order("creado_en", { ascending:false });

  if(error){
    mostrar(error.message, "error");
    return;
  }

  devoluciones = data || [];
  renderDevoluciones();
}

function renderDevoluciones(){
  const q = $("buscarDevolucion").value.toLowerCase().trim();
  const lista = devoluciones.filter(d => `${d.producto_nombre||""} ${d.tipo||""} ${d.estado||""}`.toLowerCase().includes(q));
  const tbody = $("devolucionesTabla");

  if(!lista.length){
    tbody.innerHTML = `<tr><td colspan="6">No hay devoluciones registradas.</td></tr>`;
    return;
  }

  tbody.innerHTML = lista.map(d => {
    const cliente = clientes.find(c => String(c.id) === String(d.cliente_id));
    return `
      <tr>
        <td>${nombreCliente(cliente)}</td>
        <td>${d.producto_nombre}</td>
        <td>${d.tipo}</td>
        <td><strong>${money(d.monto)}</strong></td>
        <td>${d.estado}</td>
        <td>-</td>
      </tr>
    `;
  }).join("");
}

function mostrar(txt,tipo){
  const el = $("devolucionMsg");
  if(!el) return;
  el.textContent = txt;
  el.className = `message ${tipo}`;
}

init();
