import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let productos = [];
let imagenSeleccionada = null;
let categoriaActiva = "__todas__";

const form = document.getElementById("productoForm");
const tabla = document.getElementById("productosTabla");
const imagenArchivo = document.getElementById("imagenArchivo");
const imagenPreview = document.getElementById("imagenPreview");
const imagenPreviewText = document.getElementById("imagenPreviewText");
const modal = document.getElementById("productoModal");

const categoriasBase = [
  "Accesorios",
  "Audio",
  "Boletos",
  "Componentes",
  "Consumibles",
  "Electrónicos",
  "Herramientas",
  "Papelería",
  "Impresoras",
  "Cámaras",
  "Redes",
  "Gaming"
];

async function init(){
  user = await requireAuth();
  if(!user) return;
  setupLogout();
  perfil = await protegerModulo(user, "inventario");
  if(!perfil) return;

  form.addEventListener("submit", guardarProducto);
  document.getElementById("buscarProducto").addEventListener("input", renderProductos);
  document.getElementById("ordenProductos").addEventListener("change", renderProductos);
  document.getElementById("limpiarFiltro").addEventListener("click", () => {
    categoriaActiva = "__todas__";
    document.getElementById("buscarProducto").value = "";
    renderCategorias();
    renderProductos();
  });
  document.getElementById("cancelEdit").addEventListener("click", cerrarModal);
  document.getElementById("closeProductModal").addEventListener("click", cerrarModal);
  document.getElementById("openProductModal").addEventListener("click", () => abrirModal());
  document.getElementById("generarSku").addEventListener("click", generarSkuDesdeNombre);
  document.getElementById("movimientoForm").addEventListener("submit", registrarMovimiento);
  document.getElementById("nuevaCategoriaBtn").addEventListener("click", nuevaCategoriaRapida);
  document.getElementById("btnNuevaCategoria").addEventListener("click", nuevaCategoriaRapida);
  modal.addEventListener("click", (e) => { if(e.target === modal) cerrarModal(); });


  aplicarPermisosInventario();
  document.getElementById("quickNuevoProducto")?.addEventListener("click", () => abrirModal());
  document.getElementById("quickStockBajo")?.addEventListener("click", () => {
    document.getElementById("ordenProductos").value = "stock_asc";
    categoriaActiva = "__todas__";
    renderCategorias();
    renderProductos();
  });

  if(imagenArchivo) imagenArchivo.addEventListener("change", mostrarPreviewImagen);
  await cargarProductos();
}

async function cargarProductos(){
  const { data, error } = await supabaseClient
    .from("inventario_productos")
    .select("*")
    .order("creado_en", { ascending:false });

  if(error){
    mostrarMsg(error.message, "error");
    return;
  }

  productos = data || [];
  renderCategoriaOptions();
  renderCategorias();
  renderProductos();
  renderSelectMovimiento();
  renderResumenInventario();
}

function obtenerCategorias(){
  const set = new Set(categoriasBase);
  productos.forEach(p => { if((p.categoria || "").trim()) set.add(p.categoria.trim()); });
  return Array.from(set).sort((a,b) => a.localeCompare(b, "es"));
}

function renderCategoriaOptions(){
  const select = document.getElementById("categoria");
  const current = select.value;
  select.innerHTML = `<option value="">Seleccionar categoría</option>`;
  obtenerCategorias().forEach(c => select.innerHTML += `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`);
  if(current) select.value = current;
}

function renderCategorias(){
  const cont = document.getElementById("categoriasLista");
  const categorias = obtenerCategorias();
  const total = productos.length;
  const esAdmin = perfil?.rol === "admin";

  let html = `<button class="category-item ${categoriaActiva === "__todas__" ? "active" : ""}" data-cat="__todas__"><span>Todas las categorías</span><b>${total}</b></button>`;

  html += categorias.map(cat => {
    const count = productos.filter(p => (p.categoria || "Sin categoría") === cat).length;
    const botonBorrar = esAdmin
      ? `<button class="delete-category-btn" type="button" title="Borrar categoría" data-delete-cat="${escapeHtml(cat)}">×</button>`
      : "";

    return `
      <div class="category-row ${categoriaActiva === cat ? "active" : ""}">
        <button class="category-item ${categoriaActiva === cat ? "active" : ""}" data-cat="${escapeHtml(cat)}">
          <span>${escapeHtml(cat)}</span>
          <b>${count}</b>
        </button>
        ${botonBorrar}
      </div>
    `;
  }).join("");

  cont.innerHTML = html;

  cont.querySelectorAll(".category-item").forEach(btn => {
    btn.addEventListener("click", () => {
      categoriaActiva = btn.dataset.cat;
      renderCategorias();
      renderProductos();
    });
  });

  cont.querySelectorAll(".delete-category-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      borrarCategoria(btn.dataset.deleteCat);
    });
  });
}

function renderProductos(){
  const q = document.getElementById("buscarProducto").value.toLowerCase().trim();
  const orden = document.getElementById("ordenProductos").value;

  let filtrados = productos.filter(p => {
    const matchQ = `${p.nombre} ${p.codigo || ""} ${p.sku || ""} ${p.codigo_barras || ""} ${p.categoria || ""} ${p.proveedor || ""}`.toLowerCase().includes(q);
    const matchCat = categoriaActiva === "__todas__" || (p.categoria || "Sin categoría") === categoriaActiva;
    return matchQ && matchCat;
  });

  filtrados.sort((a,b) => {
    if(orden === "stock_asc") return Number(a.stock||0) - Number(b.stock||0);
    if(orden === "stock_desc") return Number(b.stock||0) - Number(a.stock||0);
    if(orden === "precio_desc") return Number(b.precio_venta||0) - Number(a.precio_venta||0);
    if(orden === "precio_asc") return Number(a.precio_venta||0) - Number(b.precio_venta||0);
    return (a.nombre || "").localeCompare(b.nombre || "", "es");
  });

  document.getElementById("contadorProductos").textContent = `Mostrando ${filtrados.length} de ${productos.length} productos`;
  document.getElementById("contadorChip").textContent = filtrados.length;

  if(!filtrados.length){
    tabla.innerHTML = `<tr><td colspan="7">No hay productos en esta categoría.</td></tr>`;
    return;
  }

  tabla.innerHTML = filtrados.map(p => {
    let estado = "En stock";
    let clase = "ok";
    if(Number(p.stock) <= 0){ estado = "Sin stock"; clase = "danger"; }
    else if(Number(p.stock) <= Number(p.stock_minimo || 1)){ estado = "Bajo stock"; clase = "warning"; }

    const img = p.imagen_url
      ? `<img src="${p.imagen_url}" class="product-thumb" alt="${escapeHtml(p.nombre)}">`
      : `<div class="product-thumb empty">SO</div>`;

    return `
    <tr>
      <td><div class="product-cell">${img}<div><strong>${escapeHtml(p.nombre)}</strong>${p.codigo ? `<br><small>${escapeHtml(p.codigo)}</small>` : ""}</div></div></td>
      <td><span class="category-chip">${escapeHtml(p.categoria || "Sin categoría")}</span></td>
      <td>${money(p.precio_costo || 0)}</td>
      <td>${money(p.precio_venta || 0)}</td>
      <td><strong>${p.stock ?? 0}</strong><br><small>Mín: ${p.stock_minimo ?? 0}</small></td>
      <td><span class="badge ${clase}">${estado}</span></td>
      <td class="actions">${perfil?.rol === "admin" ? `<button class="btn btn-small" onclick="editarProducto('${p.id}')">Editar</button><button class="dots-btn" onclick="desactivarProducto('${p.id}')">⋮</button>` : `<button class="btn btn-small" disabled>Ver</button>`}</td>
    </tr>`;
  }).join("");
}

function renderSelectMovimiento(){
  const select = document.getElementById("movProducto");
  select.innerHTML = `<option value="">Seleccionar producto</option>`;
  productos.forEach(p => select.innerHTML += `<option value="${p.id}">${escapeHtml(p.nombre)} (${p.stock})</option>`);
}

function abrirModal(producto = null){
  limpiarForm(false);
  if(producto) cargarProductoEnFormulario(producto);
  modal.hidden = false;
  document.body.classList.add("modal-open");
}

function cerrarModal(){
  modal.hidden = true;
  document.body.classList.remove("modal-open");
  limpiarForm();
}

function generarSkuDesdeNombre(){
  const nombre = document.getElementById("nombre").value.trim();
  if(!nombre) return;
  const sku = nombre
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toUpperCase().replace(/[^A-Z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 18);
  document.getElementById("codigo").value = sku || `SO-${Date.now()}`;
}


async function borrarCategoria(categoria){
  if(perfil?.rol !== "admin"){
    mostrarMsg("Solo el administrador puede borrar categorías.", "error");
    return;
  }

  const nombre = (categoria || "").trim();
  if(!nombre) return;

  const productosEnCategoria = productos.filter(p => (p.categoria || "Sin categoría") === nombre);

  if(productosEnCategoria.length > 0){
    alert(`No puedes borrar "${nombre}" porque tiene ${productosEnCategoria.length} producto(s). Primero mueve o elimina esos productos.`);
    return;
  }

  if(!confirm(`¿Seguro que deseas borrar la categoría "${nombre}"?`)) return;

  // Las categorías actuales se calculan por productos y lista base.
  // Si está en la lista base, solo se oculta en esta sesión.
  const idx = categoriasBase.findIndex(c => c.toLowerCase() === nombre.toLowerCase());
  if(idx >= 0){
    categoriasBase.splice(idx, 1);
  }

  if(categoriaActiva === nombre){
    categoriaActiva = "__todas__";
  }

  await registrarAuditoria({
    usuario:user,
    perfil,
    modulo:"inventario",
    accion:"borrar_categoria",
    descripcion:nombre
  });

  mostrarMsg(`Categoría "${nombre}" borrada.`, "success");
  renderCategoriaOptions();
  renderCategorias();
  renderProductos();
}

window.borrarCategoria = borrarCategoria;


function nuevaCategoriaRapida(){
  const nombre = prompt("Nombre de la nueva categoría:");
  if(!nombre || !nombre.trim()) return;
  categoriaActiva = nombre.trim();
  const select = document.getElementById("categoria");
  renderCategoriaOptions();
  if(!Array.from(select.options).some(o => o.value === categoriaActiva)){
    select.innerHTML += `<option value="${escapeHtml(categoriaActiva)}">${escapeHtml(categoriaActiva)}</option>`;
  }
  select.value = categoriaActiva;
  renderCategorias();
  abrirModal();
  select.value = categoriaActiva;
}

function mostrarPreviewImagen(){
  const file = imagenArchivo.files[0];
  if(!file){ imagenSeleccionada = null; return; }
  imagenSeleccionada = file;
  const reader = new FileReader();
  reader.onload = e => {
    imagenPreview.src = e.target.result;
    imagenPreview.style.display = "block";
    imagenPreviewText.textContent = file.name;
  };
  reader.readAsDataURL(file);
}

async function subirImagenProducto(nombreProducto){
  if(!imagenSeleccionada) return document.getElementById("imagenUrl")?.value || "";
  const extension = imagenSeleccionada.name.split(".").pop();
  const nombreLimpio = nombreProducto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const ruta = `${Date.now()}-${nombreLimpio}.${extension}`;
  const { error } = await supabaseClient.storage.from("productos-inventario").upload(ruta, imagenSeleccionada, { cacheControl:"3600", upsert:false });
  if(error) throw new Error("Error subiendo imagen: " + error.message);
  const { data } = supabaseClient.storage.from("productos-inventario").getPublicUrl(ruta);
  return data.publicUrl;
}

async function guardarProducto(e){
  e.preventDefault();
  const id = document.getElementById("productoId").value;
  const nombreProducto = document.getElementById("nombre").value.trim();
  if(!nombreProducto){ mostrarMsg("El nombre del producto es obligatorio.", "error"); return; }

  let imagenUrl = "";
  try { imagenUrl = await subirImagenProducto(nombreProducto); }
  catch(error){ mostrarMsg(error.message, "error"); return; }

  const payload = {
    codigo: document.getElementById("codigo").value.trim(),
    nombre: nombreProducto,
    categoria: document.getElementById("categoria").value.trim(),
    proveedor: document.getElementById("proveedor").value.trim(),
    descripcion: document.getElementById("descripcion").value.trim(),
    precio_costo: Number(document.getElementById("precioCosto").value || 0),
    precio_venta: Number(document.getElementById("precioVenta").value || 0),
    stock: Number(document.getElementById("stock").value || 0),
    stock_minimo: Number(document.getElementById("stockMinimo").value || 1),
    imagen_url: imagenUrl,
    activo: document.getElementById("activo").checked,
    actualizado_en: new Date().toISOString()
  };

  let result;
  if(id) result = await supabaseClient.from("inventario_productos").update(payload).eq("id", id);
  else {
    payload.creado_por = user.id;
    result = await supabaseClient.from("inventario_productos").insert([payload]);
  }

  if(result.error){ mostrarMsg(result.error.message, "error"); return; }
  await registrarAuditoria({ usuario:user, perfil, modulo:"inventario", accion:id ? "editar_producto" : "crear_producto", descripcion:payload.nombre });
  mostrarMsg(id ? "Producto actualizado." : "Producto creado.", "success");
  cerrarModal();
  await cargarProductos();
}

window.editarProducto = function(id){
  const p = productos.find(x => x.id === id);
  if(!p) return;
  abrirModal(p);
};

function cargarProductoEnFormulario(p){
  document.getElementById("formTitle").textContent = "Editar producto";
  document.getElementById("productoId").value = p.id;
  document.getElementById("codigo").value = p.codigo || "";
  document.getElementById("nombre").value = p.nombre || "";
  renderCategoriaOptions();
  document.getElementById("categoria").value = p.categoria || "";
  document.getElementById("proveedor").value = p.proveedor || "";
  document.getElementById("descripcion").value = p.descripcion || "";
  document.getElementById("precioCosto").value = p.precio_costo || 0;
  document.getElementById("precioVenta").value = p.precio_venta || 0;
  document.getElementById("stock").value = p.stock || 0;
  document.getElementById("stockMinimo").value = p.stock_minimo || 1;
  document.getElementById("imagenUrl").value = p.imagen_url || "";
  if(p.imagen_url && imagenPreview){ imagenPreview.src = p.imagen_url; imagenPreview.style.display = "block"; imagenPreviewText.textContent = "Imagen actual"; }
  else limpiarPreview();
  document.getElementById("activo").checked = !!p.activo;
}

window.desactivarProducto = async function(id){
  if(perfil?.rol !== "admin"){ alert("Solo admin puede desactivar productos."); return; }
  const producto = productos.find(p => p.id === id);
  if(!producto) return;
  if(!confirm(`¿Desactivar ${producto.nombre}? No se borrará el historial.`)) return;
  const { error } = await supabaseClient.from("inventario_productos").update({ activo:false, actualizado_en:new Date().toISOString() }).eq("id", id);
  if(error){ mostrarMsg(error.message, "error"); return; }
  await registrarAuditoria({ usuario:user, perfil, modulo:"inventario", accion:"desactivar_producto", descripcion:producto.nombre });
  mostrarMsg("Producto desactivado.", "success");
  await cargarProductos();
};

async function registrarMovimiento(e){
  e.preventDefault();
  const productoId = document.getElementById("movProducto").value;
  const tipo = document.getElementById("movTipo").value;
  const cantidad = Number(document.getElementById("movCantidad").value || 0);
  const descripcion = document.getElementById("movDescripcion").value.trim();
  const producto = productos.find(p => p.id === productoId);
  if(!producto){ mostrarMov("Selecciona un producto.", "error"); return; }
  if(cantidad <= 0){ mostrarMov("Cantidad inválida.", "error"); return; }
  const stockAnterior = Number(producto.stock || 0);
  let stockNuevo = stockAnterior;
  if(tipo === "entrada") stockNuevo += cantidad;
  else if(tipo === "salida"){
    if(cantidad > stockAnterior){ mostrarMov(`No puedes sacar ${cantidad}. Stock actual: ${stockAnterior}`, "error"); return; }
    stockNuevo -= cantidad;
  } else stockNuevo = cantidad;

  const { error:updateError } = await supabaseClient.from("inventario_productos").update({ stock: stockNuevo, actualizado_en: new Date().toISOString() }).eq("id", productoId);
  if(updateError){ mostrarMov(updateError.message, "error"); return; }
  await supabaseClient.from("movimientos_inventario").insert([{ producto_id: productoId, usuario_id: user.id, tipo, cantidad, stock_anterior: stockAnterior, stock_nuevo: stockNuevo, descripcion }]);
  await registrarAuditoria({ usuario:user, perfil, modulo:"inventario", accion:`movimiento_${tipo}`, descripcion:`${producto.nombre} · ${cantidad}` });
  mostrarMov("Movimiento registrado.", "success");
  e.target.reset();
  await cargarProductos();
}

function limpiarForm(clearMessage = true){
  form.reset();
  document.getElementById("productoId").value = "";
  document.getElementById("formTitle").textContent = "Agregar nuevo producto";
  document.getElementById("activo").checked = true;
  document.getElementById("imagenUrl").value = "";
  imagenSeleccionada = null;
  limpiarPreview();
  renderCategoriaOptions();
  if(clearMessage) mostrarMsg("", "");
}

function limpiarPreview(){
  if(!imagenPreview) return;
  imagenPreview.removeAttribute("src");
  imagenPreview.style.display = "none";
  imagenPreviewText.textContent = "Sin imagen seleccionada";
}
function mostrarMsg(texto, tipo){ const el = document.getElementById("productoMsg"); el.textContent = texto; el.className = `message ${tipo || ""}`; }
function mostrarMov(texto, tipo){ const el = document.getElementById("movMsg"); el.textContent = texto; el.className = `message ${tipo}`; }
function escapeHtml(str){ return String(str ?? "").replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s])); }


function renderResumenInventario(){
  const total = productos.length;
  const activos = productos.filter(p => p.activo !== false).length;
  const stockTotal = productos.reduce((sum,p) => sum + Number(p.stock || 0), 0);
  const stockBajo = productos.filter(p => Number(p.stock || 0) > 0 && Number(p.stock || 0) <= Number(p.stock_minimo || 1)).length;
  const agotados = productos.filter(p => Number(p.stock || 0) <= 0).length;
  const valor = productos.reduce((sum,p) => sum + (Number(p.stock || 0) * Number(p.precio_costo || p.costo || 0)), 0);

  const setText = (id, value) => { const el = document.getElementById(id); if(el) el.textContent = value; };
  setText("kpiTotalProductos", total);
  setText("kpiActivos", `Activos: ${activos}`);
  setText("kpiStockTotal", stockTotal);
  setText("kpiStockBajo", stockBajo);
  setText("kpiAgotados", agotados);
  setText("kpiValorInventario", money(valor));
  setText("bottomStockBajo", `${stockBajo} productos necesitan reposición`);
  setText("bottomValor", money(valor));
}

function aplicarPermisosInventario(){
  const esAdmin = perfil?.rol === "admin";
  const idsAdmin = ["openProductModal", "nuevaCategoriaBtn", "btnNuevaCategoria", "quickNuevoProducto", "btnComprasInventario"];
  idsAdmin.forEach(id => {
    const el = document.getElementById(id);
    if(el && !esAdmin) el.style.display = "none";
  });

  const sideTools = document.querySelector(".premium-side-tools");
  const movForm = document.getElementById("movimientoForm");
  if(!esAdmin && movForm){
    movForm.closest(".tool-card").style.display = "none";
  }
}


instalarNavegacionPremium();
init();
