import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { validarEfectivoDisponible } from "./caja-utils.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user=null, perfil=null, cajaActual=null, productos=[], compras=[], movimientosCaja=[];
const $ = id => document.getElementById(id);
const estadoCaja=$("estadoCaja"), cajaDisponible=$("cajaDisponible"), comprasDia=$("comprasDia"), unidadesDia=$("unidadesDia"), registrosDia=$("registrosDia"), comprasTabla=$("comprasTabla"), msgCompras=$("msgCompras"), productoSelect=$("productoId"), buscarProducto=$("buscarProducto");

async function init(){
  user=await requireAuth(); if(!user) return;
  perfil=await protegerModulo(user,"compras_inventario"); if(!perfil) return;
  if(perfil.rol!=="admin"){ alert("Solo admin puede acceder a compras de inventario."); location.href="dashboard.html"; return; }
  setupLogout();
  $("modoProducto").addEventListener("change", cambiarModoProducto);
  $("compraForm").addEventListener("submit", guardarCompra);
  $("recargarCompras").addEventListener("click", cargarTodo);
  buscarProducto.addEventListener("input", renderProductosSelect);
  cambiarModoProducto();
  await cargarTodo();
}

function cambiarModoProducto(){
  const modo=$("modoProducto").value;
  $("bloqueExistente").style.display = modo==="existente" ? "block" : "none";
  $("bloqueNuevo").style.display = modo==="nuevo" ? "block" : "none";
  productoSelect.required = modo==="existente";
  $("nuevoNombre").required = modo==="nuevo";
}

async function cargarTodo(){ await cargarCaja(); await cargarProductos(); await cargarCompras(); }

async function cargarCaja(){
  const {data,error}=await supabaseClient.from("cajas").select("*").eq("estado","abierta").order("abierta_en",{ascending:false}).limit(1).maybeSingle();
  if(error){ msg(error.message,"error"); return; }
  cajaActual=data||null;
  if(!cajaActual){ estadoCaja.textContent="Caja cerrada"; estadoCaja.className="status-pill danger"; cajaDisponible.textContent=money(0); movimientosCaja=[]; return; }
  estadoCaja.textContent="Caja abierta"; estadoCaja.className="status-pill ok";
  const {data:movs,error:movError}=await supabaseClient.from("movimientos_caja").select("*").eq("caja_id",cajaActual.id);
  if(movError){ msg(movError.message,"error"); return; }
  movimientosCaja=movs||[];
  cajaDisponible.textContent=money(disponible());
}
function disponible(){
  const apertura=Number(cajaActual?.monto_apertura||0);
  const ingresos=movimientosCaja.filter(m=>m.tipo==="ingreso").reduce((s,m)=>s+Number(m.monto||0),0);
  const egresos=movimientosCaja.filter(m=>m.tipo==="egreso").reduce((s,m)=>s+Number(m.monto||0),0);
  return apertura+ingresos-egresos;
}

async function cargarProductos(){
  const {data,error}=await supabaseClient.from("inventario_productos").select("*").order("nombre",{ascending:true});
  if(error){ msg("Error productos: "+error.message,"error"); return; }
  productos=data||[];
  renderProductosSelect();
}
function renderProductosSelect(){
  const q=buscarProducto.value.toLowerCase().trim();
  const filtrados=productos.filter(p=>`${p.nombre||""} ${p.sku||""} ${p.codigo_barras||""}`.toLowerCase().includes(q));
  productoSelect.innerHTML='<option value="">Selecciona producto...</option>'+filtrados.map(p=>`<option value="${p.id}">${p.nombre||"Producto"} · Stock: ${p.stock??0}${p.sku?" · SKU: "+p.sku:""}</option>`).join("");
}

async function cargarCompras(){
  const {data,error}=await supabaseClient.from("compras_inventario").select("*").order("creado_en",{ascending:false}).limit(100);
  if(error){ msg("Error compras: "+error.message,"error"); comprasTabla.innerHTML='<tr><td colspan="9">No se pudieron cargar compras.</td></tr>'; return; }
  compras=data||[];
  await unirProductos();
  renderCompras();
  resumen();
}
async function unirProductos(){
  const ids=[...new Set(compras.map(c=>c.producto_id).filter(Boolean))];
  if(!ids.length) return;
  const {data}=await supabaseClient.from("inventario_productos").select("id,nombre,sku,stock").in("id",ids);
  const mapa={}; (data||[]).forEach(p=>mapa[p.id]=p);
  compras=compras.map(c=>({...c, producto:mapa[c.producto_id]||null}));
}
function resumen(){
  const hoy=new Date().toISOString().slice(0,10);
  const d=compras.filter(c=>(c.creado_en||"").slice(0,10)===hoy && c.estado!=="anulada");
  comprasDia.textContent=money(d.reduce((s,c)=>s+Number(c.total||0),0));
  unidadesDia.textContent=d.reduce((s,c)=>s+Number(c.cantidad||0),0);
  registrosDia.textContent=d.length;
}
function renderCompras(){
  if(!compras.length){ comprasTabla.innerHTML='<tr><td colspan="9">Todavía no hay compras.</td></tr>'; return; }
  comprasTabla.innerHTML=compras.map(c=>`<tr>
    <td>${c.creado_en?new Date(c.creado_en).toLocaleString("es-GT"):"-"}</td>
    <td><strong>${c.producto?.nombre||c.nombre_producto||"Producto"}</strong><br><small>${c.producto_nuevo?"Producto nuevo":(c.producto?.sku||"")}</small></td>
    <td>${c.proveedor||"-"}</td><td>${c.cantidad}</td><td>${money(c.costo_unitario)}</td><td><strong>${money(c.total)}</strong></td>
    <td>${c.descontado_caja?'<span class="badge ok">Descontado</span>':'<span class="badge warning">No descontado</span>'}</td>
    <td><span class="badge ${c.estado==="anulada"?"danger":"ok"}">${c.estado||"activa"}</span></td>
    <td>${c.estado!=="anulada"?`<button class="btn btn-small btn-danger" onclick="anularCompra('${c.id}')">Anular</button>`:"-"}</td>
  </tr>`).join("");
}


async function subirImagenProductoNuevo() {
  const input = $("nuevoImagen");
  const archivo = input?.files?.[0];

  if (!archivo) {
    return { imagen_url: null, storage_path: null };
  }

  const extension = archivo.name.split(".").pop()?.toLowerCase() || "jpg";
  const nombreSeguro = `${Date.now()}-${crypto.randomUUID()}.${extension}`;
  const storagePath = `productos/${nombreSeguro}`;

  const { error: uploadError } = await supabaseClient.storage
    .from("productos-inventario")
    .upload(storagePath, archivo, {
      cacheControl: "3600",
      upsert: false
    });

  if (uploadError) {
    throw new Error("No se pudo subir la imagen: " + uploadError.message);
  }

  const { data } = supabaseClient.storage
    .from("productos-inventario")
    .getPublicUrl(storagePath);

  return {
    imagen_url: data?.publicUrl || null,
    storage_path: storagePath
  };
}


async function guardarCompra(e){
  e.preventDefault();
  const modo=$("modoProducto").value;
  const proveedor=$("proveedor").value.trim();
  const factura=$("factura").value.trim();
  const cantidad=Number($("cantidad").value||0);
  const costo=Number($("costoUnitario").value||0);
  const notas=$("notas").value.trim();
  const descontar=$("descontarCaja").checked;
  const total=cantidad*costo;
  if(cantidad<=0 || costo<0){ msg("Cantidad o costo inválido.","error"); return; }

  if(descontar){
    await cargarCaja();
    if(!cajaActual){ msg("Primero abre caja para descontar la compra.","error"); return; }
    const validacion=await validarEfectivoDisponible(cajaActual.id,total);
    if(!validacion.ok){ msg(validacion.mensaje,"error"); return; }
  }

  let producto=null, productoNuevo=false, stockAnterior=0;

  if(modo==="existente"){
    producto=productos.find(p=>p.id===productoSelect.value);
    if(!producto){ msg("Selecciona un producto existente.","error"); return; }
    stockAnterior=Number(producto.stock||0);
  }else{
    const nombre=$("nuevoNombre").value.trim();
    const sku=$("nuevoSku").value.trim();
    const categoria=$("nuevoCategoria").value.trim();
    const precioVenta=Number($("nuevoPrecioVenta").value||0);
    const stockMinimo=Number($("nuevoStockMinimo").value||0);
    if(!nombre){ msg("Escribe el nombre del producto nuevo.","error"); return; }
    if(sku && productos.some(p=>String(p.sku||"").toLowerCase()===sku.toLowerCase())){ msg("Ese SKU ya existe. Usa producto existente.","error"); return; }

    let imagenData = { imagen_url: null, storage_path: null };

    try {
      imagenData = await subirImagenProductoNuevo();
    } catch (err) {
      msg(err.message, "error");
      return;
    }

    const payload={
      nombre,
      sku:sku||null,
      categoria:categoria||null,
      precio:precioVenta||0,
      costo:costo||0,
      stock:0,
      stock_minimo:stockMinimo||0,
      imagen_url:imagenData.imagen_url,
      storage_path:imagenData.storage_path,
      activo:true
    };
    const {data:creado,error}=await supabaseClient.from("inventario_productos").insert([payload]).select().single();
    if(error){ msg("No se pudo crear el producto: "+error.message,"error"); return; }
    producto=creado;
    productoNuevo=true;
    stockAnterior=0;
  }

  const stockNuevo=stockAnterior+cantidad;
  const compraPayload={producto_id:producto.id, usuario_id:user.id, caja_id:descontar?cajaActual.id:null, nombre_producto:producto.nombre||"Producto", proveedor, factura, cantidad, costo_unitario:costo, total, stock_anterior:stockAnterior, stock_nuevo:stockNuevo, descontado_caja:descontar, producto_nuevo:productoNuevo, notas, estado:"activa"};

  const {data:compra,error:compraError}=await supabaseClient.from("compras_inventario").insert([compraPayload]).select().single();
  if(compraError){ msg(compraError.message,"error"); return; }

  const {error:stockError}=await supabaseClient.from("inventario_productos").update({stock:stockNuevo, costo:costo||producto.costo||0}).eq("id",producto.id);
  if(stockError){ msg("Compra guardada, pero falló stock: "+stockError.message,"error"); return; }

  if(descontar){
    const {error:movError}=await supabaseClient.from("movimientos_caja").insert([{caja_id:cajaActual.id,usuario_id:user.id,tipo:"egreso",categoria:"compra_inventario",persona:proveedor,monto:total,descripcion:`Compra inventario: ${producto.nombre||"Producto"} x${cantidad}${factura?" · Factura: "+factura:""}`,referencia_id:compra.id}]);
    if(movError){ msg("Stock actualizado, pero falló caja: "+movError.message,"error"); return; }
  }

  await registrarAuditoria({usuario:user,perfil,modulo:"compras_inventario",accion:productoNuevo?"crear_producto_y_compra":"registrar_compra",descripcion:`${producto.nombre||"Producto"} x${cantidad} · ${money(total)}`,referencia_id:compra.id});
  msg(productoNuevo?"Producto creado, compra registrada y stock actualizado.":"Compra registrada y stock actualizado.","success");
  e.target.reset(); cambiarModoProducto(); await cargarTodo();
}

window.anularCompra=async function(id){
  const c=compras.find(x=>x.id===id);
  if(!c || c.estado==="anulada") return;
  if(!confirm("¿Anular compra? Se restará stock y se devolverá caja si aplica.")) return;
  await cargarProductos();
  const p=productos.find(x=>x.id===c.producto_id);
  if(!p){ alert("No se encontró el producto."); return; }
  const stockNuevo=Number(p.stock||0)-Number(c.cantidad||0);
  if(stockNuevo<0){ alert("No se puede anular porque el stock quedaría negativo."); return; }

  const {error:stockError}=await supabaseClient.from("inventario_productos").update({stock:stockNuevo}).eq("id",c.producto_id);
  if(stockError){ alert(stockError.message); return; }

  const {error:updateError}=await supabaseClient.from("compras_inventario").update({estado:"anulada",anulado_en:new Date().toISOString()}).eq("id",id);
  if(updateError){ alert(updateError.message); return; }

  if(c.descontado_caja){
    await cargarCaja();
    if(cajaActual){
      await supabaseClient.from("movimientos_caja").insert([{caja_id:cajaActual.id,usuario_id:user.id,tipo:"ingreso",categoria:"anulacion_compra_inventario",persona:c.proveedor||"",monto:Number(c.total||0),descripcion:`Anulación compra inventario: ${c.nombre_producto||"Producto"}`,referencia_id:c.id}]);
    }
  }

  await registrarAuditoria({usuario:user,perfil,modulo:"compras_inventario",accion:"anular_compra",descripcion:`${c.nombre_producto||"Producto"} x${c.cantidad} · ${money(c.total)}`,referencia_id:c.id});
  await cargarTodo();
};

function msg(t,tipo=""){ msgCompras.textContent=t; msgCompras.className=`message ${tipo}`; }

instalarNavegacionPremium();
init();
