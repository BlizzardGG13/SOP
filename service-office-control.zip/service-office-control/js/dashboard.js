import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;

const $ = (id) => document.getElementById(id);

function fmt(n) {
  try { return typeof money === "function" ? money(Number(n || 0)) : `Q${Number(n || 0).toFixed(2)}`; }
  catch(e) { return `Q${Number(n || 0).toFixed(2)}`; }
}

function inicioMesActual() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1, 0, 0, 0, 0);
}

function inicioDiaActual() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
}

function finMesActual() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
}

function diasDelMes() {
  const fin = finMesActual();
  return fin.getDate();
}

function porcentaje(n) {
  return `${Number(n || 0).toFixed(1)}%`;
}

async function init() {
  user = await requireAuth();
  if (!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "dashboard");
  if (!perfil) return;

  instalarNavegacionPremium();

  const hoy = new Date();
  $("userInfo").textContent = `${perfil.nombre} · ${perfil.rol} · ${hoy.toLocaleDateString("es-GT")}`;
  $("periodoMes").textContent = hoy.toLocaleDateString("es-GT", { month: "long", year: "numeric" });

  await cargarDashboardPremium();
  await cargarAlertas();
}

async function cargarDashboardPremium() {
  const desdeMes = inicioMesActual().toISOString();
  const desdeDia = inicioDiaActual().toISOString();
  const dias = diasDelMes();

  const { data: ventasMes, error: ventasError } = await supabaseClient
    .from("ventas")
    .select("id, folio, cliente_id, tipo_pago, estado, total, ganancia_total, creado_en, clientes(nombre)")
    .gte("creado_en", desdeMes)
    .order("creado_en", { ascending: true });

  if (ventasError) {
    console.warn("Dashboard ventas:", ventasError.message);
  }

  const ventas = ventasMes || [];
  const ventaIds = ventas.map(v => v.id);

  let detalles = [];
  if (ventaIds.length) {
    const { data: dets, error: detError } = await supabaseClient
      .from("detalle_ventas")
      .select("venta_id, producto_id, nombre_producto, producto_nombre, cantidad, precio_unitario, total, costo_unitario, ganancia_total")
      .in("venta_id", ventaIds);

    if (detError) console.warn("Dashboard detalle_ventas:", detError.message);
    detalles = dets || [];
  }

  const productoIds = [...new Set(detalles.map(d => d.producto_id).filter(Boolean))];
  let productosMap = new Map();
  if (productoIds.length) {
    const { data: productos } = await supabaseClient
      .from("inventario_productos")
      .select("id, nombre, categoria, precio_costo, costo, precio_venta, precio")
      .in("id", productoIds);
    productosMap = new Map((productos || []).map(p => [String(p.id), p]));
  }

  // Fallback de ganancia: si ventas.ganancia_total todavía no se está llenando,
  // calculamos desde detalle_ventas con costo_unitario o costo del producto.
  const gananciaPorVenta = new Map();
  detalles.forEach(d => {
    const producto = productosMap.get(String(d.producto_id));
    const cantidad = Number(d.cantidad || 0);
    const vendido = Number(d.total || (Number(d.precio_unitario || 0) * cantidad));
    const costoUnit = Number(d.costo_unitario ?? producto?.precio_costo ?? producto?.costo ?? 0);
    const ganancia = Number(d.ganancia_total ?? (vendido - (costoUnit * cantidad)));
    gananciaPorVenta.set(d.venta_id, Number(gananciaPorVenta.get(d.venta_id) || 0) + ganancia);
  });

  const totalMes = ventas.reduce((s, v) => s + Number(v.total || 0), 0);
  const gananciaMes = ventas.reduce((s, v) => s + Number(v.ganancia_total ?? gananciaPorVenta.get(v.id) ?? 0), 0);
  const ventasHoy = ventas.filter(v => new Date(v.creado_en) >= inicioDiaActual());
  const totalHoy = ventasHoy.reduce((s, v) => s + Number(v.total || 0), 0);
  const gananciaHoy = ventasHoy.reduce((s, v) => s + Number(v.ganancia_total ?? gananciaPorVenta.get(v.id) ?? 0), 0);
  const unidadesMes = detalles.reduce((s, d) => s + Number(d.cantidad || 0), 0);
  const margen = totalMes > 0 ? (gananciaMes / totalMes) * 100 : 0;

  $("ventasMes").textContent = fmt(totalMes);
  $("ventasMesDetalle").textContent = `${ventas.length} venta${ventas.length === 1 ? "" : "s"} registradas`;
  $("gananciaMes").textContent = fmt(gananciaMes);
  $("margenMes").textContent = `Margen ${porcentaje(margen)}`;
  $("ventasDia").textContent = fmt(totalHoy);
  $("gananciaDia").textContent = `Ganancia hoy ${fmt(gananciaHoy)}`;
  $("productosVendidos").textContent = unidadesMes;

  await cargarCajaYCreditos();

  const ventasPorDia = Array.from({ length: dias }, () => 0);
  const gananciaPorDia = Array.from({ length: dias }, () => 0);
  ventas.forEach(v => {
    const dia = new Date(v.creado_en).getDate() - 1;
    ventasPorDia[dia] += Number(v.total || 0);
    gananciaPorDia[dia] += Number(v.ganancia_total ?? gananciaPorVenta.get(v.id) ?? 0);
  });

  $("ventasChartTotal").textContent = fmt(totalMes);
  $("gananciaChartTotal").textContent = fmt(gananciaMes);
  dibujarLinea($("ventasMesChart"), ventasPorDia, "ventas");
  dibujarLinea($("gananciaMesChart"), gananciaPorDia, "ganancia");

  pintarTopProductos(detalles, productosMap);
  pintarCategorias(detalles, productosMap);
  pintarUltimasVentas(ventas.slice().sort((a,b)=>new Date(b.creado_en)-new Date(a.creado_en)), gananciaPorVenta);
}

async function cargarCajaYCreditos() {
  const { data: caja } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending:false })
    .limit(1)
    .maybeSingle();

  let disponible = 0;
  if (caja) {
    const { data: movs } = await supabaseClient
      .from("movimientos_caja")
      .select("tipo,monto")
      .eq("caja_id", caja.id);
    const ingresos = (movs || []).filter(m => m.tipo === "ingreso").reduce((s,m)=>s+Number(m.monto||0),0);
    const egresos = (movs || []).filter(m => m.tipo === "egreso").reduce((s,m)=>s+Number(m.monto||0),0);
    disponible = Number(caja.monto_apertura || 0) + ingresos - egresos;
  }
  $("cajaDisponible").textContent = fmt(disponible);

  const { data: creditos } = await supabaseClient
    .from("creditos")
    .select("saldo,estado")
    .eq("estado", "activo");
  $("creditosPendientes").textContent = fmt((creditos || []).reduce((s,c)=>s+Number(c.saldo||0),0));
}

function pintarTopProductos(detalles, productosMap) {
  const acumulado = new Map();
  detalles.forEach(d => {
    const producto = productosMap.get(String(d.producto_id));
    const nombre = d.nombre_producto || d.producto_nombre || producto?.nombre || "Producto";
    const cantidad = Number(d.cantidad || 0);
    const vendido = Number(d.total || 0);
    const costoUnit = Number(d.costo_unitario ?? producto?.precio_costo ?? producto?.costo ?? 0);
    const costo = costoUnit * cantidad;
    const ganancia = Number(d.ganancia_total ?? (vendido - costo));
    const key = String(d.producto_id || nombre);
    const row = acumulado.get(key) || { nombre, cantidad:0, vendido:0, costo:0, ganancia:0 };
    row.cantidad += cantidad;
    row.vendido += vendido;
    row.costo += costo;
    row.ganancia += ganancia;
    acumulado.set(key, row);
  });

  const rows = [...acumulado.values()].sort((a,b)=>b.cantidad-a.cantidad).slice(0, 7);
  const body = $("topProductosBody");
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="6">Aún no hay ventas este mes.</td></tr>`;
    return;
  }

  body.innerHTML = rows.map(r => {
    const margen = r.vendido > 0 ? (r.ganancia / r.vendido) * 100 : 0;
    return `<tr>
      <td><strong>${r.nombre}</strong></td>
      <td>${r.cantidad}</td>
      <td>${fmt(r.vendido)}</td>
      <td>${fmt(r.costo)}</td>
      <td class="text-ok"><strong>${fmt(r.ganancia)}</strong></td>
      <td>${porcentaje(margen)}</td>
    </tr>`;
  }).join("");
}

function pintarCategorias(detalles, productosMap) {
  const acumulado = new Map();
  detalles.forEach(d => {
    const producto = productosMap.get(String(d.producto_id));
    const cat = producto?.categoria || "Sin categoría";
    acumulado.set(cat, Number(acumulado.get(cat) || 0) + Number(d.total || 0));
  });
  const rows = [...acumulado.entries()].sort((a,b)=>b[1]-a[1]).slice(0, 6);
  const total = rows.reduce((s, r)=>s+r[1], 0);
  $("categoriasTotal").textContent = fmt(total);

  const lista = $("categoriasLista");
  lista.innerHTML = rows.length ? rows.map(([cat, val], idx) => `
    <div class="category-item"><span><i class="dot dot-${idx}"></i>${cat}</span><strong>${fmt(val)}</strong><small>${total ? porcentaje((val/total)*100) : "0%"}</small></div>
  `).join("") : `<div class="category-item">Sin ventas por categoría.</div>`;

  dibujarDona($("categoriasChart"), rows.map(r=>r[1]));
}

function pintarUltimasVentas(ventas, gananciaPorVenta) {
  const body = $("ultimasVentasBody");
  const rows = ventas.slice(0, 8);
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="7">Aún no hay ventas registradas.</td></tr>`;
    return;
  }

  body.innerHTML = rows.map(v => `
    <tr>
      <td><strong>${v.folio || "Venta"}</strong></td>
      <td>${v.clientes?.nombre || "CF"}</td>
      <td>${new Date(v.creado_en).toLocaleString("es-GT")}</td>
      <td>${fmt(v.total)}</td>
      <td class="text-ok"><strong>${fmt(v.ganancia_total ?? gananciaPorVenta.get(v.id) ?? 0)}</strong></td>
      <td>${v.tipo_pago || "contado"}</td>
      <td><span class="badge ok">${v.estado || "pagada"}</span></td>
    </tr>
  `).join("");
}

function dibujarLinea(canvas, data, tipo = "ventas") {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.max(1, rect.width * dpr);
  canvas.height = Math.max(1, canvas.height * dpr);
  ctx.scale(dpr, dpr);

  const w = rect.width;
  const h = canvas.height / dpr;
  const pad = 28;
  const max = Math.max(...data, 1);
  const color = tipo === "ganancia" ? "#22c55e" : "#3b82f6";

  ctx.clearRect(0, 0, w, h);
  ctx.lineWidth = 1;
  ctx.strokeStyle = "rgba(148,163,184,.22)";
  ctx.fillStyle = "rgba(148,163,184,.75)";
  ctx.font = "11px Inter, sans-serif";

  for (let i=0; i<=4; i++) {
    const y = pad + ((h - pad*2) / 4) * i;
    ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(w - pad, y); ctx.stroke();
  }

  const points = data.map((v, i) => {
    const x = pad + (i / Math.max(data.length - 1, 1)) * (w - pad*2);
    const y = h - pad - (Number(v || 0) / max) * (h - pad*2);
    return { x, y, v };
  });

  const gradient = ctx.createLinearGradient(0, pad, 0, h - pad);
  gradient.addColorStop(0, color + "88");
  gradient.addColorStop(1, color + "08");

  ctx.beginPath();
  points.forEach((p, idx) => idx ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.lineTo(w - pad, h - pad);
  ctx.lineTo(pad, h - pad);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  ctx.beginPath();
  points.forEach((p, idx) => idx ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = color;
  points.forEach(p => { if (p.v > 0) { ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI*2); ctx.fill(); } });

  ctx.fillStyle = "rgba(226,232,240,.72)";
  [1, Math.ceil(data.length/2), data.length].forEach(day => {
    const x = pad + ((day-1) / Math.max(data.length-1,1)) * (w - pad*2);
    ctx.fillText(String(day), x-4, h-8);
  });
}

function dibujarDona(canvas, data) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const total = data.reduce((s,n)=>s+Number(n||0),0);
  const colors = ["#2563eb", "#22c55e", "#f59e0b", "#8b5cf6", "#ef4444", "#14b8a6"];
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const cx = canvas.width/2, cy = canvas.height/2, r = 82;
  if (!total) {
    ctx.strokeStyle = "rgba(148,163,184,.25)";
    ctx.lineWidth = 34;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2); ctx.stroke();
    return;
  }
  let start = -Math.PI/2;
  data.forEach((v, i) => {
    const angle = (Number(v||0)/total) * Math.PI * 2;
    ctx.beginPath();
    ctx.strokeStyle = colors[i % colors.length];
    ctx.lineWidth = 34;
    ctx.arc(cx, cy, r, start, start + angle);
    ctx.stroke();
    start += angle;
  });
}

async function cargarAlertas() {
  const cont = $("alertasLista");
  const alertas = [];

  const { data: productos } = await supabaseClient
    .from("inventario_productos")
    .select("nombre,stock,stock_minimo")
    .eq("activo", true)
    .limit(50);

  (productos || []).forEach(p => {
    if (Number(p.stock||0) <= 0) {
      alertas.push({ tipo:"danger", titulo:`${p.nombre} sin stock`, detalle:"Revisar compra o entrada de inventario." });
    } else if (Number(p.stock||0) <= Number(p.stock_minimo||1)) {
      alertas.push({ tipo:"warning", titulo:`${p.nombre} bajo stock`, detalle:`Quedan ${p.stock}.` });
    }
  });

  if (!alertas.length) {
    cont.innerHTML = `<div class="alert-item"><span>✅ Todo tranquilo</span><strong>Sin alertas fuertes</strong></div>`;
    return;
  }

  cont.innerHTML = alertas.slice(0,8).map(a => `
    <div class="alert-item ${a.tipo}">
      <span>${a.titulo}<br><small>${a.detalle}</small></span>
    </div>
  `).join("");
}

window.addEventListener("resize", () => cargarDashboardPremium());
init();
