import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let cajaActual = null;
let pedidos = [];
let detallesPorVenta = {};

const estadoCaja = document.getElementById("estadoCaja");
const pedidosTabla = document.getElementById("pedidosTabla");
const buscarPedido = document.getElementById("buscarPedido");

const detallePanel = document.getElementById("detallePanel");
const detalleTitulo = document.getElementById("detalleTitulo");
const detallePedido = document.getElementById("detallePedido");
const detalleVentaTabla = document.getElementById("detalleVentaTabla");
const historialEstadosTabla = document.getElementById("historialEstadosTabla");

const cobroPanel = document.getElementById("cobroPanel");
const cobroForm = document.getElementById("cobroForm");
const cobroTitulo = document.getElementById("cobroTitulo");
const cobroMsg = document.getElementById("cobroMsg");

async function init() {
  user = await requireAuth();
  if (!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "contra_entrega");
  if (!perfil) return;

  buscarPedido.addEventListener("input", renderPedidos);
  document.getElementById("cerrarDetalle").addEventListener("click", () => detallePanel.style.display = "none");
  document.getElementById("cancelarCobro").addEventListener("click", cerrarCobro);
  cobroForm.addEventListener("submit", registrarCobro);

  await cargarCaja();
  await cargarPedidos();
}

async function cargarCaja() {
  const { data } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  cajaActual = data;
  estadoCaja.textContent = cajaActual ? "Caja abierta" : "Caja cerrada";
  estadoCaja.className = cajaActual ? "status-pill ok" : "status-pill danger";
}

async function cargarPedidos() {
  const { data, error } = await supabaseClient
    .from("pedidos_entrega")
    .select(`*, clientes(nombre,nit,telefono,direccion), ventas(id,total,saldo,estado)`)
    .order("creado_en", { ascending: false });

  if (error) {
    alert("Error cargando pedidos: " + error.message);
    return;
  }

  pedidos = data || [];
  await cargarDetallesVentas();
  renderPedidos();
  calcularResumen();
}

async function cargarDetallesVentas() {
  detallesPorVenta = {};
  const ids = pedidos.map(p => p.venta_id).filter(Boolean);
  if (!ids.length) return;

  const { data, error } = await supabaseClient
    .from("detalle_ventas")
    .select("*")
    .in("venta_id", ids);

  if (error) {
    console.error(error);
    return;
  }

  (data || []).forEach(d => {
    if (!detallesPorVenta[d.venta_id]) detallesPorVenta[d.venta_id] = [];
    detallesPorVenta[d.venta_id].push(d);
  });
}

function calcularResumen() {
  const noCancelados = pedidos.filter(p => p.estado !== "cancelado");
  const saldo = noCancelados.reduce((sum, p) => sum + Number(p.saldo || 0), 0);
  const pendientes = pedidos.filter(p => p.estado === "pendiente").length;
  const proceso = pedidos.filter(p => p.estado === "preparando" || p.estado === "en_camino").length;
  const finalizados = pedidos.filter(p => p.estado === "entregado" || p.estado === "pagado").length;

  document.getElementById("saldoPendiente").textContent = money(saldo);
  document.getElementById("pedidosPendientes").textContent = pendientes;
  document.getElementById("pedidosProceso").textContent = proceso;
  document.getElementById("pedidosFinalizados").textContent = finalizados;
}

function productoResumen(p) {
  const detalles = detallesPorVenta[p.venta_id] || [];
  if (!detalles.length) return "Sin detalle";
  return detalles.map(d => `${d.nombre_producto} x${d.cantidad}`).join(", ");
}

function renderPedidos() {
  const q = buscarPedido.value.toLowerCase().trim();

  const filtrados = pedidos.filter(p => {
    const texto = `${p.clientes?.nombre || ""} ${p.direccion_entrega || ""} ${p.estado || ""} ${p.estado_pago || ""} ${productoResumen(p)}`.toLowerCase();
    return texto.includes(q);
  });

  if (!filtrados.length) {
    pedidosTabla.innerHTML = `<tr><td colspan="7">No hay pedidos contra entrega.</td></tr>`;
    return;
  }

  pedidosTabla.innerHTML = filtrados.map(p => `
    <tr>
      <td><strong>${p.clientes?.nombre || "Cliente"}</strong><br><small>${p.telefono_contacto || p.clientes?.telefono || ""}</small></td>
      <td><strong>${productoResumen(p)}</strong><br><small>${p.notas || ""}</small></td>
      <td>${p.direccion_entrega || "-"}<br><small>${p.referencia || ""}</small></td>
      <td>${money(p.total)}<br><small>Saldo: ${money(p.saldo)}</small></td>
      <td><span class="badge ${estadoClase(p.estado)}">${formatearEstado(p.estado)}</span></td>
      <td><span class="badge ${p.estado_pago === "pagado" ? "ok" : p.estado_pago === "parcial" ? "warning" : "danger"}">${formatearPago(p.estado_pago)}</span></td>
      <td class="actions">
        <button class="btn btn-small" onclick="verDetalle('${p.id}')">Ver detalle</button>
        ${p.saldo > 0 && p.estado !== "cancelado" ? `<button class="btn btn-small" onclick="abrirCobro('${p.id}')">Cobrar</button>` : ""}
        ${botonesEstado(p)}
      </td>
    </tr>
  `).join("");
}

function botonesEstado(p) {
  if (p.estado === "cancelado") return "";
  return `
    ${p.estado !== "preparando" && p.estado !== "entregado" && p.estado !== "pagado" ? `<button class="btn btn-small btn-secondary" onclick="cambiarEstado('${p.id}', 'preparando')">Preparando</button>` : ""}
    ${p.estado !== "en_camino" && p.estado !== "entregado" && p.estado !== "pagado" ? `<button class="btn btn-small btn-secondary" onclick="cambiarEstado('${p.id}', 'en_camino')">En camino</button>` : ""}
    ${p.estado !== "entregado" && p.estado !== "pagado" ? `<button class="btn btn-small btn-secondary" onclick="cambiarEstado('${p.id}', 'entregado')">Entregado</button>` : ""}
    ${p.estado !== "pagado" && p.saldo <= 0 ? `<button class="btn btn-small btn-secondary" onclick="cambiarEstado('${p.id}', 'pagado')">Finalizar</button>` : ""}
    ${p.estado !== "pagado" ? `<button class="btn btn-small btn-danger" onclick="cambiarEstado('${p.id}', 'cancelado')">Cancelar</button>` : ""}
  `;
}

function estadoClase(estado) {
  if (estado === "pagado" || estado === "entregado") return "ok";
  if (estado === "cancelado") return "danger";
  if (estado === "en_camino") return "info";
  return "warning";
}

function formatearEstado(estado) {
  const map = { pendiente:"Pendiente", preparando:"Preparando", en_camino:"En camino", entregado:"Entregado", pagado:"Finalizado", cancelado:"Cancelado" };
  return map[estado] || estado;
}

function formatearPago(estado) {
  const map = { pendiente:"Pago pendiente", parcial:"Pago parcial", pagado:"Pagado" };
  return map[estado] || estado || "pendiente";
}

window.cambiarEstado = async function(id, estado) {
  const pedido = pedidos.find(p => p.id === id);
  if (!pedido) return;

  if (estado === "cancelado" && !confirm("¿Seguro que deseas cancelar este pedido?")) return;
  if (estado === "pagado" && Number(pedido.saldo) > 0) {
    alert("No puedes finalizar como pagado si aún tiene saldo pendiente.");
    return;
  }

  const payload = { estado, actualizado_en: new Date().toISOString() };
  if (estado === "preparando") payload.preparado_en = new Date().toISOString();
  if (estado === "en_camino") payload.en_camino_en = new Date().toISOString();
  if (estado === "entregado") payload.entregado_en = new Date().toISOString();
  if (estado === "pagado") payload.pagado_en = new Date().toISOString();
  if (estado === "cancelado") payload.cancelado_en = new Date().toISOString();

  const { error } = await supabaseClient.from("pedidos_entrega").update(payload).eq("id", id);
  if (error) { alert(error.message); return; }

  await supabaseClient.from("historial_pedidos_entrega").insert([{
    pedido_id: id,
    usuario_id: user.id,
    estado_anterior: pedido.estado,
    estado_nuevo: estado,
    nota: `Cambio manual a ${formatearEstado(estado)}`
  }]);

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "contra_entrega",
    accion: "cambiar_estado_pedido",
    descripcion: `${pedido.clientes?.nombre || "Cliente"}: ${pedido.estado} → ${estado}`
  });

  await cargarPedidos();
};

window.verDetalle = async function(id) {
  const p = pedidos.find(x => x.id === id);
  if (!p) return;

  detalleTitulo.textContent = `Pedido de ${p.clientes?.nombre || "Cliente"}`;

  detallePedido.innerHTML = `
    <div class="status-flow">
      ${["pendiente","preparando","en_camino","entregado","pagado"].map(e => `<span class="${p.estado === e ? "active" : ""}">${formatearEstado(e)}</span>`).join("")}
    </div>
    <div class="summary-lines">
      <div><span>Cliente</span><strong>${p.clientes?.nombre || "-"}</strong></div>
      <div><span>Dirección</span><strong>${p.direccion_entrega || "-"}</strong></div>
      <div><span>Referencia</span><strong>${p.referencia || "-"}</strong></div>
      <div><span>Total</span><strong>${money(p.total)}</strong></div>
      <div><span>Anticipo</span><strong>${money(p.anticipo)}</strong></div>
      <div><span>Saldo</span><strong>${money(p.saldo)}</strong></div>
      <div><span>Estado entrega</span><strong>${formatearEstado(p.estado)}</strong></div>
      <div><span>Estado pago</span><strong>${formatearPago(p.estado_pago)}</strong></div>
      <div><span>Notas</span><strong>${p.notas || "-"}</strong></div>
    </div>
  `;

  await cargarDetalleVenta(p.venta_id);
  await cargarHistorialEstados(p.id);

  detallePanel.style.display = "block";
  detallePanel.scrollIntoView({ behavior: "smooth" });
};

async function cargarDetalleVenta(ventaId) {
  const detalles = detallesPorVenta[ventaId] || [];
  if (!detalles.length) {
    detalleVentaTabla.innerHTML = `<tr><td colspan="4">No hay detalle registrado.</td></tr>`;
    return;
  }

  detalleVentaTabla.innerHTML = detalles.map(d => `
    <tr>
      <td>${d.nombre_producto}</td>
      <td>${d.cantidad}</td>
      <td>${money(d.precio_unitario)}</td>
      <td>${money(d.total)}</td>
    </tr>
  `).join("");
}

async function cargarHistorialEstados(pedidoId) {
  const { data, error } = await supabaseClient
    .from("historial_pedidos_entrega")
    .select("*")
    .eq("pedido_id", pedidoId)
    .order("creado_en", { ascending:false });

  if (error || !data?.length) {
    historialEstadosTabla.innerHTML = `<tr><td colspan="4">Sin historial todavía.</td></tr>`;
    return;
  }

  historialEstadosTabla.innerHTML = data.map(h => `
    <tr>
      <td>${new Date(h.creado_en).toLocaleString("es-GT")}</td>
      <td>${formatearEstado(h.estado_anterior)}</td>
      <td>${formatearEstado(h.estado_nuevo)}</td>
      <td>${h.nota || "-"}</td>
    </tr>
  `).join("");
}

window.abrirCobro = function(id) {
  const p = pedidos.find(x => x.id === id);
  if (!p) return;

  document.getElementById("pedidoIdCobro").value = p.id;
  document.getElementById("montoCobro").value = p.saldo;
  document.getElementById("notaCobro").value = "";
  cobroTitulo.textContent = `Cobrar pedido: ${p.clientes?.nombre || "Cliente"} · saldo ${money(p.saldo)}`;
  cobroMsg.textContent = "";
  cobroMsg.className = "message";
  cobroPanel.style.display = "block";
  cobroPanel.scrollIntoView({ behavior: "smooth" });
};

function cerrarCobro() {
  cobroForm.reset();
  cobroPanel.style.display = "none";
}

async function registrarCobro(e) {
  e.preventDefault();
  await cargarCaja();

  if (!cajaActual) {
    cobroMsg.textContent = "Primero debes abrir caja para registrar el cobro.";
    cobroMsg.className = "message error";
    return;
  }

  const pedidoId = document.getElementById("pedidoIdCobro").value;
  const pedido = pedidos.find(p => p.id === pedidoId);
  if (!pedido) return;

  const monto = Number(document.getElementById("montoCobro").value || 0);
  const nota = document.getElementById("notaCobro").value.trim();

  if (monto <= 0 || monto > Number(pedido.saldo)) {
    cobroMsg.textContent = `El monto debe ser mayor a Q0.00 y no mayor al saldo ${money(pedido.saldo)}.`;
    cobroMsg.className = "message error";
    return;
  }

  const nuevoSaldo = Number(pedido.saldo) - monto;
  const pagado = nuevoSaldo <= 0;
  const estadoPago = pagado ? "pagado" : "parcial";

  if (pedido.credito_id) {
    const { error: abonoError } = await supabaseClient.from("abonos_credito").insert([{
      credito_id: pedido.credito_id,
      caja_id: cajaActual.id,
      usuario_id: user.id,
      monto,
      nota: nota || "Cobro contra entrega"
    }]);
    if (abonoError) { cobroMsg.textContent = abonoError.message; cobroMsg.className = "message error"; return; }

    await supabaseClient.from("creditos").update({
      saldo: nuevoSaldo,
      estado: pagado ? "pagado" : "activo",
      pagado_en: pagado ? new Date().toISOString() : null
    }).eq("id", pedido.credito_id);
  }

  await supabaseClient.from("ventas").update({
    saldo: nuevoSaldo,
    estado: pagado ? "pagada" : "pendiente"
  }).eq("id", pedido.venta_id);

  const { error: movError } = await supabaseClient.from("movimientos_caja").insert([{
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo: "ingreso",
    categoria: "abono_credito",
    persona: pedido.clientes?.nombre || "Cliente",
    monto,
    descripcion: `Cobro contra entrega de ${pedido.clientes?.nombre || "cliente"}. ${nota}`
  }]);
  if (movError) { cobroMsg.textContent = movError.message; cobroMsg.className = "message error"; return; }

  await supabaseClient.from("pedidos_entrega").update({
    saldo: nuevoSaldo,
    estado_pago: estadoPago,
    pagado_en: pagado ? new Date().toISOString() : null,
    actualizado_en: new Date().toISOString()
  }).eq("id", pedido.id);

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "contra_entrega",
    accion: "cobrar_pedido",
    descripcion: `${pedido.clientes?.nombre || "Cliente"} · ${money(monto)}`
  });

  cobroMsg.textContent = pagado ? "Cobro registrado. Pedido pagado." : `Cobro registrado. Saldo pendiente: ${money(nuevoSaldo)}.`;
  cobroMsg.className = "message success";

  await cargarPedidos();
  if (pagado) setTimeout(cerrarCobro, 900);
}

instalarNavegacionPremium();
init();
