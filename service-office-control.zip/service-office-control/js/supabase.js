// CONFIGURACION DEMO:
// Reemplaza SUPABASE_URL y SUPABASE_ANON_KEY con los datos del proyecto Supabase DEMO.
// No uses aquí las credenciales del sistema real si esta versión será pública.

import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";


export const SUPABASE_URL = "";
export const SUPABASE_ANON_KEY = "";

export const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export function money(value) {
  const number = Number(value || 0);
  return number.toLocaleString("es-GT", {
    style: "currency",
    currency: "GTQ",
    minimumFractionDigits: 2
  });
}

export async function getCurrentUser() {
  const { data, error } = await supabaseClient.auth.getUser();
  if (error || !data.user) return null;
  return data.user;
}

export async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = "index.html";
    return null;
  }
  return user;
}

export async function logout() {
  await supabaseClient.auth.signOut();
  window.location.href = "index.html";
}

export function setupLogout() {
  const btn = document.getElementById("logoutBtn");
  if (btn) btn.addEventListener("click", logout);
}
