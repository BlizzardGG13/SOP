import { supabaseClient, requireAuth, setupLogout } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let usuarios = [];

const form = document.getElementById("usuarioForm");
const msg = document.getElementById("usuarioMsg");
const tabla = document.getElementById("usuariosTabla");
const buscar = document.getElementById("buscarUsuario");

async function init() {
  user = await requireAuth();
  if (!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "usuarios");
  if (!perfil) return;

  form.addEventListener("submit", guardarUsuario);
  buscar.addEventListener("input", renderUsuarios);
  document.getElementById("cancelEdit").addEventListener("click", limpiarForm);

  await cargarUsuarios();
}

async function cargarUsuarios() {
  const { data, error } = await supabaseClient
    .from("usuarios_perfiles")
    .select("*")
    .order("creado_en", { ascending: false });

  if (error) {
    msg.textContent = error.message;
    msg.className = "message error";
    return;
  }

  usuarios = data || [];
  renderUsuarios();
}

function renderUsuarios() {
  const q = buscar.value.toLowerCase().trim();

  const filtrados = usuarios.filter(u =>
    `${u.nombre || ""} ${u.correo || ""} ${u.rol || ""}`
      .toLowerCase()
      .includes(q)
  );

  if (!filtrados.length) {
    tabla.innerHTML = `<tr><td colspan="6">No hay usuarios registrados.</td></tr>`;
    return;
  }

  tabla.innerHTML = filtrados.map(u => `
    <tr>
      <td><strong>${u.nombre || "-"}</strong><br><small>${u.id}</small></td>
      <td>${u.correo || "-"}</td>
      <td><span class="badge ${u.rol === "admin" ? "ok" : "warning"}">${u.rol}</span></td>
      <td>${u.activo ? "✅ Sí" : "❌ No"}</td>
      <td>${u.creado_en ? new Date(u.creado_en).toLocaleDateString("es-GT") : "-"}</td>
      <td class="actions">
        <button class="btn btn-small" onclick="editarUsuario('${u.id}')">Editar</button>
        ${u.activo ? `<button class="btn btn-small btn-danger" onclick="cambiarActivo('${u.id}', false)">Desactivar</button>` : `<button class="btn btn-small btn-secondary" onclick="cambiarActivo('${u.id}', true)">Activar</button>`}
      </td>
    </tr>
  `).join("");
}

async function guardarUsuario(e) {
  e.preventDefault();

  const id = document.getElementById("usuarioId").value.trim();

  const payload = {
    id,
    nombre: document.getElementById("nombre").value.trim(),
    correo: document.getElementById("correo").value.trim(),
    rol: document.getElementById("rol").value,
    activo: document.getElementById("activo").checked,
    actualizado_en: new Date().toISOString()
  };

  if (!payload.nombre) {
    msg.textContent = "El nombre es obligatorio.";
    msg.className = "message error";
    return;
  }

  const existe = usuarios.some(u => u.id === id);

  const result = existe
    ? await supabaseClient.from("usuarios_perfiles").update(payload).eq("id", id)
    : await supabaseClient.from("usuarios_perfiles").insert([payload]);

  if (result.error) {
    msg.textContent = result.error.message;
    msg.className = "message error";
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "usuarios",
    accion: existe ? "actualizar_usuario" : "crear_usuario",
    descripcion: `${payload.nombre} (${payload.rol})`,
    referencia_id: id,
    metadata: payload
  });

  msg.textContent = existe ? "Usuario actualizado." : "Usuario registrado.";
  msg.className = "message success";

  limpiarForm();
  await cargarUsuarios();
}

window.editarUsuario = function(id) {
  const u = usuarios.find(x => x.id === id);
  if (!u) return;

  document.getElementById("formTitle").textContent = "Editar usuario";
  document.getElementById("usuarioId").value = u.id;
  document.getElementById("usuarioId").readOnly = true;
  document.getElementById("nombre").value = u.nombre || "";
  document.getElementById("correo").value = u.correo || "";
  document.getElementById("rol").value = u.rol || "cajera";
  document.getElementById("activo").checked = !!u.activo;
  window.scrollTo({ top: 0, behavior: "smooth" });
};

window.cambiarActivo = async function(id, activo) {
  if (id === user.id && !activo) {
    alert("No puedes desactivar tu propio usuario mientras estás dentro.");
    return;
  }

  const u = usuarios.find(x => x.id === id);
  const confirmar = confirm(`${activo ? "¿Activar" : "¿Desactivar"} a ${u?.nombre || "este usuario"}?`);
  if (!confirmar) return;

  const { error } = await supabaseClient
    .from("usuarios_perfiles")
    .update({ activo, actualizado_en: new Date().toISOString() })
    .eq("id", id);

  if (error) {
    alert(error.message);
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "usuarios",
    accion: activo ? "activar_usuario" : "desactivar_usuario",
    descripcion: `${u?.nombre || id}`,
    referencia_id: id
  });

  await cargarUsuarios();
};

function limpiarForm() {
  form.reset();
  document.getElementById("formTitle").textContent = "Registrar perfil de usuario";
  document.getElementById("usuarioId").readOnly = false;
  document.getElementById("activo").checked = true;
}

instalarNavegacionPremium();
init();