import { supabaseClient } from "./supabase.js";

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function cargarMarcaLogin() {
  const defaults = {
    nombreEmpresa: "SERVICE OFFICE",
    eslogan: "Sistema de gestión empresarial",
    logoSrc: "img/service-office-ticket-logo.png",
    mostrarLogo: true
  };

  let config = { ...defaults };
  try {
    const ticketConfig = JSON.parse(localStorage.getItem("soc_ticket_config_v1") || "{}");
    config = { ...config, ...ticketConfig };
  } catch (_) {}

  const nombre = (config.nombreEmpresa || defaults.nombreEmpresa).trim();
  const eslogan = (config.eslogan || defaults.eslogan).trim();
  const logoSrc = (config.logoSrc || "").trim();

  const nameEl = document.getElementById("loginBrandName");
  const sloganEl = document.getElementById("loginBrandSlogan");
  const logoWrap = document.getElementById("loginBrandLogoWrap");
  const logoImg = document.getElementById("loginBrandLogo");
  const icon = document.getElementById("loginBrandIcon");

  if (nameEl) nameEl.innerHTML = escapeHtml(nombre);
  if (sloganEl) sloganEl.textContent = eslogan || defaults.eslogan;

  if (logoWrap && logoImg && logoSrc && config.mostrarLogo !== false) {
    logoImg.src = logoSrc;
    logoImg.alt = `Logo de ${nombre}`;
    logoWrap.hidden = false;
    if (icon) icon.hidden = true;
    logoImg.onerror = () => {
      logoWrap.hidden = true;
      if (icon) icon.hidden = false;
    };
  } else {
    if (logoWrap) logoWrap.hidden = true;
    if (icon) icon.hidden = false;
  }
}


const $ = (id) => document.getElementById(id);

function setMsg(texto, tipo = "error") {
  const msg = $("loginMsg") || document.querySelector(".login-msg") || document.querySelector(".message");
  if (!msg) return;
  msg.textContent = texto || "";
  msg.className = `so-msg ${tipo}`;
}

function setLoading(loading) {
  const btn = $("loginBtn") || document.querySelector("#loginForm button[type='submit']");
  if (!btn) return;

  if (loading) {
    btn.disabled = true;
    btn.dataset.originalText = btn.innerHTML;
    btn.innerHTML = "Ingresando...";
  } else {
    btn.disabled = false;
    btn.innerHTML = btn.dataset.originalText || "Iniciar sesión";
  }
}

function normalizarPerfil(perfil, email = null) {
  if (!perfil) return null;
  return {
    ...perfil,
    email: perfil.email || perfil.correo || email || null,
    rol: perfil.rol || perfil.role || "cajera",
    activo: perfil.activo === true || perfil.activo === "true" || perfil.activo === 1
  };
}

async function buscarPerfilLogin(user) {
  const email = user?.email || null;

  // 1) Tabla principal de permisos del sistema.
  let consulta = await supabaseClient
    .from("usuarios_perfiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  if (consulta.data) return normalizarPerfil(consulta.data, email);

  // 2) Respaldo por correo/email, útil cuando el ID existe pero el email quedó vacío o viceversa.
  if (email) {
    consulta = await supabaseClient
      .from("usuarios_perfiles")
      .select("*")
      .or(`email.eq.${email},correo.eq.${email}`)
      .maybeSingle();

    if (consulta.data) return normalizarPerfil(consulta.data, email);
  }

  // 3) Respaldo para versiones donde el login antiguo usaba perfiles.
  consulta = await supabaseClient
    .from("perfiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  if (consulta.data) return normalizarPerfil(consulta.data, email);

  if (email) {
    consulta = await supabaseClient
      .from("perfiles")
      .select("*")
      .eq("email", email)
      .maybeSingle();

    if (consulta.data) return normalizarPerfil(consulta.data, email);
  }

  console.warn("Perfil no encontrado para login:", { userId: user.id, email });
  return null;
}

async function redirigirSegunRol(user) {
  const perfil = await buscarPerfilLogin(user);
  const rol = perfil?.rol || null;

  if (!perfil || !perfil.activo) {
    await supabaseClient.auth.signOut();
    setLoading(false);
    setMsg("Tu usuario no tiene perfil activo en la demo.", "error");
    console.warn("Perfil inválido o inactivo:", { userId: user.id, email: user.email, perfil });
    return;
  }

  if (rol === "tecnico") {
    window.location.href = "instalaciones.html";
    return;
  }

  window.location.href = "dashboard.html";
}

async function revisarSesionActiva() {
  const { data } = await supabaseClient.auth.getSession();
  const session = data?.session;

  if (session?.user) {
    await redirigirSegunRol(session.user);
  }
}

async function login(e) {
  e.preventDefault();

  const email = ($("email")?.value || $("correo")?.value || "").trim();
  const password = $("password")?.value || $("contrasena")?.value || "";

  if (!email || !password) {
    setMsg("Ingresa correo y contraseña.", "error");
    return;
  }

  setMsg("");
  setLoading(true);

  const { data, error } = await supabaseClient.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    setLoading(false);
    setMsg("Correo o contraseña incorrectos.", "error");
    console.error(error.message);
    return;
  }

  if (!data?.user) {
    setLoading(false);
    setMsg("No se pudo iniciar sesión.", "error");
    return;
  }

  setMsg("Acceso correcto. Redirigiendo...", "success");
  await redirigirSegunRol(data.user);
}

function instalarLogin() {
  const form = $("loginForm") || document.querySelector("form");
  if (!form) {
    console.error("No se encontró formulario de login.");
    return;
  }

  form.addEventListener("submit", login);

  const toggle = $("togglePassword");
  const password = $("password") || $("contrasena");
  toggle?.addEventListener("click", () => {
    if (!password) return;
    password.type = password.type === "password" ? "text" : "password";
  });

  $("forgotPassword")?.addEventListener("click", async (e) => {
    e.preventDefault();
    const email = ($("email")?.value || "").trim();
    if (!email) {
      setMsg("Escribe tu correo para enviar recuperación.", "error");
      return;
    }

    const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + "/index.html"
    });

    if (error) {
      setMsg("No se pudo enviar recuperación.", "error");
      return;
    }

    setMsg("Correo de recuperación enviado.", "success");
  });
}

cargarMarcaLogin();
instalarLogin();
revisarSesionActiva();
