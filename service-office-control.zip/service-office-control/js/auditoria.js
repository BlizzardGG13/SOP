import {
  supabaseClient,
  requireAuth,
  setupLogout
} from "./supabase.js";
import {
  protegerModulo
} from "./authz.js";
import {
  instalarNavegacionPremium
} from "./app-ui.js";

let user = null;
let perfil = null;
let acciones = [];

async function init() {
  user = await requireAuth();
  if (!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "auditoria");
  if (!perfil) return;

  document.getElementById("buscarAuditoria").addEventListener("input", renderAcciones);
  await cargarAcciones();
}

async function cargarAcciones() {
  const {
    data,
    error
  } = await supabaseClient
    .from("auditoria_acciones")
    .select("*")
    .order("creado_en", {
      ascending: false
    })
    .limit(200);

  if (error) {
    alert(error.message);
    return;
  }

  acciones = data || [];
  renderAcciones();
}

function renderAcciones() {
  const q = document.getElementById("buscarAuditoria").value.toLowerCase().trim();

  const filtradas = acciones.filter(a =>
    `${a.usuario_nombre || ""} ${a.usuario_rol || ""} ${a.modulo || ""} ${a.accion || ""} ${a.descripcion || ""}`
    .toLowerCase()
    .includes(q)
  );

  const tbody = document.getElementById("auditoriaTabla");

  if (!filtradas.length) {
    tbody.innerHTML = `<tr><td colspan="6">No hay acciones registradas.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtradas.map(a => `
    <tr>
      <td>${new Date(a.creado_en).toLocaleString("es-GT")}</td>
      <td>${a.usuario_nombre || "-"}</td>
      <td>${a.usuario_rol || "-"}</td>
      <td>${a.modulo}</td>
      <td><strong>${a.accion}</strong></td>
      <td>${a.descripcion || "-"}</td>
    </tr>
  `).join("");
}

instalarNavegacionPremium();
init();