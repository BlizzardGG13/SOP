const STORAGE_KEY = 'soc_ticket_config_v1';

export const DEFAULT_TICKET_CONFIG = {
  nombreEmpresa: 'SERVICE OFFICE',
  eslogan: 'SOLUCIONES TECNOLÓGICAS PARA TODOS',
  telefono: '4202-0545',
  direccion: 'Esquipulas, Guatemala',
  sitioWeb: 'ServiceOfficeEsquipulas.com',
  mensajeFinal: '¡Gracias por su compra!',
  mensajeSecundario: 'Visítanos nuevamente ☺',
  logoSrc: 'img/service-office-ticket-logo.png',
  mostrarLogo: true,
  mostrarEslogan: true,
  mostrarTelefono: true,
  mostrarDireccion: true,
  mostrarSitioWeb: true,
  mostrarCajero: true,
  mostrarCliente: true,
  mostrarNit: true,
  mostrarSku: true,
  mostrarMensajeFinal: true,
  estilo: 'premium'
};

export function getTicketConfig() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return { ...DEFAULT_TICKET_CONFIG, ...saved };
  } catch (e) {
    return { ...DEFAULT_TICKET_CONFIG };
  }
}

export function saveTicketConfig(config) {
  const next = { ...DEFAULT_TICKET_CONFIG, ...(config || {}) };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent('soc-ticket-config-updated', { detail: next }));
  return next;
}

export function resetTicketConfig() {
  localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new CustomEvent('soc-ticket-config-updated', { detail: DEFAULT_TICKET_CONFIG }));
  return { ...DEFAULT_TICKET_CONFIG };
}

export function escapeTicket(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function ticketLogoHtml(config = getTicketConfig()) {
  if (!config.mostrarLogo) return '';
  return `<div class="tt-logo-wrap"><img class="tt-logo" src="${escapeTicket(config.logoSrc || DEFAULT_TICKET_CONFIG.logoSrc)}" alt="${escapeTicket(config.nombreEmpresa)}"></div>`;
}

export function ticketHeaderHtml(config = getTicketConfig()) {
  const nombre = escapeTicket(config.nombreEmpresa || DEFAULT_TICKET_CONFIG.nombreEmpresa);
  const eslogan = escapeTicket(config.eslogan || DEFAULT_TICKET_CONFIG.eslogan);
  return `
    ${ticketLogoHtml(config)}
    <div class="tt-brand-name">${nombre}</div>
    ${config.mostrarEslogan ? `<div class="tt-brand-slogan">${eslogan}</div>` : ''}
  `;
}

export function ticketFooterHtml(config = getTicketConfig()) {
  const partes = [];
  if (config.mostrarTelefono && config.telefono) partes.push(escapeTicket(config.telefono));
  if (config.mostrarDireccion && config.direccion) partes.push(escapeTicket(config.direccion));
  return `
    ${config.mostrarMensajeFinal ? `<div class="tt-thanks">${escapeTicket(config.mensajeFinal || '')}</div>` : ''}
    ${config.mensajeSecundario ? `<div class="tt-small-center">${escapeTicket(config.mensajeSecundario)}</div>` : ''}
    ${partes.length ? `<div class="tt-footer-contact">${partes.join('&nbsp;&nbsp;|&nbsp;&nbsp;')}</div>` : ''}
    ${config.mostrarSitioWeb && config.sitioWeb ? `<div class="tt-site">${escapeTicket(config.sitioWeb)}</div>` : ''}
  `;
}

export function ticketPrintStyles() {
  return `
    @page{size:80mm auto;margin:0}
    *{box-sizing:border-box}
    body{margin:0;padding:0;background:#fff;color:#000;font-family:Arial,"Helvetica Neue",sans-serif;font-size:11px}
    .thermal-ticket{width:72mm;margin:0 auto;padding:4mm 3mm}
    .tt-logo-wrap{text-align:center;margin-bottom:1.5mm}.tt-logo{width:48mm;max-height:30mm;object-fit:contain;filter:grayscale(1) contrast(1.35)}
    .tt-brand-name{text-align:center;font-size:22px;font-weight:950;letter-spacing:.5px;line-height:1;text-transform:uppercase}.tt-brand-slogan{text-align:center;background:#000;color:#fff;border-radius:10px;padding:3px 6px;margin:5px 0 6px;font-size:9px;font-weight:800;text-transform:uppercase}
    .tt-line{border-top:1px dashed #000;margin:7px 0}
    .tt-row{display:flex;justify-content:space-between;gap:8px;margin:3px 0;align-items:flex-start}.tt-row span:first-child{text-transform:uppercase;white-space:nowrap}.tt-row strong{text-align:right}
    .tt-head-row{display:grid;grid-template-columns:13mm 1fr 20mm;background:#000;color:#fff;font-weight:800;padding:5px 6px;border-radius:3px;text-transform:uppercase}
    .tt-product-row{display:grid;grid-template-columns:13mm 1fr 20mm;gap:4px;align-items:start;margin:7px 0}.tt-qty{text-align:center}.tt-product-name{word-break:break-word}.tt-product-name small{display:block;font-size:9px;font-weight:400;margin-top:2px}.tt-product-total{text-align:right}
    .tt-total{font-size:17px;font-weight:900}.tt-balance{display:flex;justify-content:space-between;border:1px solid #000;border-radius:5px;padding:6px;margin:7px 0;text-transform:uppercase;font-weight:900;font-size:13px}
    .tt-thanks{text-align:center;font-size:16px;font-weight:800;font-style:italic;margin:8px 0 5px}.tt-small-center{text-align:center;font-size:10px;margin:2px 0}.tt-footer-contact,.tt-site{text-align:center;font-weight:700;margin-top:4px}.tt-site{font-size:12px}
    @media print{body{padding:0}.thermal-ticket{width:72mm;padding:3mm 2mm}}
  `;
}

export function sampleTicketData() {
  return {
    folio: 'VTA-000125',
    fecha: new Date().toISOString(),
    cajero: 'Dayana',
    cliente: 'Luis Estrada',
    telefono: '5555-1234',
    nit: 'CF',
    tipo_pago: 'crédito',
    total: 165,
    descuento: 0,
    pagado: 0,
    saldo: 165,
    items: [{ cantidad: 1, nombre: 'Audífonos Gaming', sku: 'AUD-GAM-001', total: 165 }]
  };
}
