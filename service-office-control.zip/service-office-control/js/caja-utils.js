import { supabaseClient, money } from "./supabase.js";

export async function obtenerCajaAbierta() {
  const { data, error } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function calcularDisponibleCaja(cajaId) {
  const { data: caja, error: cajaError } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("id", cajaId)
    .single();

  if (cajaError) throw cajaError;

  const { data: movimientos, error: movError } = await supabaseClient
    .from("movimientos_caja")
    .select("tipo,monto")
    .eq("caja_id", cajaId);

  if (movError) throw movError;

  const ingresos = (movimientos || [])
    .filter(m => m.tipo === "ingreso")
    .reduce((sum, m) => sum + Number(m.monto || 0), 0);

  const egresos = (movimientos || [])
    .filter(m => m.tipo === "egreso")
    .reduce((sum, m) => sum + Number(m.monto || 0), 0);

  const apertura = Number(caja.monto_apertura || 0);
  return apertura + ingresos - egresos;
}

export async function validarEfectivoDisponible(cajaId, monto) {
  const disponible = await calcularDisponibleCaja(cajaId);
  const montoNumero = Number(monto || 0);

  if (montoNumero > disponible) {
    return {
      ok: false,
      disponible,
      monto: montoNumero,
      faltante: montoNumero - disponible,
      mensaje: `No hay suficiente efectivo en caja.\n\nDisponible: ${money(disponible)}\nIntentas sacar: ${money(montoNumero)}\nFaltan: ${money(montoNumero - disponible)}`
    };
  }

  return {
    ok: true,
    disponible,
    monto: montoNumero,
    faltante: 0,
    mensaje: ""
  };
}

export function mostrarErrorCaja(msgElement, validacion) {
  const texto = `❌ No hay suficiente efectivo en caja. Disponible: ${money(validacion.disponible)} · Intentas sacar: ${money(validacion.monto)} · Faltan: ${money(validacion.faltante)}`;

  if (msgElement) {
    msgElement.textContent = texto;
    msgElement.className = "message error";
  } else {
    alert(validacion.mensaje);
  }
}
