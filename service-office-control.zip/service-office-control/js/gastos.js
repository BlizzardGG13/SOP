import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { validarEfectivoDisponible } from "./caja-utils.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let cajaActual = null;
let movimientosCaja = [];
let gastos = [];

const estadoCaja = document.getElementById("estadoCaja");
const cajaDisponible = document.getElementById("cajaDisponible");
const gastosDia = document.getElementById("gastosDia");
const reembolsosDia = document.getElementById("reembolsosDia");
const registrosDia = document.getElementById("registrosDia");
const gastosTabla = document.getElementById("gastosTabla");
const msgGastos = document.getElementById("msgGastos");

async function init() {
  user = await requireAuth();
  if (!user) return;

  perfil = await protegerModulo(user, "gastos");
  if (!perfil) return;

  setupLogout();

  document.getElementById("gastoForm").addEventListener("submit", guardarGasto);
  document.getElementById("recargarGastos").addEventListener("click", cargarTodo);

  await cargarTodo();
}

async function cargarTodo() {
  await cargarCaja();
  await cargarGastos();
}

async function cargarCaja() {
  const { data, error } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    mostrarMensaje(error.message, "error");
    return;
  }

  cajaActual = data || null;

  if (!cajaActual) {
    estadoCaja.textContent = "Caja cerrada";
    estadoCaja.className = "status-pill danger";
    cajaDisponible.textContent = money(0);
    movimientosCaja = [];
    return;
  }

  estadoCaja.textContent = "Caja abierta";
  estadoCaja.className = "status-pill ok";

  const { data: movs, error: movError } = await supabaseClient
    .from("movimientos_caja")
    .select("*")
    .eq("caja_id", cajaActual.id)
    .order("creado_en", { ascending: false });

  if (movError) {
    mostrarMensaje(movError.message, "error");
    return;
  }

  movimientosCaja = movs || [];
  cajaDisponible.textContent = money(calcularDisponible());
}

function calcularDisponible() {
  const apertura = Number(cajaActual?.monto_apertura || 0);
  const ingresos = movimientosCaja
    .filter(m => m.tipo === "ingreso")
    .reduce((sum, m) => sum + Number(m.monto || 0), 0);

  const egresos = movimientosCaja
    .filter(m => m.tipo === "egreso")
    .reduce((sum, m) => sum + Number(m.monto || 0), 0);

  return apertura + ingresos - egresos;
}

async function cargarGastos() {
  const { data, error } = await supabaseClient
    .from("gastos")
    .select("*")
    .order("creado_en", { ascending: false })
    .limit(100);

  if (error) {
    mostrarMensaje(error.message, "error");
    gastosTabla.innerHTML = `<tr><td colspan="8">No se pudieron cargar los gastos.</td></tr>`;
    return;
  }

  gastos = data || [];
  renderGastos();
  calcularResumen();
}

function calcularResumen() {
  const hoy = new Date().toISOString().slice(0, 10);

  const delDia = gastos.filter(g => (g.creado_en || "").slice(0, 10) === hoy && g.estado !== "anulado");

  const totalGastos = delDia
    .filter(g => g.tipo === "egreso")
    .reduce((sum, g) => sum + Number(g.monto || 0), 0);

  const totalReembolsos = delDia
    .filter(g => g.tipo === "ingreso")
    .reduce((sum, g) => sum + Number(g.monto || 0), 0);

  gastosDia.textContent = money(totalGastos);
  reembolsosDia.textContent = money(totalReembolsos);
  registrosDia.textContent = delDia.length;
}

function renderGastos() {
  if (!gastos.length) {
    gastosTabla.innerHTML = `<tr><td colspan="8">Todavía no hay gastos registrados.</td></tr>`;
    return;
  }

  gastosTabla.innerHTML = gastos.map(g => `
    <tr>
      <td>${g.creado_en ? new Date(g.creado_en).toLocaleString("es-GT") : "-"}</td>
      <td><span class="badge ${g.tipo === "ingreso" ? "ok" : "danger"}">${g.tipo === "ingreso" ? "Ingreso" : "Egreso"}</span></td>
      <td>${formatearCategoria(g.categoria)}</td>
      <td>${g.beneficiario || "-"}</td>
      <td>${g.descripcion || "-"}</td>
      <td><strong>${money(g.monto)}</strong></td>
      <td><span class="badge ${g.estado === "anulado" ? "danger" : "ok"}">${g.estado || "activo"}</span></td>
      <td>
        ${g.estado !== "anulado" ? `<button class="btn btn-small btn-danger" onclick="anularGasto('${g.id}')">Anular</button>` : "-"}
      </td>
    </tr>
  `).join("");
}

async function guardarGasto(e) {
  e.preventDefault();

  await cargarCaja();

  if (!cajaActual) {
    mostrarMensaje("Primero debes abrir caja para registrar gastos o reembolsos.", "error");
    return;
  }

  const tipo = document.getElementById("tipoMovimiento").value;
  const categoria = document.getElementById("categoria").value;
  const beneficiario = document.getElementById("beneficiario").value.trim();
  const monto = Number(document.getElementById("monto").value || 0);
  const descripcion = document.getElementById("descripcion").value.trim();

  if (monto <= 0) {
    mostrarMensaje("El monto debe ser mayor a Q0.00.", "error");
    return;
  }

  if (tipo === "egreso") {
    const validacion = await validarEfectivoDisponible(cajaActual.id, monto);
    if (!validacion.ok) {
      mostrarMensaje(validacion.mensaje, "error");
      return;
    }
  }

  const gastoPayload = {
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo,
    categoria,
    beneficiario,
    descripcion,
    monto,
    estado: "activo"
  };

  const { data: gastoCreado, error: gastoError } = await supabaseClient
    .from("gastos")
    .insert([gastoPayload])
    .select()
    .single();

  if (gastoError) {
    mostrarMensaje(gastoError.message, "error");
    return;
  }

  const movimientoPayload = {
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo,
    categoria: tipo === "ingreso" ? "reembolso_gasto" : "gasto",
    persona: beneficiario,
    monto,
    descripcion: `${formatearCategoria(categoria)} · ${descripcion || "Sin descripción"}`,
    referencia_id: gastoCreado.id
  };

  const { error: movError } = await supabaseClient
    .from("movimientos_caja")
    .insert([movimientoPayload]);

  if (movError) {
    await supabaseClient.from("gastos").update({
      estado: "error_movimiento",
      descripcion: `${descripcion} | ERROR MOVIMIENTO CAJA: ${movError.message}`
    }).eq("id", gastoCreado.id);

    mostrarMensaje("Se guardó el gasto, pero NO se pudo mover caja: " + movError.message, "error");
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "gastos",
    accion: tipo === "ingreso" ? "registrar_reembolso" : "registrar_gasto",
    descripcion: `${formatearCategoria(categoria)} · ${money(monto)}`,
    referencia_id: gastoCreado.id
  });

  mostrarMensaje(tipo === "ingreso" ? "Reembolso registrado y sumado a caja." : "Gasto registrado y descontado de caja.", "success");

  e.target.reset();
  await cargarTodo();
}

window.anularGasto = async function(id) {
  const gasto = gastos.find(g => g.id === id);
  if (!gasto || gasto.estado === "anulado") return;

  if (perfil?.rol !== "admin") {
    alert("Solo admin puede anular gastos.");
    return;
  }

  await cargarCaja();

  if (!cajaActual) {
    alert("Primero debe existir una caja abierta para hacer el movimiento de reversa.");
    return;
  }

  if (!confirm("¿Seguro que deseas anular este registro? Se hará un movimiento contrario en caja.")) return;

  const tipoReversa = gasto.tipo === "egreso" ? "ingreso" : "egreso";

  if (tipoReversa === "egreso") {
    const validacion = await validarEfectivoDisponible(cajaActual.id, Number(gasto.monto || 0));
    if (!validacion.ok) {
      alert(validacion.mensaje);
      return;
    }
  }

  const { error: updateError } = await supabaseClient
    .from("gastos")
    .update({
      estado: "anulado",
      anulado_en: new Date().toISOString()
    })
    .eq("id", id);

  if (updateError) {
    alert(updateError.message);
    return;
  }

  const { error: movError } = await supabaseClient.from("movimientos_caja").insert([{
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo: tipoReversa,
    categoria: "anulacion_gasto",
    persona: gasto.beneficiario || "",
    monto: Number(gasto.monto || 0),
    descripcion: `Anulación de ${gasto.tipo === "egreso" ? "gasto" : "reembolso"}: ${gasto.descripcion || ""}`,
    referencia_id: gasto.id
  }]);

  if (movError) {
    alert("El gasto fue marcado como anulado, pero no se pudo mover caja: " + movError.message);
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "gastos",
    accion: "anular_gasto",
    descripcion: `${formatearCategoria(gasto.categoria)} · ${money(gasto.monto)}`,
    referencia_id: gasto.id
  });

  await cargarTodo();
};

function formatearCategoria(categoria) {
  const map = {
    luz: "Luz",
    internet: "Internet",
    renta: "Renta",
    gasolina: "Gasolina",
    transporte: "Transporte",
    repuestos: "Repuestos",
    compra_producto: "Compra de producto",
    comida: "Comida",
    mantenimiento: "Mantenimiento",
    papeleria: "Papelería",
    reembolso: "Reembolso",
    otro: "Otro"
  };

  return map[categoria] || categoria || "-";
}

function mostrarMensaje(texto, tipo = "") {
  msgGastos.textContent = texto;
  msgGastos.className = `message ${tipo}`;
}

instalarNavegacionPremium();
init();
