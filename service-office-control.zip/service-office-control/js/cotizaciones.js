import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user=null, perfil=null;
let productos=[];
let clientes=[];
let items=JSON.parse(localStorage.getItem("soc_cotizacion_actual") || "[]");

async function init(){
  user=await requireAuth(); if(!user) return;
  setupLogout();
  perfil=await protegerModulo(user,"cotizaciones"); if(!perfil) return;
  await Promise.all([cargarProductos(), cargarClientes()]);
  bind();
  renderInventarioCotizaciones();
  renderClientes();
  renderQuote();
}
function bind(){
  document.getElementById("buscarInventarioCot").addEventListener("input", renderInventarioCotizaciones);
  document.getElementById("manualForm").addEventListener("submit", agregarManual);
  document.getElementById("margenInput").addEventListener("input", renderQuote);
  document.getElementById("limpiarCotizacion").addEventListener("click", limpiarCotizacion);
  document.getElementById("nuevaCotizacionBtn").addEventListener("click", limpiarCotizacion);
  document.getElementById("buscarWebBtn").addEventListener("click", simularBusquedaRapida);
  document.getElementById("abrirBusquedaGoogle").addEventListener("click", abrirBusquedaWeb);
  document.getElementById("generarCotizacion").addEventListener("click", generarCotizacionPrint);
  document.getElementById("enviarWhatsapp").addEventListener("click", enviarWhatsapp);
  document.getElementById("guardarBorrador").addEventListener("click", guardarBorrador);
  document.getElementById("historialBtn").addEventListener("click", () => alert("Historial local: el borrador queda guardado en este navegador. En la siguiente fase lo guardamos en tabla de Supabase."));
}
async function cargarProductos(){
  const {data,error}=await supabaseClient.from("inventario_productos").select("*").eq("activo",true).order("nombre",{ascending:true});
  if(!error) productos=data||[];
}
async function cargarClientes(){
  const {data,error}=await supabaseClient.from("clientes").select("*").eq("activo",true).order("nombre",{ascending:true});
  if(!error) clientes=data||[];
}
function renderClientes(){
  const sel=document.getElementById("clienteCotizacion");
  sel.innerHTML='<option value="">Seleccionar cliente</option>';
  clientes.forEach(c=> sel.innerHTML += `<option value="${c.id}">${escapeHtml(c.nombre)} ${c.telefono ? '· '+escapeHtml(c.telefono) : ''}</option>`);
}
function renderInventarioCotizaciones(){
  const q=document.getElementById("buscarInventarioCot").value.toLowerCase().trim();
  const cont=document.getElementById("inventarioCotizaciones");
  const filtrados=productos.filter(p=>`${p.nombre} ${p.codigo||''} ${p.categoria||''}`.toLowerCase().includes(q)).slice(0,12);
  if(!filtrados.length){ cont.innerHTML='<div class="empty-state">No hay productos de inventario.</div>'; return; }
  cont.innerHTML=filtrados.map(p=> resultCard({
    id:p.id, nombre:p.nombre, detalle:`${p.categoria||'Inventario'} · Stock: ${p.stock||0}`, precio:Number(p.precio_venta||0), tienda:'Inventario', imagen:p.imagen_url||'', fuente:'inventario'
  })).join('');
}
function resultCard(r){
  const img=r.imagen ? `<img src="${r.imagen}" alt="${escapeHtml(r.nombre)}">` : `<div class="quote-img-empty">SO</div>`;
  return `<article class="quote-result-card">
    <div class="quote-product-info">${img}<div><strong>${escapeHtml(r.nombre)}</strong><small>${escapeHtml(r.detalle||'')}</small><span class="badge ok">${escapeHtml(r.fuente||'web')}</span></div></div>
    <div><strong class="quote-price">${money(r.precio)}</strong><small>${escapeHtml(r.tienda||'')}</small></div>
    <button class="btn btn-secondary" onclick='agregarItemCotizacion(${JSON.stringify(r).replace(/'/g,"&#39;")})'>＋ Agregar</button>
  </article>`;
}
window.agregarItemCotizacion=function(r){
  items.push({ id:crypto.randomUUID(), nombre:r.nombre, detalle:r.detalle||'', precio:Number(r.precio||0), tienda:r.tienda||'', url:r.url||'', imagen:r.imagen||'', cantidad:1 });
  save(); renderQuote();
}
function agregarManual(e){
  e.preventDefault();
  const r={ nombre:manualNombre.value.trim(), precio:Number(manualPrecio.value||0), tienda:manualTienda.value.trim()||'Web', url:manualUrl.value.trim(), imagen:manualImagen.value.trim(), detalle:'Producto agregado manualmente', fuente:'manual' };
  if(!r.nombre || r.precio<=0) return alert('Completa nombre y precio.');
  window.agregarItemCotizacion(r);
  e.target.reset();
}
function simularBusquedaRapida(){
  const prod=qProducto.value.trim()||'computadora';
  const min=Number(qMin.value||0), max=Number(qMax.value||0);
  const base=[
    ['Laptop Lenovo IdeaPad 3 15.6”',4299,'Max'],['Laptop Acer Aspire 5 15.6”',4450,'Intelaf'],['Laptop HP 15 Core i5',4699,'Office Depot'],['Laptop Dell Inspiron 3511',4999,'PBX Guatemala'],['Laptop Lenovo V15 G2',4850,'Kemik']
  ].filter(x=>(!min||x[1]>=min)&&(!max||x[1]<=max));
  const cont=document.getElementById('inventarioCotizaciones');
  cont.innerHTML=base.map(x=>resultCard({nombre:x[0], detalle:`Resultado rápido para "${prod}"`, precio:x[1], tienda:x[2], fuente:'web'})).join('') || '<div class="empty-state">No encontré resultados en ese rango.</div>';
}
function abrirBusquedaWeb(){
  const prod=qProducto.value.trim()||'computadora'; const min=qMin.value; const max=qMax.value; const tienda=qTienda.value;
  const query=[prod, tienda, min?`Q${min}`:'', max?`Q${max}`:'', 'Guatemala'].filter(Boolean).join(' ');
  window.open(`https://www.google.com/search?tbm=shop&q=${encodeURIComponent(query)}`,'_blank');
}
function renderQuote(){
  const cont=document.getElementById('quoteItems'); const empty=document.getElementById('emptyQuote');
  empty.style.display=items.length?'none':'block';
  cont.innerHTML=items.map(i=>`<article class="quote-item"><div>${i.imagen?`<img src="${i.imagen}">`:'<div class="quote-img-empty sm">SO</div>'}<div><strong>${escapeHtml(i.nombre)}</strong><small>${escapeHtml(i.tienda||'')}</small></div></div><strong>${money(i.precio*i.cantidad)}</strong><button onclick="quitarItem('${i.id}')">×</button></article>`).join('');
  const subtotal=items.reduce((a,i)=>a+(Number(i.precio||0)*Number(i.cantidad||1)),0); const margen=Number(document.getElementById('margenInput').value||0); const ganancia=subtotal*(margen/100); const total=subtotal+ganancia;
  document.getElementById("quoteSubtotal").textContent=money(subtotal); document.getElementById("quoteGanancia").textContent=money(ganancia); document.getElementById("quoteTotal").textContent=money(total);
}
window.quitarItem=function(id){ items=items.filter(i=>i.id!==id); save(); renderQuote(); }
function limpiarCotizacion(){ if(items.length && !confirm('¿Limpiar cotización actual?')) return; items=[]; save(); renderQuote(); }
function guardarBorrador(){ save(); alert('Borrador guardado en este navegador.'); }
function generarCotizacionPrint(){
  if(!items.length) return alert('Agrega productos primero.');
  const cliente=clientes.find(c=>c.id===clienteCotizacion.value)?.nombre || 'Cliente final';
  const subtotal=document.getElementById("quoteSubtotal").textContent, total=document.getElementById("quoteTotal").textContent;
  const rows=items.map(i=>`<tr><td>${escapeHtml(i.nombre)}</td><td>${escapeHtml(i.tienda||'')}</td><td style="text-align:right">${money(i.precio)}</td></tr>`).join('');
  const w=window.open('','_blank');
  w.document.write(`<html><head><title>Cotización</title><style>body{font-family:Arial;padding:30px}h1{color:#e11d1d}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #ddd}.total{font-size:24px;color:#e11d1d}</style></head><body><h1>Service Office Control</h1><h2>Cotización</h2><p><b>Cliente:</b> ${escapeHtml(cliente)}</p><p><b>Fecha:</b> ${new Date().toLocaleString('es-GT')}</p><table><tr><th>Producto</th><th>Tienda</th><th>Precio</th></tr>${rows}</table><p>Subtotal: ${subtotal}</p><p class="total"><b>Total sugerido:</b> ${total}</p><p>Precios y disponibilidad sujetos a cambio.</p><script>window.print()</script></body></html>`);
  w.document.close();
  registrarAuditoria({usuario:user,perfil,modulo:'cotizaciones',accion:'generar_cotizacion',descripcion:`${cliente} · ${total}`});
}
function enviarWhatsapp(){
  if(!items.length) return alert('Agrega productos primero.');
  const cliente=clientes.find(c=>c.id===clienteCotizacion.value);
  const detalle=items.map(i=>`• ${i.nombre}: ${money(i.precio)}`).join('%0A');
  const msg=`Cotización Service Office%0A${detalle}%0ATotal sugerido: ${document.getElementById("quoteTotal").textContent}%0APrecios sujetos a cambio.`;
  window.open(`https://wa.me/${cliente?.telefono ? cliente.telefono.replace(/\D/g,'') : ''}?text=${msg}`,'_blank');
}
function save(){localStorage.setItem('soc_cotizacion_actual',JSON.stringify(items));}
function escapeHtml(str){return String(str??'').replace(/[&<>'"]/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s]));}
instalarNavegacionPremium();
init();
