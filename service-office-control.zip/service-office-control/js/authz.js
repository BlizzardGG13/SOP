import { supabaseClient } from "./supabase.js";

export const PERMISOS = {
  admin: {
    modulos: [
      "dashboard",
      "clientes",
      "caja",
      "gastos",
      "ventas",
      "inventario",
      "compras_inventario",
      "impresiones",
      "reportes",
      "prestamos",
      "creditos",
      "contra_entrega",
      "usuarios",
      "auditoria",
      "camaras",
      "instalaciones",
      "devoluciones",
      "documentos",
      "facturacion",
      "ticket_config",
      "cotizaciones"
    ],
    puedeGestionarUsuarios: true,
    puedeVerAuditoria: true,
    puedeBorrar: true,
    puedeConfigurar: true
  },

  cajera: {
    modulos: [
      "dashboard",
      "clientes",
      "caja",
      "gastos",
      "ventas",
      "inventario",
      "impresiones",
      "reportes",
      "prestamos",
      "creditos",
      "contra_entrega",
      "camaras",
      "devoluciones",
      "documentos",
      "cotizaciones"
    ],
    puedeGestionarUsuarios: false,
    puedeVerAuditoria: false,
    puedeBorrar: false,
    puedeConfigurar: false
  },

  tecnico: {
    modulos: [
      "instalaciones"
    ],
    puedeGestionarUsuarios: false,
    puedeVerAuditoria: false,
    puedeBorrar: false,
    puedeConfigurar: false
  }
};

export async function obtenerPerfilActual(userId, email = null) {
  const normalizarPerfil = (perfil) => {
    if (!perfil) return null;
    return {
      ...perfil,
      email: perfil.email || perfil.correo || email || null,
      rol: perfil.rol || perfil.role || "cajera",
      activo: perfil.activo === true || perfil.activo === "true" || perfil.activo === 1
    };
  };

  let consulta = await supabaseClient
    .from("usuarios_perfiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();

  if (consulta.data) return normalizarPerfil(consulta.data);

  if (email) {
    consulta = await supabaseClient
      .from("usuarios_perfiles")
      .select("*")
      .or(`email.eq.${email},correo.eq.${email}`)
      .maybeSingle();

    if (consulta.data) return normalizarPerfil(consulta.data);
  }

  consulta = await supabaseClient
    .from("perfiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();

  if (consulta.data) return normalizarPerfil(consulta.data);

  if (email) {
    consulta = await supabaseClient
      .from("perfiles")
      .select("*")
      .eq("email", email)
      .maybeSingle();

    if (consulta.data) return normalizarPerfil(consulta.data);
  }

  console.warn("Perfil no encontrado:", { userId, email });
  return null;
}

export function permisosDe(rol) {
  return PERMISOS[rol] || PERMISOS.cajera;
}

export function puedeVerModulo(perfil, modulo) {
  if (!perfil || !perfil.activo) return false;
  return permisosDe(perfil.rol).modulos.includes(modulo);
}

export async function protegerModulo(user, modulo) {
  const perfil = await obtenerPerfilActual(user.id, user.email);

  if (!perfil || !perfil.activo) {
    await supabaseClient.auth.signOut();
    window.location.href = "index.html";
    return null;
  }

  if (!puedeVerModulo(perfil, modulo)) {
    window.location.href = perfil.rol === "tecnico" ? "instalaciones.html" : "dashboard.html";
    return null;
  }

  renderSidebar(perfil, modulo);
  renderUserMini(perfil);
  return perfil;
}

export function renderSidebar(perfil, moduloActivo) {
  const navs = document.querySelectorAll(".sidebar nav");
  if (!navs.length) return;

  const icons = {
    dashboard: "🏠",
    clientes: "👥",
    caja: "💰",
    gastos: "💸",
    ventas: "🛒",
    inventario: "📦",
    compras_inventario: "🛒",
    impresiones: "🖨️",
    reportes: "📊",
    prestamos: "🤝",
    creditos: "💳",
    contra_entrega: "🚚",
    usuarios: "🔐",
    auditoria: "🧾",
    camaras: "📹",
    instalaciones: "🛠️",
    devoluciones: "↩️",
    documentos: "📄",
    facturacion: "🧾",
    ticket_config: "🎫",
    cotizaciones: "🧾"
  };

  const items = [
    ["dashboard", "Dashboard", "dashboard.html"],
    ["clientes", "Clientes", "clientes.html"],
    ["caja", "Caja", "caja.html"],
    ["gastos", "Gastos", "gastos.html"],
    ["ventas", "Ventas", "ventas.html"],
    ["inventario", "Inventario", "inventario.html"],
    ["compras_inventario", "Compras inventario", "compras-inventario.html"],
    ["cotizaciones", "Cotizaciones", "cotizaciones.html"],
    ["impresiones", "Impresiones", "impresiones.html"],
    ["reportes", "Reportes", "reportes.html"],
    ["prestamos", "Préstamos", "prestamos.html"],
    ["creditos", "Créditos", "creditos.html"],
    ["contra_entrega", "Contra entrega", "contra-entrega.html"],
    ["camaras", "Cámaras", "camaras.html"],
    ["instalaciones", "Instalaciones", "instalaciones.html"],
    ["devoluciones", "Devoluciones", "devoluciones.html"],
    ["documentos", "Documentos", "documentos.html"],
    ["facturacion", "Facturación", "facturacion.html"],
    ["ticket_config", "Ticket térmico", "ticket-config.html"],
    ["usuarios", "Usuarios", "usuarios.html"],
    ["auditoria", "Auditoría", "auditoria.html"]
  ];

  const permisos = permisosDe(perfil.rol);

  const html = items
    .filter(([key]) => permisos.modulos.includes(key))
    .map(([key, label, href]) => `
      <a href="${href}" class="${key === moduloActivo ? "active" : ""}">
        <span class="nav-icon">${icons[key] || "•"}</span>
        <span>${label}</span>
      </a>
    `)
    .join("");

  navs.forEach(nav => {
    nav.innerHTML = html;
  });
}

export function renderUserMini(perfil) {
  const sidebars = document.querySelectorAll(".sidebar");
  sidebars.forEach(sidebar => {
    if (sidebar.querySelector(".sidebar-user")) return;
    const div = document.createElement("div");
    div.className = "sidebar-user";
    div.innerHTML = `
      <strong>${perfil.nombre || "Usuario"}</strong>
      <small>${perfil.rol || "rol"}</small>
      <span>● En línea</span>
    `;
    const logout = sidebar.querySelector("#logoutBtn");
    if (logout) sidebar.insertBefore(div, logout);
  });
}

export async function registrarAuditoria({ usuario, perfil, modulo, accion, descripcion = "", referencia_id = null, metadata = null }) {
  try {
    await supabaseClient.from("auditoria_acciones").insert([{
      usuario_id: usuario?.id || null,
      usuario_nombre: perfil?.nombre || usuario?.email || "Usuario",
      usuario_rol: perfil?.rol || "sin_rol",
      modulo,
      accion,
      descripcion,
      referencia_id,
      metadata
    }]);
  } catch (error) {
    console.warn("No se pudo registrar auditoría:", error);
  }
}
