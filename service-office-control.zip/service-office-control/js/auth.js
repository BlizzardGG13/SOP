import { supabaseClient } from "./supabase.js";

const form = document.getElementById("loginForm");
const msg = document.getElementById("loginMsg");

async function obtenerPerfil(userId) {
  const { data, error } = await supabaseClient
    .from("usuarios_perfiles")
    .select("*")
    .eq("id", userId)
    .single();

  if (error) return null;
  return data;
}

function destinoPorRol(perfil) {
  if (perfil?.rol === "tecnico") return "instalaciones.html";
  return "dashboard.html";
}

async function checkSession() {
  const { data } = await supabaseClient.auth.getSession();
  if (data.session?.user) {
    const perfil = await obtenerPerfil(data.session.user.id);
    window.location.href = destinoPorRol(perfil);
  }
}

checkSession();

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  msg.textContent = "Ingresando...";
  msg.className = "message";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });

  if (error) {
    msg.textContent = "Correo o contraseña incorrectos.";
    msg.className = "message error";
    return;
  }

  const perfil = await obtenerPerfil(data.user.id);

  if (!perfil || !perfil.activo) {
    await supabaseClient.auth.signOut();
    msg.textContent = "Tu usuario no tiene perfil activo.";
    msg.className = "message error";
    return;
  }

  window.location.href = destinoPorRol(perfil);
});
