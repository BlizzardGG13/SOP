import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { validarEfectivoDisponible } from "./caja-utils.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let cajaActual = null;
let movimientos = [];
let ultimoResumenCierre = null;

async function init() {
  user = await requireAuth();
  if (!user) return;

  perfil = await protegerModulo(user, "caja");
  if (!perfil) return;
  setupLogout();

  document.getElementById("abrirCajaForm").addEventListener("submit", abrirCaja);
  document.getElementById("movimientoForm").addEventListener("submit", guardarMovimiento);
  document.getElementById("preCierreForm").addEventListener("submit", revisarCierre);
  document.getElementById("confirmarCierreForm").addEventListener("submit", confirmarCierre);
  document.getElementById("recargarHistorial").addEventListener("click", cargarHistorialCajas);
  document.getElementById("cerrarCierreCajaModal")?.addEventListener("click", cerrarModalCierreCaja);
  document.getElementById("cerrarCierreCajaFooter")?.addEventListener("click", cerrarModalCierreCaja);
  document.getElementById("imprimirCierreCaja")?.addEventListener("click", imprimirCierreCajaActual);
  document.getElementById("cierreCajaModal")?.addEventListener("click", e => {
    if(e.target.id === "cierreCajaModal") cerrarModalCierreCaja();
  });

  await cargarCaja();
  await cargarHistorialCajas();
}

async function cargarCaja() {
  const { data } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  cajaActual = data;
  actualizarVista();

  if (cajaActual) {
    await cargarMovimientos();
  } else {
    movimientos = [];
    document.getElementById("movimientosTabla").innerHTML = "";
    limpiarTotales();
  }
}

function actualizarVista() {
  const estado = document.getElementById("estadoCaja");
  const abrirPanel = document.getElementById("abrirCajaPanel");
  const movimientoPanel = document.getElementById("movimientoPanel");
  const cerrarPanel = document.getElementById("cerrarCajaPanel");

  if (!cajaActual) {
    estado.textContent = "Caja cerrada";
    estado.className = "status-pill danger";
    abrirPanel.style.display = "block";
    movimientoPanel.style.display = "none";
    cerrarPanel.style.display = "none";
    return;
  }

  estado.textContent = "Caja abierta";
  estado.className = "status-pill ok";
  abrirPanel.style.display = "none";
  movimientoPanel.style.display = "block";
  cerrarPanel.style.display = "block";

  document.getElementById("montoApertura").textContent = money(cajaActual.monto_apertura);
}

function limpiarTotales() {
  document.getElementById("montoApertura").textContent = money(0);
  document.getElementById("totalIngresos").textContent = money(0);
  document.getElementById("totalEgresos").textContent = money(0);
  document.getElementById("esperadoCaja").textContent = money(0);

  const disponibleEl = document.getElementById("disponibleCaja");
  if (disponibleEl) disponibleEl.textContent = money(0);
}

async function abrirCaja(e) {
  e.preventDefault();

  const monto = Number(document.getElementById("montoInicial").value || 0);

  const { error } = await supabaseClient.from("cajas").insert([{
    usuario_id: user.id,
    monto_apertura: monto,
    estado: "abierta"
  }]);

  if (error) {
    alert(error.message);
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "caja",
    accion: "abrir_caja",
    descripcion: `Apertura con ${money(monto)}`
  });

  e.target.reset();
  await cargarCaja();
}

async function cargarMovimientos() {
  const { data, error } = await supabaseClient
    .from("movimientos_caja")
    .select("*")
    .eq("caja_id", cajaActual.id)
    .order("creado_en", { ascending: false });

  if (error) {
    alert(error.message);
    return;
  }

  movimientos = data || [];
  renderMovimientos();
  calcularTotales();
  resetResumenCierre();
}

function renderMovimientos() {
  const tbody = document.getElementById("movimientosTabla");

  if (!movimientos.length) {
    tbody.innerHTML = `<tr><td colspan="6">No hay movimientos en esta caja.</td></tr>`;
    return;
  }

  tbody.innerHTML = movimientos.map(m => `
    <tr>
      <td><span class="badge ${m.tipo === "ingreso" ? "ok" : "danger"}">${m.tipo}</span></td>
      <td>${formatearCategoria(m.categoria)}</td>
      <td>${m.persona || "-"}</td>
      <td>${m.descripcion || "-"}</td>
      <td>${money(m.monto)}</td>
      <td>${new Date(m.creado_en).toLocaleString("es-GT")}</td>
    </tr>
  `).join("");
}

function calcularTotales() {
  const resumen = obtenerResumenCaja();

  document.getElementById("totalIngresos").textContent = money(resumen.totalIngresos);
  document.getElementById("totalEgresos").textContent = money(resumen.totalEgresos);
  document.getElementById("esperadoCaja").textContent = money(resumen.esperado);

  const disponibleEl = document.getElementById("disponibleCaja");
  if (disponibleEl) disponibleEl.textContent = money(resumen.esperado);
}

function obtenerResumenCaja(montoReal = null) {
  const ingresosPorCategoria = {};
  const egresosPorCategoria = {};

  for (const m of movimientos) {
    const monto = Number(m.monto || 0);
    if (m.tipo === "ingreso") {
      ingresosPorCategoria[m.categoria] = (ingresosPorCategoria[m.categoria] || 0) + monto;
    } else if (m.tipo === "egreso") {
      egresosPorCategoria[m.categoria] = (egresosPorCategoria[m.categoria] || 0) + monto;
    }
  }

  const totalIngresos = Object.values(ingresosPorCategoria).reduce((a, b) => a + b, 0);
  const totalEgresos = Object.values(egresosPorCategoria).reduce((a, b) => a + b, 0);
  const apertura = Number(cajaActual?.monto_apertura || 0);
  const esperado = apertura + totalIngresos - totalEgresos;
  const diferencia = montoReal === null ? 0 : Number(montoReal) - esperado;

  return {
    apertura,
    ingresosPorCategoria,
    egresosPorCategoria,
    totalIngresos,
    totalEgresos,
    esperado,
    montoReal,
    diferencia
  };
}

async function guardarMovimiento(e) {
  e.preventDefault();

  if (!cajaActual) {
    alert("Primero debes abrir caja.");
    return;
  }

  const payload = {
    caja_id: cajaActual.id,
    usuario_id: user.id,
    tipo: document.getElementById("tipo").value,
    categoria: document.getElementById("categoria").value,
    persona: document.getElementById("persona").value.trim(),
    monto: Number(document.getElementById("montoMovimiento").value || 0),
    descripcion: document.getElementById("descripcion").value.trim()
  };

  if (payload.monto <= 0) {
    alert("El monto debe ser mayor a Q0.00.");
    return;
  }

  if (payload.tipo === "egreso") {
    const validacion = await validarEfectivoDisponible(cajaActual.id, payload.monto);

    if (!validacion.ok) {
      alert(validacion.mensaje);
      return;
    }
  }

  const { error } = await supabaseClient
    .from("movimientos_caja")
    .insert([payload]);

  if (error) {
    alert(error.message);
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "caja",
    accion: payload.tipo === "ingreso" ? "registrar_ingreso" : "registrar_egreso",
    descripcion: `${payload.categoria}: ${money(payload.monto)}`
  });

  e.target.reset();
  await cargarMovimientos();
}

async function revisarCierre(e) {
  e.preventDefault();

  // v22: recarga directa por caja_id para que el detalle del día no salga vacío.
  // No usamos solo filtros por fecha; la relación confiable es movimientos_caja.caja_id.
  if (cajaActual) {
    movimientosCierreParaImprimir = await cargarMovimientosCajaPorId(cajaActual.id);
    movimientos = [...movimientosCierreParaImprimir];
    renderMovimientos();
  }

  const montoReal = Number(document.getElementById("montoReal").value || 0);
  ultimoResumenCierre = obtenerResumenCaja(montoReal);

  const resumenDiv = document.getElementById("resumenCierre");
  const confirmarForm = document.getElementById("confirmarCierreForm");
  const observacion = document.getElementById("observacionCierre");

  const diferencia = ultimoResumenCierre.diferencia;
  const absDiff = Math.abs(diferencia);

  let estado = "";
  let sugerencias = "";

  if (absDiff < 0.01) {
    estado = `<div class="close-ok">✅ Caja cuadrada correctamente.</div>`;
    sugerencias = `<p>No hay diferencia entre el dinero esperado y el dinero contado.</p>`;
    observacion.required = false;
    observacion.placeholder = "Observación opcional.";
  } else if (diferencia < 0) {
    estado = `<div class="close-error">⚠️ Falta dinero en caja: ${money(absDiff)}</div>`;
    sugerencias = `
      <p><strong>Posibles razones:</strong></p>
      <ul>
        <li>Se hizo un gasto o retiro y no se registró.</li>
        <li>Se entregó vuelto de más.</li>
        <li>Falta registrar una venta, anticipo o abono.</li>
        <li>Algún movimiento fue registrado con monto incorrecto.</li>
      </ul>
    `;
    observacion.required = true;
    observacion.placeholder = "Obligatorio: explica por qué falta dinero o qué se revisó.";
  } else {
    estado = `<div class="close-warning">⚠️ Sobra dinero en caja: ${money(absDiff)}</div>`;
    sugerencias = `
      <p><strong>Posibles razones:</strong></p>
      <ul>
        <li>Se cobró algo y no se registró.</li>
        <li>Se registró una venta con monto menor.</li>
        <li>No se anotó un préstamo recibido o ingreso extra.</li>
        <li>El monto inicial pudo haberse ingresado incorrectamente.</li>
      </ul>
    `;
    observacion.required = true;
    observacion.placeholder = "Obligatorio: explica por qué sobra dinero o qué se revisó.";
  }

  resumenDiv.className = "close-summary";
  resumenDiv.innerHTML = `
    <h3>Resumen de cierre</h3>
    ${estado}

    <div class="summary-lines">
      <div><span>Monto inicial</span><strong>${money(ultimoResumenCierre.apertura)}</strong></div>
      <div><span>Total ingresos</span><strong>${money(ultimoResumenCierre.totalIngresos)}</strong></div>
      <div><span>Total egresos</span><strong>${money(ultimoResumenCierre.totalEgresos)}</strong></div>
      <div><span>Total esperado</span><strong>${money(ultimoResumenCierre.esperado)}</strong></div>
      <div><span>Dinero contado</span><strong>${money(ultimoResumenCierre.montoReal)}</strong></div>
      <div><span>Diferencia</span><strong>${money(ultimoResumenCierre.diferencia)}</strong></div>
    </div>

    <h4>Ingresos por categoría</h4>
    ${renderCategoriasResumen(ultimoResumenCierre.ingresosPorCategoria)}

    <h4>Egresos por categoría</h4>
    ${renderCategoriasResumen(ultimoResumenCierre.egresosPorCategoria)}

    ${sugerencias}
  `;

  confirmarForm.style.display = "grid";
}

function renderCategoriasResumen(obj) {
  const entries = Object.entries(obj);

  if (!entries.length) {
    return `<p class="muted">Sin movimientos.</p>`;
  }

  return `
    <div class="mini-list">
      ${entries.map(([categoria, total]) => `
        <div><span>${formatearCategoria(categoria)}</span><strong>${money(total)}</strong></div>
      `).join("")}
    </div>
  `;
}


let ultimoHTMLCierreCaja = "";
// v22: movimientos usados específicamente para imprimir el cierre.
// Evita que el detalle salga vacío si la vista se resetea al cerrar caja.
let movimientosCierreParaImprimir = [];

async function cargarMovimientosCajaPorId(cajaId) {
  if (!cajaId) return [];

  const { data, error } = await supabaseClient
    .from("movimientos_caja")
    .select("id,caja_id,usuario_id,tipo,categoria,descripcion,persona,monto,creado_en,referencia_id")
    .eq("caja_id", cajaId)
    .order("creado_en", { ascending: true });

  if (error) {
    console.warn("No se pudieron cargar movimientos del cierre:", error.message);
    return [];
  }

  return data || [];
}

function folioCierreCaja() {
  return "SO-CC-" + Date.now();
}

function usuarioActualCaja() {
  return perfil?.nombre || perfil?.email || user?.email || "Usuario";
}


function logoEmpresaHTML() {
  return `<img class="ticket-logo-img" src="img/Logo_facturas.jpeg" alt="Service Office" />`;
}

function horaMovimiento(fecha) {
  if (!fecha) return "-";
  return new Date(fecha).toLocaleTimeString("es-GT", { hour:"2-digit", minute:"2-digit" });
}

function descripcionMovimiento(m) {
  return m.descripcion || m.persona || formatearCategoria(m.categoria) || "-";
}

function referenciaMovimiento(m) {
  return m.referencia || m.folio || m.referencia_id || "-";
}

function movimientosOrdenadosCaja() {
  const fuente = (movimientosCierreParaImprimir && movimientosCierreParaImprimir.length)
    ? movimientosCierreParaImprimir
    : (movimientos || []);

  return [...fuente].sort((a,b) => new Date(a.creado_en || 0) - new Date(b.creado_en || 0));
}

function renderDetalleMovimientosCierre(resumen) {
  const lista = movimientosOrdenadosCaja();
  if (!lista.length) {
    return `<tr><td colspan="8">Sin movimientos registrados.</td></tr>`;
  }

  let saldo = Number(resumen.apertura || 0);

  return lista.map(m => {
    const monto = Number(m.monto || 0);
    const ingreso = m.tipo === "ingreso" ? monto : 0;
    const egreso = m.tipo === "egreso" ? monto : 0;
    saldo += ingreso - egreso;

    return `
      <tr>
        <td>${horaMovimiento(m.creado_en)}</td>
        <td><span class="mini-badge ${m.tipo === "ingreso" ? "ok" : "danger"}">${m.tipo}</span></td>
        <td>${formatearCategoria(m.categoria)}</td>
        <td>${descripcionMovimiento(m)}</td>
        <td>${referenciaMovimiento(m)}</td>
        <td class="right text-ok">${ingreso ? money(ingreso) : "-"}</td>
        <td class="right text-danger">${egreso ? money(egreso) : "-"}</td>
        <td class="right">${money(saldo)}</td>
      </tr>
    `;
  }).join("");
}

function totalCategoria(resumen, tipo, categoria) {
  const obj = tipo === "ingreso" ? resumen.ingresosPorCategoria || {} : resumen.egresosPorCategoria || {};
  return Number(obj[categoria] || 0);
}

function htmlMediosPagoPlaceholder() {
  return `
    <div class="ticket-box">
      <h3>Desglose de medios de pago</h3>
      <table>
        <tbody>
          <tr><td>Efectivo</td><td class="right">Según movimientos de caja</td></tr>
          <tr><td>Transferencia / tarjeta</td><td class="right">Registrar como observación si aplica</td></tr>
        </tbody>
      </table>
    </div>
  `;
}

function htmlCierreCaja(resumen, caja, observacion = "", folio = "") {
  const ingresos = Object.entries(resumen.ingresosPorCategoria || {});
  const egresos = Object.entries(resumen.egresosPorCategoria || {});
  const aperturaFecha = caja?.abierta_en ? new Date(caja.abierta_en).toLocaleString("es-GT") : "-";
  const cierreFecha = new Date().toLocaleString("es-GT");
  const duracionMs = caja?.abierta_en ? (new Date() - new Date(caja.abierta_en)) : 0;
  const horas = Math.floor(duracionMs / 3600000);
  const minutos = Math.floor((duracionMs % 3600000) / 60000);

  const rows = (entries) => entries.length
    ? entries.map(([cat,total]) => `<tr><td>${formatearCategoria(cat)}</td><td class="right">${money(total)}</td></tr>`).join("")
    : `<tr><td colspan="2">Sin movimientos</td></tr>`;

  const diferenciaClase = Math.abs(Number(resumen.diferencia || 0)) < 0.01 ? "ok" : "danger";

  return `
    <div class="ticket-cierre-caja ticket-cierre-premium">
      <div class="ticket-top-brand">
        <div class="brand-left">
          ${logoEmpresaHTML()}
          <div>
            <h1>Service Office Control</h1>
            <p>Sistema de gestión y control</p>
          </div>
        </div>

        <div class="ticket-title">
          <h2>CIERRE DE CAJA</h2>
          <strong>RESUMEN DETALLADO</strong>
        </div>

        <div class="ticket-folio-box">
          <span>Folio de cierre</span>
          <strong>${folio || "Cierre"}</strong>
          <small>Impreso: ${cierreFecha}</small>
        </div>
      </div>

      <div class="ticket-main-summary">
        <div class="ticket-info-grid">
          <div><span>Cajero</span><strong>${usuarioActualCaja()}</strong></div>
          <div><span>Fecha apertura</span><strong>${aperturaFecha}</strong></div>
          <div><span>Fecha cierre</span><strong>${cierreFecha}</strong></div>
          <div><span>Duración</span><strong>${horas}h ${minutos}m</strong></div>
          <div><span>Caja</span><strong>Caja general</strong></div>
          <div><span>Moneda</span><strong>Quetzales (Q)</strong></div>
        </div>

        <div class="ticket-balance-grid">
          <div><span>Monto inicial</span><strong>${money(resumen.apertura)}</strong></div>
          <div><span>Total ingresos</span><strong class="text-ok">${money(resumen.totalIngresos)}</strong></div>
          <div><span>Total egresos</span><strong class="text-danger">${money(resumen.totalEgresos)}</strong></div>
          <div><span>Efectivo esperado</span><strong>${money(resumen.esperado)}</strong></div>
          <div><span>Efectivo contado</span><strong>${money(resumen.montoReal)}</strong></div>
          <div class="difference-line ${diferenciaClase}"><span>Diferencia</span><strong>${money(resumen.diferencia)}</strong></div>
        </div>
      </div>

      <div class="ticket-cards-3">
        <div class="ticket-box">
          <h3>Resumen de ingresos</h3>
          <table><tbody>
            <tr><td>Ventas al contado</td><td class="right">${money(totalCategoria(resumen, "ingreso", "venta"))}</td></tr>
            <tr><td>Abonos de crédito</td><td class="right">${money(totalCategoria(resumen, "ingreso", "abono_credito"))}</td></tr>
            <tr><td>Anticipos</td><td class="right">${money(totalCategoria(resumen, "ingreso", "anticipo"))}</td></tr>
            <tr><td>Préstamos recibidos</td><td class="right">${money(totalCategoria(resumen, "ingreso", "prestamo_recibido"))}</td></tr>
            <tr><td>Otros ingresos</td><td class="right">${money(totalCategoria(resumen, "ingreso", "otro"))}</td></tr>
            <tr class="total-row"><td>Total ingresos</td><td class="right text-ok">${money(resumen.totalIngresos)}</td></tr>
          </tbody></table>
        </div>

        <div class="ticket-box">
          <h3>Resumen de egresos</h3>
          <table><tbody>
            <tr><td>Gastos</td><td class="right">${money(totalCategoria(resumen, "egreso", "gasto"))}</td></tr>
            <tr><td>Compras</td><td class="right">${money(totalCategoria(resumen, "egreso", "compra_producto"))}</td></tr>
            <tr><td>Retiros</td><td class="right">${money(totalCategoria(resumen, "egreso", "retiro"))}</td></tr>
            <tr><td>Devoluciones</td><td class="right">${money(totalCategoria(resumen, "egreso", "devolucion"))}</td></tr>
            <tr><td>Pago préstamo</td><td class="right">${money(totalCategoria(resumen, "egreso", "pago_prestamo"))}</td></tr>
            <tr class="total-row"><td>Total egresos</td><td class="right text-danger">${money(resumen.totalEgresos)}</td></tr>
          </tbody></table>
        </div>

        <div class="ticket-box">
          <h3>Resumen general</h3>
          <table><tbody>
            <tr><td>Monto inicial</td><td class="right">${money(resumen.apertura)}</td></tr>
            <tr><td>(+) Ingresos</td><td class="right text-ok">${money(resumen.totalIngresos)}</td></tr>
            <tr><td>(-) Egresos</td><td class="right text-danger">${money(resumen.totalEgresos)}</td></tr>
            <tr><td>Efectivo esperado</td><td class="right">${money(resumen.esperado)}</td></tr>
            <tr><td>Efectivo contado</td><td class="right">${money(resumen.montoReal)}</td></tr>
            <tr class="total-row"><td>Diferencia</td><td class="right">${money(resumen.diferencia)}</td></tr>
          </tbody></table>
        </div>
      </div>

      <h3 class="section-title">Detalle de movimientos del día</h3>
      <table class="movement-detail-table">
        <thead>
          <tr>
            <th>Hora</th>
            <th>Tipo</th>
            <th>Categoría</th>
            <th>Descripción</th>
            <th>Referencia</th>
            <th>Ingreso</th>
            <th>Egreso</th>
            <th>Saldo</th>
          </tr>
        </thead>
        <tbody>
          ${renderDetalleMovimientosCierre(resumen)}
          <tr class="total-row">
            <td colspan="5">Totales</td>
            <td class="right text-ok">${money(resumen.totalIngresos)}</td>
            <td class="right text-danger">${money(resumen.totalEgresos)}</td>
            <td class="right">${money(resumen.esperado)}</td>
          </tr>
        </tbody>
      </table>

      <div class="ticket-bottom-grid">
        ${htmlMediosPagoPlaceholder()}

        <div class="ticket-box">
          <h3>Observaciones</h3>
          <div class="ticket-observacion"><p>${observacion || "Sin observaciones."}</p></div>
        </div>

        <div class="ticket-box">
          <h3>Resumen final</h3>
          <table><tbody>
            <tr><td>Efectivo esperado</td><td class="right">${money(resumen.esperado)}</td></tr>
            <tr><td>Efectivo contado</td><td class="right">${money(resumen.montoReal)}</td></tr>
            <tr class="total-row"><td>Diferencia</td><td class="right">${money(resumen.diferencia)}</td></tr>
          </tbody></table>
        </div>
      </div>

      <div class="ticket-firmas">
        <div>Cajero<br><small>${usuarioActualCaja()}</small></div>
        <div>Administrador / Supervisor<br><small>Firma</small></div>
      </div>

      <p class="ticket-footer">Documento generado automáticamente por Service Office Control · Gracias por su trabajo.</p>
    </div>
  `;
}

function abrirModalCierreCaja(html, titulo = "Resumen de cierre", subtitulo = "Vista previa imprimible") {
  ultimoHTMLCierreCaja = html;
  const modal = document.getElementById("cierreCajaModal");
  const preview = document.getElementById("cierreCajaPreview");
  if(!modal || !preview) return;

  document.getElementById("cierreCajaTitulo").textContent = titulo;
  document.getElementById("cierreCajaSubtitulo").textContent = subtitulo;
  preview.innerHTML = html;
  modal.hidden = false;
}

function cerrarModalCierreCaja() {
  const modal = document.getElementById("cierreCajaModal");
  if(modal) modal.hidden = true;
}

function imprimirCierreCajaActual() {
  if(!ultimoHTMLCierreCaja) return;
  const w = window.open("", "_blank", "width=900,height=900");
  w.document.write(`
    <html>
      <head>
        <title>Cierre de caja</title>
        <style>
          body{font-family:Arial,sans-serif;background:#fff;color:#111;padding:14px}
          .ticket-cierre-caja{max-width:1050px;margin:auto;border:1px solid #d7dee8;border-radius:16px;padding:18px}
          .ticket-top-brand{display:grid;grid-template-columns:1.2fr 1fr .9fr;gap:14px;align-items:center;border-bottom:3px solid #e50914;padding-bottom:12px;margin-bottom:14px}
          .brand-left{display:flex;align-items:center;gap:12px}.ticket-logo-img{width:130px;max-height:54px;object-fit:contain}.brand-left h1{margin:0;color:#111827;font-size:20px}.brand-left p{margin:3px 0;color:#64748b}
          .ticket-title{text-align:center}.ticket-title h2{margin:0;color:#111827;font-size:28px}.ticket-title strong{color:#e50914}
          .ticket-folio-box{border:1px solid #cbd5e1;border-radius:10px;padding:10px;text-align:center}.ticket-folio-box span,.ticket-folio-box small{display:block;color:#64748b}.ticket-folio-box strong{display:block;font-size:18px;color:#111827}
          .ticket-main-summary{display:grid;grid-template-columns:1.2fr .9fr;gap:14px;margin:14px 0}.ticket-info-grid,.ticket-balance-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.ticket-info-grid div,.ticket-balance-grid div{background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;padding:9px}.ticket-info-grid span,.ticket-balance-grid span{display:block;color:#64748b;font-size:11px;font-weight:bold}.ticket-info-grid strong,.ticket-balance-grid strong{font-size:13px}
          .difference-line{border:2px solid #0f766e!important}.difference-line.danger{border-color:#dc2626!important}
          .ticket-cards-3,.ticket-bottom-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:14px 0}.ticket-box{border:1px solid #cbd5e1;border-radius:10px;padding:10px}.ticket-box h3,.section-title{margin:0 0 8px;color:#0f2a55}
          table{width:100%;border-collapse:collapse;font-size:12px}td,th{border-bottom:1px solid #e5e7eb;padding:7px;text-align:left}th{background:#0f2a55;color:#fff}.right{text-align:right}.text-ok{color:#15803d}.text-danger{color:#dc2626}.total-row td{font-weight:bold;border-top:2px solid #111827}
          .mini-badge{padding:3px 6px;border-radius:999px;font-size:10px;font-weight:bold}.mini-badge.ok{background:#dcfce7;color:#15803d}.mini-badge.danger{background:#fee2e2;color:#dc2626}
          .ticket-observacion{background:#f8fafc;min-height:70px;border-radius:8px;padding:9px}.ticket-firmas{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:45px;text-align:center}.ticket-firmas div{border-top:1px solid #111;padding-top:8px}.ticket-footer{text-align:center;color:#64748b;font-size:11px;margin-top:14px}
          @media print{body{padding:0}.ticket-cierre-caja{border:0;max-width:100%;padding:8px}.ticket-cards-3,.ticket-bottom-grid{break-inside:avoid}.movement-detail-table{font-size:10px}}
        </style>
      </head>
      <body>${ultimoHTMLCierreCaja}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}

async function guardarDocumentoCierreCaja(resumen, caja, observacion) {
  const folio = folioCierreCaja();
  const contenido = {
    folio,
    caja_id: caja.id,
    usuario: usuarioActualCaja(),
    apertura_en: caja.abierta_en,
    cierre_en: new Date().toISOString(),
    apertura: resumen.apertura,
    total_ingresos: resumen.totalIngresos,
    total_egresos: resumen.totalEgresos,
    esperado: resumen.esperado,
    monto_real: resumen.montoReal,
    diferencia: resumen.diferencia,
    ingresos_por_categoria: resumen.ingresosPorCategoria,
    egresos_por_categoria: resumen.egresosPorCategoria,
    movimientos: (movimientosCierreParaImprimir && movimientosCierreParaImprimir.length ? movimientosCierreParaImprimir : movimientos),
    observacion: observacion || "Caja cuadrada."
  };

  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .insert([{
      tipo: "cierre_caja",
      referencia_id: caja.id,
      usuario_id: user.id,
      folio,
      titulo: "Cierre de caja",
      contenido
    }])
    .select()
    .single();

  if(error) {
    console.warn("No se pudo guardar documento de cierre:", error.message);
    return { documento:null, folio };
  }

  return { documento:data, folio };
}

window.verCierreCaja = async function(cajaId) {
  const fila = window.__historialCajasSOC?.find(c => String(c.id) === String(cajaId));
  if(!fila) return;

  const resumen = fila.resumen_cierre || {
    apertura: Number(fila.monto_apertura || 0),
    totalIngresos: Number(fila.total_ingresos || 0),
    totalEgresos: Number(fila.total_egresos || 0),
    esperado: Number(fila.monto_apertura || 0) + Number(fila.total_ingresos || 0) - Number(fila.total_egresos || 0),
    montoReal: Number(fila.monto_cierre || 0),
    diferencia: Number(fila.diferencia || 0),
    ingresosPorCategoria: {},
    egresosPorCategoria: {}
  };

  const normalizado = {
    apertura: Number(resumen.apertura ?? fila.monto_apertura ?? 0),
    totalIngresos: Number(resumen.totalIngresos ?? resumen.total_ingresos ?? fila.total_ingresos ?? 0),
    totalEgresos: Number(resumen.totalEgresos ?? resumen.total_egresos ?? fila.total_egresos ?? 0),
    esperado: Number(resumen.esperado ?? 0),
    montoReal: Number(resumen.montoReal ?? resumen.monto_real ?? fila.monto_cierre ?? 0),
    diferencia: Number(resumen.diferencia ?? fila.diferencia ?? 0),
    ingresosPorCategoria: resumen.ingresosPorCategoria || resumen.ingresos_por_categoria || {},
    egresosPorCategoria: resumen.egresosPorCategoria || resumen.egresos_por_categoria || {}
  };

  if(!normalizado.esperado) normalizado.esperado = normalizado.apertura + normalizado.totalIngresos - normalizado.totalEgresos;

  movimientosCierreParaImprimir = Array.isArray(resumen.movimientos) && resumen.movimientos.length
    ? resumen.movimientos
    : await cargarMovimientosCajaPorId(fila.id);

  abrirModalCierreCaja(
    htmlCierreCaja(normalizado, fila, fila.observacion_cierre || "Caja cerrada.", fila.folio_cierre || "Cierre"),
    "Cierre de caja",
    fila.cerrada_en ? new Date(fila.cerrada_en).toLocaleString("es-GT") : "Historial"
  );
};


async function confirmarCierre(e) {
  e.preventDefault();

  // v22: asegura que el documento final de cierre conserve el detalle completo del día
  // sin resetear el resumen calculado.
  if (cajaActual) {
    movimientosCierreParaImprimir = await cargarMovimientosCajaPorId(cajaActual.id);
    movimientos = [...movimientosCierreParaImprimir];
  }

  if (!ultimoResumenCierre) {
    alert("Primero revisa el cierre.");
    return;
  }

  const observacion = document.getElementById("observacionCierre").value.trim();
  const diferencia = Math.abs(ultimoResumenCierre.diferencia);

  if (diferencia >= 0.01 && !observacion) {
    alert("La caja no cuadra. Debes escribir una observación antes de cerrar.");
    return;
  }

  const cierreDocumento = await guardarDocumentoCierreCaja(ultimoResumenCierre, cajaActual, observacion);

  const { error } = await supabaseClient
    .from("cajas")
    .update({
      monto_cierre: ultimoResumenCierre.montoReal,
      total_ingresos: ultimoResumenCierre.totalIngresos,
      total_egresos: ultimoResumenCierre.totalEgresos,
      diferencia: ultimoResumenCierre.diferencia,
      observacion_cierre: observacion || "Caja cuadrada.",
      resumen_cierre: ultimoResumenCierre,
      folio_cierre: cierreDocumento.folio,
      documento_cierre_id: cierreDocumento.documento?.id || null,
      estado: "cerrada",
      cerrada_en: new Date().toISOString()
    })
    .eq("id", cajaActual.id);

  if (error) {
    alert(error.message);
    return;
  }

  abrirModalCierreCaja(
    htmlCierreCaja(ultimoResumenCierre, cajaActual, observacion, cierreDocumento.folio),
    "Cierre de caja generado",
    "Imprime o guarda el PDF antes de salir"
  );

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "caja",
    accion: "cerrar_caja",
    descripcion: `Cierre: ${money(ultimoResumenCierre.montoReal)} · Diferencia: ${money(ultimoResumenCierre.diferencia)}`
  });

  alert("Caja cerrada correctamente. Se generó el resumen imprimible.");

  cajaActual = null;
  movimientos = [];
  ultimoResumenCierre = null;

  document.getElementById("movimientosTabla").innerHTML = "";
  document.getElementById("preCierreForm").reset();
  document.getElementById("confirmarCierreForm").reset();
  resetResumenCierre();

  await cargarCaja();
  await cargarHistorialCajas();
}

function resetResumenCierre() {
  ultimoResumenCierre = null;
  const resumenDiv = document.getElementById("resumenCierre");
  const confirmarForm = document.getElementById("confirmarCierreForm");

  if (resumenDiv) {
    resumenDiv.className = "close-summary empty";
    resumenDiv.textContent = "Ingresa el efectivo real contado para ver el resumen antes de cerrar.";
  }

  if (confirmarForm) {
    confirmarForm.style.display = "none";
  }
}

async function cargarHistorialCajas() {
  const { data, error } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "cerrada")
    .order("cerrada_en", { ascending: false })
    .limit(20);

  if (error) {
    alert(error.message);
    return;
  }

  const tbody = document.getElementById("historialCajasTabla");

  if (!data?.length) {
    tbody.innerHTML = `<tr><td colspan="9">Todavía no hay cajas cerradas.</td></tr>`;
    return;
  }

  window.__historialCajasSOC = data || [];

  tbody.innerHTML = data.map(c => `
    <tr>
      <td>${c.abierta_en ? new Date(c.abierta_en).toLocaleString("es-GT") : "-"}</td>
      <td>${c.cerrada_en ? new Date(c.cerrada_en).toLocaleString("es-GT") : "-"}</td>
      <td>${money(c.monto_apertura)}</td>
      <td>${money(c.total_ingresos)}</td>
      <td>${money(c.total_egresos)}</td>
      <td>${money(c.monto_cierre)}</td>
      <td><strong class="${Number(c.diferencia) === 0 ? "text-ok" : "text-danger"}">${money(c.diferencia)}</strong></td>
      <td>${c.observacion_cierre || "-"}</td>
      <td><button class="btn btn-small btn-primary" type="button" onclick="verCierreCaja('${c.id}')">Imprimir</button></td>
    </tr>
  `).join("");
}

function formatearCategoria(categoria) {
  const map = {
    venta: "Venta",
    anticipo: "Anticipo",
    abono_credito: "Abono crédito",
    prestamo_recibido: "Préstamo recibido",
    prestamo_entregado: "Préstamo entregado",
    abono_prestamo_recibido: "Abono préstamo recibido",
    gasto: "Gasto",
    retiro: "Retiro",
    pago_prestamo: "Pago de préstamo",
    compra_producto: "Compra de producto",
    devolucion: "Devolución",
    otro: "Otro"
  };

  return map[categoria] || categoria;
}

instalarNavegacionPremium();
init();