import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let clientes = [];
let cotizaciones = [];
let tecnicos = [];

async function init() {
  user = await requireAuth();
  if (!user) return;

  setupLogout();

  perfil = await protegerModulo(user, "camaras");
  if (!perfil) return;

  document.getElementById("camaraForm").addEventListener("submit", guardarCotizacion);
  document.getElementById("buscarCamara").addEventListener("input", renderCotizaciones);

  await cargarClientes();
  await cargarTecnicos();
  await cargarCotizaciones();
}

async function cargarClientes() {
  const { data, error } = await supabaseClient
    .from("clientes")
    .select("*")
    .eq("activo", true)
    .order("nombre", { ascending: true });

  if (error) {
    mostrar("Error cargando clientes: " + error.message, "error");
    return;
  }

  clientes = data || [];

  const select = document.getElementById("clienteId");
  select.innerHTML = `<option value="">Seleccionar cliente</option>`;

  clientes.forEach(c => {
    select.innerHTML += `<option value="${c.id}">${c.nombre}</option>`;
  });
}

async function cargarTecnicos() {
  const select = document.getElementById("tecnicoId");
  if (!select) return;

  const { data, error } = await supabaseClient
    .from("usuarios_perfiles")
    .select("*")
    .eq("rol", "tecnico")
    .eq("activo", true)
    .order("nombre", { ascending: true });

  if (error) {
    console.error("Error cargando técnicos:", error);
    return;
  }

  tecnicos = data || [];

  select.innerHTML = `<option value="">Seleccionar técnico para instalación</option>`;

  tecnicos.forEach(t => {
    select.innerHTML += `<option value="${t.id}">${t.nombre}</option>`;
  });
}

async function cargarCotizaciones() {
  const { data, error } = await supabaseClient
    .from("camaras_cotizaciones")
    .select(`
      *,
      clientes (
        nombre,
        telefono,
        direccion
      )
    `)
    .order("creado_en", { ascending: false });

  if (error) {
    mostrar("Error cargando cotizaciones: " + error.message, "error");
    return;
  }

  cotizaciones = data || [];
  renderCotizaciones();
}

async function guardarCotizacion(e) {
  e.preventDefault();

  const equipoTotal = Number(document.getElementById("equipoTotal").value || 0);
  const manoObra = Number(document.getElementById("manoObra").value || 0);
  const anticipo = Number(document.getElementById("anticipo").value || 0);

  const total = equipoTotal + manoObra;
  const saldo = Math.max(total - anticipo, 0);

  const payload = {
    cliente_id: document.getElementById("clienteId").value || null,
    usuario_id: user.id,
    titulo: document.getElementById("titulo").value.trim() || "Cotización de cámaras",
    cantidad_camaras: Number(document.getElementById("cantidadCamaras").value || 1),
    resolucion: document.getElementById("resolucion").value,
    tipo_sistema: document.getElementById("tipoSistema").value,
    incluye_disco: document.getElementById("incluyeDisco").checked,
    metros_cable: Number(document.getElementById("metrosCable").value || 0),
    equipo_total: equipoTotal,
    mano_obra: manoObra,
    total,
    anticipo,
    saldo,
    estado: anticipo > 0 ? "anticipo_recibido" : "cotizado",
    notas: document.getElementById("notas").value.trim(),
    actualizado_en: new Date().toISOString()
  };

  const { error } = await supabaseClient
    .from("camaras_cotizaciones")
    .insert([payload]);

  if (error) {
    mostrar(error.message, "error");
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "camaras",
    accion: "crear_cotizacion_camaras",
    descripcion: `${payload.cantidad_camaras} cámaras ${payload.resolucion} · ${money(total)}`
  });

  mostrar("Cotización guardada.", "success");

  e.target.reset();
  document.getElementById("titulo").value = "Cotización de cámaras";
  document.getElementById("cantidadCamaras").value = 4;
  document.getElementById("incluyeDisco").checked = true;

  await cargarCotizaciones();
}

function renderCotizaciones() {
  const q = document.getElementById("buscarCamara").value.toLowerCase().trim();

  const lista = cotizaciones.filter(c => {
    const texto = `
      ${c.clientes?.nombre || ""}
      ${c.resolucion || ""}
      ${c.estado || ""}
      ${c.tipo_sistema || ""}
    `.toLowerCase();

    return texto.includes(q);
  });

  const tbody = document.getElementById("camarasTabla");

  if (!lista.length) {
    tbody.innerHTML = `<tr><td colspan="7">No hay cotizaciones de cámaras.</td></tr>`;
    return;
  }

  tbody.innerHTML = lista.map(c => `
    <tr>
      <td>
        <strong>${c.clientes?.nombre || "Sin cliente"}</strong>
        <br>
        <small>${c.clientes?.telefono || ""}</small>
      </td>

      <td>
        ${c.cantidad_camaras} cámaras · ${c.resolucion} · ${c.tipo_sistema}
        <br>
        <small>${c.incluye_disco ? "Incluye disco duro" : "Sin disco duro"}</small>
      </td>

      <td>${money(c.total)}</td>
      <td>${money(c.anticipo)}</td>
      <td><strong>${money(c.saldo)}</strong></td>

      <td>
        <span class="badge ${c.estado === "cotizado" ? "warning" : "ok"}">
          ${c.estado}
        </span>
      </td>

      <td class="actions">
        <button class="btn btn-small btn-secondary" onclick="crearInstalacion('${c.id}')">
          Crear instalación
        </button>
      </td>
    </tr>
  `).join("");
}

window.crearInstalacion = async function(id) {
  const c = cotizaciones.find(x => x.id === id);
  if (!c) return;

  const tecnicoId = document.getElementById("tecnicoId")?.value || null;

  if (!tecnicoId) {
    alert("Selecciona un técnico antes de crear la instalación.");
    return;
  }

  const cliente = clientes.find(x => x.id === c.cliente_id);
  const tecnico = tecnicos.find(t => t.id === tecnicoId);

  const { error } = await supabaseClient
    .from("camaras_instalaciones")
    .insert([{
      cotizacion_id: c.id,
      cliente_id: c.cliente_id,
      usuario_id: user.id,
      tecnico_id: tecnicoId,
      direccion: cliente?.direccion || c.clientes?.direccion || "",
      estado: "pendiente_instalar",
      notas: `Instalación generada desde cotización ${c.resolucion}. Técnico: ${tecnico?.nombre || "sin nombre"}`
    }]);

  if (error) {
    alert(error.message);
    return;
  }

  await supabaseClient
    .from("camaras_cotizaciones")
    .update({
      estado: "pendiente_instalar",
      actualizado_en: new Date().toISOString()
    })
    .eq("id", id);

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "camaras",
    accion: "crear_instalacion",
    descripcion: `Instalación de ${c.cantidad_camaras} cámaras ${c.resolucion} asignada a ${tecnico?.nombre || tecnicoId}`
  });

  alert("Instalación creada correctamente y asignada al técnico.");

  await cargarCotizaciones();
};

function mostrar(txt, tipo) {
  const el = document.getElementById("camaraMsg");
  el.textContent = txt;
  el.className = `message ${tipo}`;
}

instalarNavegacionPremium();
init();
