import { supabaseClient, requireAuth, setupLogout } from './supabase.js';
import { protegerModulo } from './authz.js';
import { instalarNavegacionPremium } from './app-ui.js';
import { getTicketConfig, saveTicketConfig, resetTicketConfig, ticketHeaderHtml, ticketFooterHtml, ticketPrintStyles, sampleTicketData, escapeTicket } from './ticket-config-utils.js';

const $ = (id) => document.getElementById(id);
let perfil = null;

function formToConfig() {
  return {
    nombreEmpresa: $('ticketNombreEmpresa').value.trim(),
    eslogan: $('ticketEslogan').value.trim(),
    telefono: $('ticketTelefono').value.trim(),
    direccion: $('ticketDireccion').value.trim(),
    sitioWeb: $('ticketSitioWeb').value.trim(),
    logoSrc: $('ticketLogoSrc').value.trim(),
    mensajeFinal: $('ticketMensajeFinal').value.trim(),
    mensajeSecundario: $('ticketMensajeSecundario').value.trim(),
    mostrarLogo: $('mostrarLogo').checked,
    mostrarEslogan: $('mostrarEslogan').checked,
    mostrarTelefono: $('mostrarTelefono').checked,
    mostrarDireccion: $('mostrarDireccion').checked,
    mostrarSitioWeb: $('mostrarSitioWeb').checked,
    mostrarCajero: $('mostrarCajero').checked,
    mostrarCliente: $('mostrarCliente').checked,
    mostrarNit: $('mostrarNit').checked,
    mostrarSku: $('mostrarSku').checked,
    mostrarMensajeFinal: $('mostrarMensajeFinal').checked
  };
}

function fillForm(config) {
  $('ticketNombreEmpresa').value = config.nombreEmpresa || '';
  $('ticketEslogan').value = config.eslogan || '';
  $('ticketTelefono').value = config.telefono || '';
  $('ticketDireccion').value = config.direccion || '';
  $('ticketSitioWeb').value = config.sitioWeb || '';
  $('ticketLogoSrc').value = config.logoSrc || '';
  $('ticketMensajeFinal').value = config.mensajeFinal || '';
  $('ticketMensajeSecundario').value = config.mensajeSecundario || '';
  ['mostrarLogo','mostrarEslogan','mostrarTelefono','mostrarDireccion','mostrarSitioWeb','mostrarCajero','mostrarCliente','mostrarNit','mostrarSku','mostrarMensajeFinal'].forEach(id => {
    $(id).checked = !!config[id];
  });
}

function buildPreviewHtml(config) {
  const doc = sampleTicketData();
  const fecha = new Date(doc.fecha).toLocaleString('es-GT');
  const item = doc.items[0];
  return `
    <div class="thermal-ticket ticket-premium">
      ${ticketHeaderHtml(config)}
      <div class="tt-line"></div>
      <div class="tt-row"><span>Folio:</span><strong>${escapeTicket(doc.folio)}</strong></div>
      <div class="tt-row"><span>Fecha:</span><span>${escapeTicket(fecha)}</span></div>
      ${config.mostrarCajero ? `<div class="tt-row"><span>Cajero:</span><span>${escapeTicket(doc.cajero)}</span></div>` : ''}
      <div class="tt-line"></div>
      ${config.mostrarCliente ? `<div class="tt-row"><span>Cliente:</span><strong>${escapeTicket(doc.cliente)}</strong></div>` : ''}
      <div class="tt-row"><span>Teléfono:</span><span>${escapeTicket(doc.telefono)}</span></div>
      ${config.mostrarNit ? `<div class="tt-row"><span>NIT:</span><span>${escapeTicket(doc.nit)}</span></div>` : ''}
      <div class="tt-line"></div>
      <div class="tt-head-row"><span>CANT.</span><span>DESCRIPCIÓN</span><span>TOTAL</span></div>
      <div class="tt-item tt-product-row">
        <div class="tt-qty">${item.cantidad}</div>
        <div class="tt-product-name"><strong>${escapeTicket(item.nombre)}</strong>${config.mostrarSku ? `<small>SKU: ${escapeTicket(item.sku)}</small>` : ''}</div>
        <div class="tt-product-total"><strong>Q ${Number(item.total).toFixed(2)}</strong></div>
      </div>
      <div class="tt-line"></div>
      <div class="tt-row"><span>Subtotal:</span><strong>Q ${doc.total.toFixed(2)}</strong></div>
      <div class="tt-row"><span>Descuento:</span><strong>Q ${doc.descuento.toFixed(2)}</strong></div>
      <div class="tt-row tt-total"><span>TOTAL:</span><strong>Q ${doc.total.toFixed(2)}</strong></div>
      <div class="tt-line"></div>
      <div class="tt-row"><span>Forma de pago:</span><strong>${escapeTicket(doc.tipo_pago.toUpperCase())}</strong></div>
      <div class="tt-balance"><span>Saldo pendiente:</span><strong>Q ${doc.saldo.toFixed(2)}</strong></div>
      <div class="tt-line"></div>
      ${ticketFooterHtml(config)}
    </div>
  `;
}

function renderPreview() {
  const config = formToConfig();
  $('ticketPreview').innerHTML = `<style>${ticketPrintStyles()}</style>${buildPreviewHtml(config)}`;
}

function imprimirPrueba() {
  const html = buildPreviewHtml(formToConfig());
  const w = window.open('', '_blank', 'width=420,height=720');
  w.document.write(`<html><head><title>Ticket de prueba</title><style>${ticketPrintStyles()}</style></head><body>${html}<script>setTimeout(()=>window.print(),250)</script></body></html>`);
  w.document.close();
  w.focus();
}

async function init() {
  const user = await requireAuth();
  setupLogout();
  perfil = await protegerModulo(user, 'ticket_config');
  if (!perfil) return;
  instalarNavegacionPremium();
  fillForm(getTicketConfig());
  renderPreview();

  document.querySelectorAll('#ticketConfigForm input').forEach(input => input.addEventListener('input', renderPreview));
  document.querySelectorAll('#ticketConfigForm input[type="checkbox"]').forEach(input => input.addEventListener('change', renderPreview));

  $('ticketConfigForm').addEventListener('submit', (e) => {
    e.preventDefault();
    saveTicketConfig(formToConfig());
    $('ticketConfigMsg').textContent = 'Configuración guardada.';
    setTimeout(() => $('ticketConfigMsg').textContent = '', 2200);
    renderPreview();
  });

  $('resetTicket').addEventListener('click', () => {
    const config = resetTicketConfig();
    fillForm(config);
    renderPreview();
  });

  $('probarTicket').addEventListener('click', imprimirPrueba);
}

init();
