import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";
import { getTicketConfig, ticketHeaderHtml, ticketFooterHtml, ticketPrintStyles } from "./ticket-config-utils.js";

let user = null;
let perfil = null;
let productos = [];
let clientes = [];
let carrito = [];
let ultimaLlaveVentaSOC = null;
let productoSeleccionado = null;
let cajaActual = null;

const $ = (id) => document.getElementById(id);


function actualizarBotonAgregarCarrito() {
  const btn = document.getElementById("agregarAlCarrito");
  if (!btn) return;

  if (productoSeleccionado) {
    btn.disabled = false;
    btn.textContent = "Agregar al carrito";
    btn.classList.remove("btn-disabled");
  } else {
    btn.disabled = true;
    btn.textContent = carrito.length ? "Selecciona otro producto" : "Selecciona un producto";
    btn.classList.add("btn-disabled");
  }
}


function fmt(n) {
  try { return typeof money === "function" ? money(Number(n || 0)) : `Q${Number(n || 0).toFixed(2)}`; }
  catch(e) { return `Q${Number(n || 0).toFixed(2)}`; }
}

function precioProducto(p) {
  return Number(p.precio_venta ?? p.precio ?? p.venta ?? p.precio_unitario ?? 0);
}

function costoProducto(p) {
  return Number(p.precio_costo ?? p.costo ?? p.precio_compra ?? p.costo_unitario ?? 0);
}

function codigoProducto(p) {
  return p.sku || p.codigo || p.codigo_barras || "";
}

function normalizarCodigo(valor) {
  return String(valor ?? "").trim().toLowerCase();
}

function buscarProductoPorCodigoExacto(valor) {
  const q = normalizarCodigo(valor);
  if (!q) return null;

  return productos.find(p => {
    const codigo = normalizarCodigo(p.codigo);
    const sku = normalizarCodigo(p.sku);
    const barras = normalizarCodigo(p.codigo_barras);
    return codigo === q || sku === q || barras === q;
  }) || null;
}

function imagenProducto(p) {
  return p.imagen_url || p.imagen || p.foto_url || "https://placehold.co/96x96?text=SO";
}

async function init() {
  user = await requireAuth();
  if (!user) return;

  setupLogout();
  perfil = await protegerModulo(user, "ventas");
  if (!perfil) return;

  await cargarClientes();
  await cargarProductos();
  await cargarCajaAbierta();
  configurarEventos();
  configurarCamposCreditoEntrega();
  renderCarrito();
  actualizarBotonAgregarCarrito();
  await cargarDocumentos();
  await cargarHistorialVentas();

  instalarNavegacionPremium();
}

function configurarEventos() {
  const buscadorProducto = $("buscarProductoVenta");
  buscadorProducto?.addEventListener("input", pintarResultados);
  // Importante para lector de código de barras:
  // muchos lectores envían ENTER al final del escaneo. Ese ENTER NO debe enviar el formulario
  // ni registrar la venta; solo debe agregar el producto al carrito y dejar listo el campo.
  buscadorProducto?.addEventListener("keydown", manejarEnterBuscadorProducto);
  $("limpiarProductoVenta")?.addEventListener("click", limpiarSeleccion);
  $("agregarAlCarrito")?.addEventListener("click", () => agregarAlCarrito());
  $("ventaForm")?.addEventListener("submit", registrarVentaCompleta);
  $("recargarDocumentos")?.addEventListener("click", cargarDocumentos);
  $("recibidoVenta")?.addEventListener("input", actualizarCambioVenta);
  $("tipoPago")?.addEventListener("change", actualizarCambioVenta);
  configurarBotonesCambioVenta();
  ["cantidad", "precioUnitario", "descuento"].forEach(id => $(id)?.addEventListener("input", actualizarPreviewSeleccionado));

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".venta-product-search-box")) {
      const res = $("resultadosProductoVenta");
      if (res) {
        res.innerHTML = "";
        res.style.display = "none";
      }
    }
  });
}

async function cargarClientes() {
  const select = $("clienteId");
  if (!select) return;

  const { data, error } = await supabaseClient
    .from("clientes")
    .select("*")
    .order("nombre", { ascending: true });

  if (error) {
    console.warn(error.message);
    select.innerHTML = `<option value="">Cliente CF / sin cliente</option>`;
    return;
  }

  clientes = data || [];
  select.innerHTML = `<option value="">Cliente CF / sin cliente</option>` + clientes.map(c => {
    const nombre = c.nombre_completo || [c.nombre, c.apellido].filter(Boolean).join(" ") || c.nombre || "Cliente";
    const nit = c.nit || "CF";
    return `<option value="${c.id}">${nombre} - ${nit}</option>`;
  }).join("");
}

async function cargarProductos() {
  const { data, error } = await supabaseClient
    .from("inventario_productos")
    .select("*")
    .order("nombre", { ascending: true });

  if (error) {
    console.warn(error.message);
    productos = [];
    return;
  }

  productos = data || [];
}

async function cargarCajaAbierta() {
  const { data } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  cajaActual = data || null;
}

function manejarEnterBuscadorProducto(event) {
  if (event.key !== "Enter") return;

  // Evita que el ENTER del lector dispare el submit del formulario de venta.
  event.preventDefault();
  event.stopPropagation();

  const input = $("buscarProductoVenta");
  const codigo = input?.value?.trim();
  if (!codigo) return;

  const producto = buscarProductoPorCodigoExacto(codigo);

  if (!producto) {
    mostrarMsg("No se encontró producto con ese código.", "error");
    pintarResultados();
    return;
  }

  seleccionarProducto(producto.id);
  agregarAlCarrito({ desdeScanner: true, limpiarInputDespues: true });

  // Deja el buscador listo para escanear el siguiente producto.
  setTimeout(() => {
    const buscador = $("buscarProductoVenta");
    const resultados = $("resultadosProductoVenta");
    if (buscador) {
      buscador.value = "";
      buscador.focus();
    }
    if (resultados) {
      resultados.innerHTML = "";
      resultados.style.display = "none";
    }
  }, 0);
}

function pintarResultados() {
  const input = $("buscarProductoVenta");
  const resultados = $("resultadosProductoVenta");
  if (!input || !resultados) return;

  const q = input.value.toLowerCase().trim();

  if (!q) {
    resultados.innerHTML = "";
    resultados.style.display = "none";
    return;
  }

  const encontrados = productos.filter(p => {
    const texto = `${p.nombre || ""} ${p.sku || ""} ${p.codigo || ""} ${p.codigo_barras || ""} ${p.categoria || ""}`.toLowerCase();
    return texto.includes(q);
  }).slice(0, 12);

  if (!encontrados.length) {
    resultados.innerHTML = `<div class="venta-product-empty">No se encontró ningún producto.</div>`;
    resultados.style.display = "block";
    return;
  }

  resultados.innerHTML = encontrados.map(p => {
    const stock = Number(p.stock || 0);
    const stockClass = stock <= 0 ? "danger" : stock <= Number(p.stock_minimo || 1) ? "warning" : "ok";
    const imagen = imagenProducto(p);
    const precio = precioProducto(p);
    const codigo = codigoProducto(p) || "N/D";

    return `
      <button type="button" class="venta-product-card" data-id="${p.id}">
        <div class="venta-product-card-image-wrap">
          <img src="${imagen}" class="venta-product-card-image" onerror="this.src='https://placehold.co/96x96?text=SO'">
        </div>
        <div class="venta-product-card-content">
          <div class="venta-product-card-top">
            <div class="venta-product-card-info">
              <strong>${p.nombre || "Producto"}</strong>
              <div class="venta-product-card-details">
                <span>SKU/Código: ${codigo}</span>
              </div>
              <small>Categoría: ${p.categoria || "Sin categoría"}</small>
            </div>
            <div class="venta-product-card-side">
              <span class="venta-product-stock ${stockClass}">Stock: ${stock}</span>
              <b>${fmt(precio)}</b>
              <span class="venta-product-select-btn">Seleccionar</span>
            </div>
          </div>
        </div>
      </button>
    `;
  }).join("");

  resultados.style.display = "block";

  resultados.querySelectorAll(".venta-product-card").forEach(btn => {
    btn.addEventListener("click", () => seleccionarProducto(btn.dataset.id));
  });
}

function seleccionarProducto(id) {
  const p = productos.find(x => String(x.id) === String(id));
  if (!p) return;

  productoSeleccionado = p;

  const input = $("buscarProductoVenta");
  const precioInput = $("precioUnitario");
  const info = $("productoSeleccionadoInfo");
  const resultados = $("resultadosProductoVenta");

  if (input) input.value = `${p.nombre || "Producto"}${codigoProducto(p) ? " · " + codigoProducto(p) : ""}`;
  if (precioInput) precioInput.value = precioProducto(p);
  if (info) info.textContent = `Seleccionado: ${p.nombre || "Producto"} · Stock: ${Number(p.stock || 0)}`;

  if (resultados) {
    resultados.innerHTML = "";
    resultados.style.display = "none";
  }

  actualizarPreviewSeleccionado();
  actualizarBotonAgregarCarrito();
}

function actualizarPreviewSeleccionado() {
  if (!productoSeleccionado) return;
  const cantidad = Number($("cantidad")?.value || 1);
  const precio = Number($("precioUnitario")?.value || precioProducto(productoSeleccionado));
  const descuento = Number($("descuento")?.value || 0);
  const total = Math.max(0, (cantidad * precio) - descuento);
  const info = $("productoSeleccionadoInfo");
  if (info) info.textContent = `Seleccionado: ${productoSeleccionado.nombre} · Cantidad: ${cantidad} · Total línea: ${fmt(total)}`;
}

function agregarAlCarrito(opciones = {}) {
  const desdeScanner = opciones?.desdeScanner === true;
  const limpiarInputDespues = opciones?.limpiarInputDespues === true;

  if (!desdeScanner && procesandoAgregarCarritoSOC) return;
  if (!desdeScanner) procesandoAgregarCarritoSOC = true;
  const btnAgregarSOC = document.getElementById("agregarAlCarrito");
  if (!desdeScanner && btnAgregarSOC) {
    btnAgregarSOC.disabled = true;
    btnAgregarSOC.dataset.originalText = btnAgregarSOC.dataset.originalText || btnAgregarSOC.innerHTML;
    btnAgregarSOC.innerHTML = "Agregando...";
  }
  if (!desdeScanner) {
    setTimeout(() => {
      procesandoAgregarCarritoSOC = false;
      if (btnAgregarSOC) {
        btnAgregarSOC.disabled = false;
        btnAgregarSOC.innerHTML = btnAgregarSOC.dataset.originalText || "Agregar al carrito";
      }
    }, 650);
  }
  const msg = $("ventaMsg");
  if (!productoSeleccionado) {
    mostrarMsg("Selecciona un producto primero.", "error");
    return;
  }

  const cantidad = Number($("cantidad")?.value || 1);
  const precio = Number($("precioUnitario")?.value || precioProducto(productoSeleccionado));
  const descuento = Number($("descuento")?.value || 0);

  if (cantidad <= 0) {
    mostrarMsg("La cantidad debe ser mayor a 0.", "error");
    return;
  }

  if (precio <= 0) {
    mostrarMsg("El producto debe tener precio de venta mayor a Q0.00.", "error");
    return;
  }

  if (descuento < 0 || descuento > (cantidad * precio)) {
    mostrarMsg("El descuento no puede ser negativo ni mayor al subtotal.", "error");
    return;
  }

  const stock = Number(productoSeleccionado.stock || 0);
  const yaEnCarrito = carrito
    .filter(i => String(i.producto_id) === String(productoSeleccionado.id))
    .reduce((s, i) => s + Number(i.cantidad || 0), 0);
  const totalSolicitado = yaEnCarrito + cantidad;
  if (totalSolicitado > stock) {
    mostrarMsg(`Stock insuficiente. Disponible: ${stock}, ya en carrito: ${yaEnCarrito}, intentas agregar: ${cantidad}`, "error");
    return;
  }

  const existente = carrito.find(i => String(i.producto_id) === String(productoSeleccionado.id) && Number(i.precio_unitario) === precio);
  if (existente) {
    existente.cantidad += cantidad;
    existente.descuento += descuento;
    existente.total = Math.max(0, (existente.cantidad * existente.precio_unitario) - existente.descuento);
    existente.costo_unitario = Number(existente.costo_unitario || costoProducto(productoSeleccionado) || 0);
  } else {
    carrito.push({
      producto_id: productoSeleccionado.id,
      nombre: productoSeleccionado.nombre || "Producto",
      codigo: codigoProducto(productoSeleccionado),
      categoria: productoSeleccionado.categoria || "",
      imagen_url: imagenProducto(productoSeleccionado),
      cantidad,
      precio_unitario: precio,
      costo_unitario: costoProducto(productoSeleccionado),
      descuento,
      total: Math.max(0, (cantidad * precio) - descuento),
      stock_actual: stock
    });
  }

  limpiarSeleccion(!limpiarInputDespues ? false : true);
  renderCarrito();
  mostrarMsg(desdeScanner ? "Producto escaneado y agregado al carrito." : "Producto agregado al carrito.", "success");
}

function limpiarSeleccion(limpiarInput = true) {
  productoSeleccionado = null;
  if (limpiarInput) $("buscarProductoVenta").value = "";
  $("precioUnitario").value = "";
  $("cantidad").value = 1;
  $("descuento").value = 0;
  const info = $("productoSeleccionadoInfo");
  if (info) info.textContent = "Escribe para buscar productos.";
  actualizarBotonAgregarCarrito();
}

window.quitarProductoCarrito = function(index) {
  carrito.splice(index, 1);
  renderCarrito();
};

window.cambiarCantidadCarrito = function(index, value) {
  const item = carrito[index];
  if (!item) return;
  const cantidad = Math.max(1, Number(value || 1));
  item.cantidad = cantidad;
  item.total = Math.max(0, (item.cantidad * item.precio_unitario) - item.descuento);
  renderCarrito();
};

function calcularTotales() {
  const subtotal = carrito.reduce((s, i) => s + (Number(i.cantidad) * Number(i.precio_unitario)), 0);
  const descuento = carrito.reduce((s, i) => s + Number(i.descuento || 0), 0);
  const total = Math.max(0, subtotal - descuento);
  return { subtotal, descuento, total, cantidadProductos: carrito.reduce((s, i) => s + Number(i.cantidad || 0), 0) };
}

function estadoCambioVenta() {
  const { total } = calcularTotales();
  const tipoPago = $("tipoPago")?.value || "contado";
  const recibido = Number($("recibidoVenta")?.value || 0);
  const vuelto = Math.max(0, recibido - total);
  const faltante = Math.max(0, total - recibido);
  return { total, tipoPago, recibido, vuelto, faltante };
}

function actualizarCambioVenta() {
  const bloque = $("bloqueCambioVenta");
  if (!bloque) return;
  const { total, tipoPago, recibido, vuelto, faltante } = estadoCambioVenta();
  const aplica = tipoPago === "contado";
  bloque.style.display = aplica ? "block" : "none";

  const box = $("vueltoVentaBox");
  const monto = $("vueltoVenta");
  const texto = $("vueltoVentaTexto");
  if (!box || !monto || !texto) return;

  box.classList.remove("falta", "exacto");
  if (!aplica) return;

  if (total <= 0) {
    monto.textContent = fmt(0);
    texto.textContent = "Agrega productos al carrito para calcular el vuelto.";
    return;
  }

  if (recibido <= 0) {
    monto.textContent = fmt(0);
    texto.textContent = "Escribe cuánto entregó el cliente para calcular el vuelto.";
    return;
  }

  if (faltante > 0) {
    box.classList.add("falta");
    monto.textContent = fmt(faltante);
    texto.textContent = `Faltan ${fmt(faltante)} para completar el pago.`;
    return;
  }

  if (vuelto === 0) {
    box.classList.add("exacto");
    monto.textContent = fmt(0);
    texto.textContent = "Pago exacto.";
    return;
  }

  monto.textContent = fmt(vuelto);
  texto.textContent = `Vuelto a entregar: ${fmt(vuelto)}.`;
}

function configurarBotonesCambioVenta() {
  document.querySelectorAll('.soc-billetes-rapidos[data-target="recibidoVenta"] button').forEach(btn => {
    btn.addEventListener("click", () => {
      const input = $("recibidoVenta");
      if (!input) return;
      input.value = Number(btn.dataset.monto || 0).toFixed(2);
      actualizarCambioVenta();
    });
  });
}

function renderCarrito() {
  const cont = $("detalleVentaPreview");
  const { subtotal, descuento, total, cantidadProductos } = calcularTotales();

  $("previewProductos").textContent = cantidadProductos;
  $("previewSubtotal").textContent = fmt(subtotal);
  $("previewDescuento").textContent = fmt(descuento);
  $("previewTotal").textContent = fmt(total);
  actualizarCambioVenta();

  if (!cont) return;

  if (!carrito.length) {
    cont.innerHTML = `<div class="empty-cart">🛒</div><p>Aún no hay productos agregados</p><small>Busca, selecciona y agrega productos al carrito</small>`;
    return;
  }

  cont.innerHTML = `
    <div class="cart-items">
      ${carrito.map((i, index) => `
        <div class="cart-item">
          <img src="${i.imagen_url}" onerror="this.src='https://placehold.co/96x96?text=SO'">
          <div class="cart-item-info">
            <strong>${i.nombre}</strong>
            <small>${i.codigo || ""}</small>
            <div class="cart-qty">
              <span>Cant.</span>
              <input type="number" min="1" value="${i.cantidad}" onchange="cambiarCantidadCarrito(${index}, this.value)">
            </div>
          </div>
          <div class="cart-item-total">
            <b>${fmt(i.total)}</b>
            <button type="button" onclick="quitarProductoCarrito(${index})">×</button>
          </div>
        </div>
      `).join("")}
    </div>
  `;
  actualizarBotonAgregarCarrito();
}


function configurarCamposCreditoEntrega() {
  const tipo = document.getElementById("tipoPago");
  const bloque = document.getElementById("bloqueCreditoEntrega");
  const credito = document.getElementById("camposCredito");
  const entrega = document.getElementById("camposContraEntrega");
  const titulo = document.getElementById("extraTituloVenta");

  if (!tipo || !bloque) return;

  const actualizar = () => {
    const valor = tipo.value;

    bloque.style.display = (valor === "credito" || valor === "contra_entrega") ? "block" : "none";

    if (credito) credito.style.display = valor === "credito" ? "block" : "none";
    if (entrega) entrega.style.display = valor === "contra_entrega" ? "block" : "none";

    if (titulo) {
      titulo.textContent = valor === "credito"
        ? "Datos del crédito"
        : valor === "contra_entrega"
          ? "Datos de contra entrega"
          : "Datos adicionales";
    }
  };

  tipo.addEventListener("change", actualizar);
  actualizar();
}

function clienteNombreSeguro(cliente) {
  if (!cliente) return "Consumidor Final";
  return cliente.nombre_completo || [cliente.nombre, cliente.apellido].filter(Boolean).join(" ") || cliente.nombre || "Cliente";
}

async function crearCreditoVenta({ ventaId, clienteId, total, saldo, nota }) {
  if (!clienteId) {
    throw new Error("Para venta a crédito debes seleccionar un cliente.");
  }

  const totalCredito = Number(total || 0);
  const saldoCredito = Number(saldo ?? totalCredito);
  const estadoCredito = saldoCredito <= 0 ? "pagado" : "pendiente";

  // Corrección v13:
  // Antes de crear un crédito revisamos si ya existe uno para esta venta.
  // Esto evita créditos duplicados cuando el usuario presiona dos veces o cuando se reintenta una venta.
  if (ventaId) {
    const { data: existente, error: buscarError } = await supabaseClient
      .from("creditos")
      .select("id, venta_id, monto_total, saldo, total, monto_pendiente, estado")
      .eq("venta_id", ventaId)
      .maybeSingle();

    if (buscarError) {
      throw new Error("La venta se creó, pero no se pudo verificar si ya tenía crédito: " + buscarError.message);
    }

    if (existente) {
      return existente;
    }
  }

  const payload = {
    venta_id: ventaId,
    cliente_id: clienteId,
    usuario_id: user.id,

    // Compatibilidad con tablas viejas y nuevas
    total: totalCredito,
    saldo: saldoCredito,
    monto_total: totalCredito,
    monto_pendiente: saldoCredito,

    estado: estadoCredito,
    nota: nota || null,
    actualizado_en: new Date().toISOString()
  };

  const { data, error } = await supabaseClient
    .from("creditos")
    .insert([payload])
    .select()
    .single();

  if (error) {
    // Si existe el índice único y se intenta duplicar por accidente, recuperamos el crédito existente.
    if (ventaId && (error.code === "23505" || String(error.message || "").toLowerCase().includes("duplicate"))) {
      const { data: existente } = await supabaseClient
        .from("creditos")
        .select("*")
        .eq("venta_id", ventaId)
        .maybeSingle();
      if (existente) return existente;
    }
    throw new Error("La venta se creó, pero no se pudo crear el crédito: " + error.message);
  }

  return data;
}

async function crearDocumentoVentaSeguro({ ventaId, clienteId, folioVenta, titulo, contenido }) {
  if (!ventaId) return null;

  // Corrección v13:
  // Una venta debe tener un solo documento automático principal.
  // Si ya existe, no lo duplicamos; solo devolvemos el existente.
  const { data: existente, error: buscarError } = await supabaseClient
    .from("documentos_generados")
    .select("id, folio, tipo")
    .eq("referencia_id", ventaId)
    .eq("tipo", "comprobante_venta")
    .maybeSingle();

  if (buscarError) {
    throw new Error("No se pudo verificar el documento de la venta: " + buscarError.message);
  }

  if (existente) return existente;

  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .insert([{
      tipo: "comprobante_venta",
      referencia_id: ventaId,
      cliente_id: clienteId,
      usuario_id: user.id,
      folio: folioVenta,
      titulo: titulo || "Comprobante de venta",
      contenido
    }])
    .select()
    .single();

  if (error) {
    throw new Error("La venta se creó, pero no se pudo crear el documento/comprobante: " + error.message);
  }

  return data;
}

async function crearPedidoContraEntrega({ ventaId, creditoId, clienteId, cajaId, cliente, total, anticipo, saldo, direccion, referencia, telefono, notas }) {
  if (!clienteId) {
    throw new Error("Para contra entrega debes seleccionar un cliente.");
  }

  if (!direccion) {
    throw new Error("Para contra entrega debes escribir la dirección de entrega.");
  }

  const payload = {
    venta_id: ventaId,
    credito_id: creditoId || null,
    cliente_id: clienteId,
    usuario_id: user.id,
    caja_id: cajaId || null,
    direccion_entrega: direccion,
    referencia: referencia || null,
    telefono_contacto: telefono || cliente?.telefono || null,
    estado: "pendiente",
    total: total,
    anticipo: anticipo,
    saldo: saldo,
    notas: notas || null,
    estado_pago: saldo <= 0 ? "pagado" : (anticipo > 0 ? "parcial" : "pendiente")
  };

  const { data, error } = await supabaseClient
    .from("pedidos_entrega")
    .insert([payload])
    .select()
    .single();

  if (error) {
    throw new Error("La venta se creó, pero no se pudo crear el pedido contra entrega: " + error.message);
  }

  return data;
}

async function registrarAnticipoContraEntrega({ ventaId, cliente, cajaId, anticipo }) {
  if (!anticipo || anticipo <= 0) return;

  if (!cajaId) {
    throw new Error("Para registrar anticipo de contra entrega debes tener caja abierta.");
  }

  const { error } = await supabaseClient
    .from("movimientos_caja")
    .insert([{
      caja_id: cajaId,
      usuario_id: user.id,
      tipo: "ingreso",
      categoria: "anticipo_contra_entrega",
      persona: clienteNombreSeguro(cliente),
      monto: anticipo,
      descripcion: `Anticipo de contra entrega`,
      referencia_id: ventaId
    }]);

  if (error) {
    throw new Error("La venta se creó, pero no se pudo registrar el anticipo en caja: " + error.message);
  }
}



async function validarStockCarritoAntesDeVender() {
  if (!carrito.length) {
    return { ok: false, mensaje: "Agrega al menos un producto al carrito." };
  }

  const cantidades = {};
  carrito.forEach(item => {
    cantidades[item.producto_id] = (cantidades[item.producto_id] || 0) + Number(item.cantidad || 0);
  });

  const ids = Object.keys(cantidades);

  const { data, error } = await supabaseClient
    .from("inventario_productos")
    .select("id,nombre,stock")
    .in("id", ids);

  if (error) {
    return { ok: false, mensaje: "No se pudo validar el inventario. Recarga la página e intenta de nuevo." };
  }

  const productosActuales = data || [];

  for (const id of ids) {
    const producto = productosActuales.find(p => String(p.id) === String(id));
    const requerido = Number(cantidades[id] || 0);

    if (!producto) {
      return { ok: false, mensaje: "Uno de los productos ya no existe en inventario." };
    }

    const disponible = Number(producto.stock || 0);

    if (requerido > disponible) {
      return {
        ok: false,
        mensaje: `Stock insuficiente para "${producto.nombre}". Disponible: ${disponible}, solicitado: ${requerido}.`
      };
    }
  }

  return { ok: true, productosActuales };
}

async function descontarStockCarritoSeguro(productosActuales) {
  const cantidades = {};
  carrito.forEach(item => {
    cantidades[item.producto_id] = (cantidades[item.producto_id] || 0) + Number(item.cantidad || 0);
  });

  for (const [productoId, cantidadVendida] of Object.entries(cantidades)) {
    const producto = productosActuales.find(p => String(p.id) === String(productoId));
    if (!producto) continue;

    const nuevoStock = Number(producto.stock || 0) - Number(cantidadVendida || 0);

    const { error } = await supabaseClient
      .from("inventario_productos")
      .update({ stock: nuevoStock })
      .eq("id", productoId);

    if (error) {
      throw new Error("No se pudo descontar stock de " + (producto.nombre || "producto") + ": " + error.message);
    }
  }
}



/* =====================================================
   PROTECCION ANTI DOBLE CLICK / DOBLE VENTA
===================================================== */
let procesandoVentaSOC = false;
let procesandoAgregarCarritoSOC = false;

function setProcesandoVentaSOC(activo, texto = "Procesando venta...") {
  const btn = document.getElementById("btnRegistrarVentaCompleta") || document.querySelector("#ventaForm button[type='submit']");
  if (!btn) return;

  if (activo) {
    btn.dataset.originalText = btn.dataset.originalText || btn.innerHTML;
    btn.disabled = true;
    btn.classList.add("btn-processing");
    btn.innerHTML = `<span class="mini-spinner"></span>${texto}`;
  } else {
    btn.disabled = false;
    btn.classList.remove("btn-processing");
    btn.innerHTML = btn.dataset.originalText || "Registrar venta completa";
  }
}

function crearLlaveVentaSOC() {
  const clienteId = document.getElementById("clienteId")?.value || "CF";
  const tipoPago = document.getElementById("tipoPago")?.value || "contado";
  const items = (carrito || []).map(i => `${i.producto_id}:${i.cantidad}:${i.precio_unitario}`).join("|");
  return `${clienteId}-${tipoPago}-${items}-${Math.round(Date.now() / 4000)}`;
}


async function registrarVentaCompleta(e) {
  e.preventDefault();

  if (procesandoVentaSOC) {
    mostrarMsg("La venta ya se está procesando. Espera un momento.", "warning");
    return;
  }

  const llaveActual = crearLlaveVentaSOC();
  if (ultimaLlaveVentaSOC === llaveActual) {
    mostrarMsg("Esta venta ya fue enviada. Evita presionar dos veces.", "warning");
    return;
  }

  procesandoVentaSOC = true;
  ultimaLlaveVentaSOC = llaveActual;
  setProcesandoVentaSOC(true, "Guardando venta...");

  if (!carrito.length) {
    mostrarMsg("Agrega al menos un producto al carrito.", "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const validacionStock = await validarStockCarritoAntesDeVender();
  if (!validacionStock.ok) {
    mostrarMsg(validacionStock.mensaje, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  await cargarCajaAbierta();

  const clienteId = $("clienteId").value || null;
  const cliente = clientes.find(c => String(c.id) === String(clienteId));
  const tipoPago = $("tipoPago").value;
  const usarCF = $("usarCF")?.checked || false;
  const { subtotal, descuento, total } = calcularTotales();
  const anticipoEntrega = tipoPago === "contra_entrega" ? Number(document.getElementById("anticipoEntrega")?.value || 0) : 0;
  const direccionEntrega = (document.getElementById("direccionEntrega")?.value || "").trim();
  const referenciaEntrega = (document.getElementById("referenciaEntrega")?.value || "").trim();
  const telefonoEntrega = (document.getElementById("telefonoEntrega")?.value || "").trim();
  const notaCredito = (document.getElementById("notaCredito")?.value || "").trim();

  if ((tipoPago === "credito" || tipoPago === "contra_entrega") && !clienteId) {
    mostrarMsg("Selecciona un cliente para crédito o contra entrega.", "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  if (tipoPago === "contra_entrega" && !direccionEntrega) {
    mostrarMsg("Escribe la dirección de entrega.", "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  if (anticipoEntrega < 0 || anticipoEntrega > total) {
    mostrarMsg("El anticipo no puede ser negativo ni mayor al total.", "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const recibidoVenta = tipoPago === "contado" ? Number($("recibidoVenta")?.value || 0) : 0;
  const vueltoVenta = tipoPago === "contado" ? Math.max(0, recibidoVenta - total) : 0;

  if (tipoPago === "contado" && recibidoVenta > 0 && recibidoVenta < total) {
    mostrarMsg(`Faltan ${fmt(total - recibidoVenta)} para completar el pago.`, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const ingresoCaja = tipoPago === "contado" ? total : (tipoPago === "contra_entrega" ? anticipoEntrega : 0);
  const saldo = tipoPago === "contado" ? 0 : Math.max(0, total - ingresoCaja);

  if ((tipoPago === "contado" || ingresoCaja > 0) && !cajaActual) {
    mostrarMsg("Primero debes abrir caja para registrar este cobro.", "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const folioVenta = `VTA-${Date.now()}`;
  const gananciaTotalVenta = carrito.reduce((sum, item) => {
    const cantidadItem = Number(item.cantidad || 0);
    const totalItem = Number(item.total || 0);
    const costoItem = Number(item.costo_unitario || 0) * cantidadItem;
    return sum + (totalItem - costoItem);
  }, 0);

  const ventaPayload = {
    cliente_id: clienteId,
    usuario_id: user.id,
    tipo_pago: tipoPago,
    subtotal,
    descuento,
    total,
    ganancia_total: gananciaTotalVenta,
    saldo,
    estado: tipoPago === "contado" ? "pagada" : (tipoPago === "credito" ? "credito" : "contra_entrega"),
    folio: folioVenta
  };

  const { data: venta, error: ventaError } = await supabaseClient
    .from("ventas")
    .insert([ventaPayload])
    .select()
    .single();

  if (ventaError) {
    mostrarMsg("No se pudo registrar la venta: " + ventaError.message, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const ventaId = venta.id;

  const detalles = carrito.map(i => {
    const cantidadItem = Number(i.cantidad || 0);
    const costoUnitario = Number(i.costo_unitario || 0);
    const gananciaTotal = Number(i.total || 0) - (costoUnitario * cantidadItem);
    const gananciaUnitaria = cantidadItem > 0 ? gananciaTotal / cantidadItem : 0;
    return {
      venta_id: ventaId,
      producto_id: i.producto_id,
      nombre_producto: i.nombre || "Producto",
      producto_nombre: i.nombre || "Producto",
      cantidad: i.cantidad,
      precio_unitario: i.precio_unitario,
      costo_unitario: costoUnitario,
      ganancia_unitaria: gananciaUnitaria,
      ganancia_total: gananciaTotal,
      descuento: i.descuento,
      total: i.total
    };
  });

  const { error: detalleError } = await supabaseClient
    .from("detalle_ventas")
    .insert(detalles);

  if (detalleError) {
    mostrarMsg("Venta creada, pero falló detalle: " + detalleError.message, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  try {
    await descontarStockCarritoSeguro(validacionStock.productosActuales || []);
  } catch (err) {
    mostrarMsg(err.message, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  if (tipoPago === "contado" && ingresoCaja > 0 && cajaActual) {
    const { error: cajaError } = await supabaseClient.from("movimientos_caja").insert([{
      caja_id: cajaActual.id,
      usuario_id: user.id,
      tipo: "ingreso",
      categoria: "venta",
      monto: ingresoCaja,
      descripcion: `Venta ${folioVenta}`,
      referencia_id: ventaId
    }]);

    if (cajaError) {
      mostrarMsg("Venta guardada, pero no se pudo sumar a caja: " + cajaError.message, "error");
      return;
    }
  }

  let creditoCreado = null;
  let pedidoCreado = null;

  try {
    if (tipoPago === "credito") {
      creditoCreado = await crearCreditoVenta({
        ventaId,
        clienteId,
        total,
        saldo,
        nota: notaCredito
      });
    }

    if (tipoPago === "contra_entrega") {
      if (anticipoEntrega > 0) {
        await registrarAnticipoContraEntrega({
          ventaId,
          cliente,
          cajaId: cajaActual?.id,
          anticipo: anticipoEntrega
        });
      }

      // También se crea crédito interno si queda saldo pendiente.
      if (saldo > 0) {
        creditoCreado = await crearCreditoVenta({
          ventaId,
          clienteId,
          total,
          saldo,
          nota: "Saldo generado por venta contra entrega"
        });
      }

      pedidoCreado = await crearPedidoContraEntrega({
        ventaId,
        creditoId: creditoCreado?.id || null,
        clienteId,
        cajaId: cajaActual?.id || null,
        cliente,
        total,
        anticipo: anticipoEntrega,
        saldo,
        direccion: direccionEntrega,
        referencia: referenciaEntrega,
        telefono: telefonoEntrega,
        notas: carrito.map(i => `${i.nombre} x${i.cantidad}`).join(", ")
      });
    }
  } catch (err) {
    mostrarMsg(err.message, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  const clienteNombre = usarCF ? "Consumidor Final" : (cliente?.nombre_completo || [cliente?.nombre, cliente?.apellido].filter(Boolean).join(" ") || cliente?.nombre || "Consumidor Final");
  const nit = usarCF ? "CF" : (cliente?.nit || "CF");

  const contenidoDocumento = {
    folio: folioVenta,
    venta_id: ventaId,
    cliente: clienteNombre,
    nit,
    producto: carrito.map(i => `${i.nombre} x${i.cantidad}`).join(", "),
    cantidad: carrito.reduce((s,i)=>s+Number(i.cantidad),0),
    precio_unitario: 0,
    total,
    ganancia_total: gananciaTotalVenta,
    saldo,
    recibido: recibidoVenta,
    vuelto: vueltoVenta,
    pagado: ingresoCaja,
    tipo_pago: tipoPago,
    fecha: new Date().toISOString(),
    items: carrito,
    credito_id: creditoCreado?.id || null,
    pedido_entrega_id: pedidoCreado?.id || null,
    direccion_entrega: direccionEntrega || null,
    anticipo: ingresoCaja
  };

  try {
    await crearDocumentoVentaSeguro({
      ventaId,
      clienteId,
      folioVenta,
      titulo: tipoPago === "credito" ? "Comprobante de venta a crédito" : "Comprobante de venta",
      contenido: contenidoDocumento
    });
  } catch (err) {
    mostrarMsg(err.message, "error");
    procesandoVentaSOC = false;
    setProcesandoVentaSOC(false);
    return;
  }

  try {
    await supabaseClient.from("facturas").insert([{
      venta_id: ventaId,
      cliente_id: clienteId,
      usuario_id: user.id,
      tipo: "interna",
      estado: nit === "CF" ? "pendiente_fel" : "emitida",
      folio: `SO-F-${Date.now()}`,
      cliente_nombre: clienteNombre,
      nit,
      total,
      saldo,
      contenido: contenidoDocumento,
      consumidor_final: nit === "CF"
    }]);
  } catch(err) {
    console.warn("Factura interna no creada:", err);
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "ventas",
    accion: "registrar_venta",
    descripcion: `${tipoPago} · ${carrito.length} productos · Total ${fmt(total)}`,
    referencia_id: ventaId
  });

  mostrarMsg(`Venta registrada correctamente. Total: ${fmt(total)}`, "success");
  abrirComprobanteVenta(contenidoDocumento);

  carrito = [];
  productoSeleccionado = null;
  $("ventaForm").reset();
  $("direccionEntrega") && ($("direccionEntrega").value = "");
  $("referenciaEntrega") && ($("referenciaEntrega").value = "");
  $("telefonoEntrega") && ($("telefonoEntrega").value = "");
  $("anticipoEntrega") && ($("anticipoEntrega").value = 0);
  $("notaCredito") && ($("notaCredito").value = "");
  $("recibidoVenta") && ($("recibidoVenta").value = "");
  actualizarCambioVenta();
  configurarCamposCreditoEntrega();
  $("cantidad").value = 1;
  $("descuento").value = 0;
  renderCarrito();
  actualizarBotonAgregarCarrito();
  await cargarProductos();
  await cargarDocumentos();
  procesandoVentaSOC = false;
  setProcesandoVentaSOC(false);
}

async function cargarDocumentos() {
  const tabla = $("documentosTabla");
  if (!tabla) return;

  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .select("*")
    .eq("tipo", "comprobante_venta")
    .order("creado_en", { ascending: false })
    .limit(10);

  if (error) {
    tabla.innerHTML = `<tr><td colspan="5">No se pudieron cargar comprobantes.</td></tr>`;
    return;
  }

  const docs = data || [];

  if (!docs.length) {
    tabla.innerHTML = `<tr><td colspan="5">No hay comprobantes todavía.</td></tr>`;
    return;
  }

  tabla.innerHTML = docs.map(d => `
    <tr>
      <td>${d.creado_en ? new Date(d.creado_en).toLocaleString("es-GT") : "-"}</td>
      <td>${d.folio || "-"}</td>
      <td>${d.contenido?.cliente || "-"}</td>
      <td>${fmt(d.contenido?.total || 0)}</td>
      <td><button class="btn btn-small" type="button" onclick="verComprobanteVenta(\'${d.id}\')">Ver</button></td>
    </tr>
  `).join("");
}

function mostrarMsg(texto, tipo = "") {
  const msg = $("ventaMsg");
  if (!msg) return;
  msg.textContent = texto;
  msg.className = `message ${tipo}`;
}

init();


/* =====================================================
   HISTORIAL Y DETALLE DE VENTAS
===================================================== */

let historialVentas = [];

async function cargarHistorialVentas() {
  const tabla = document.getElementById("ventasHistorialTabla");
  if (!tabla) return;

  const { data, error } = await supabaseClient
    .from("ventas")
    .select("*")
    .order("creado_en", { ascending: false })
    .limit(80);

  if (error) {
    tabla.innerHTML = `<tr><td colspan="7">No se pudieron cargar ventas: ${error.message}</td></tr>`;
    return;
  }

  historialVentas = data || [];
  await unirClientesHistorial();
  renderHistorialVentas();
}

async function unirClientesHistorial() {
  const ids = [...new Set(historialVentas.map(v => v.cliente_id).filter(Boolean))];
  if (!ids.length) return;

  const { data, error } = await supabaseClient
    .from("clientes")
    .select("*")
    .in("id", ids);

  if (error) return;

  const mapa = {};
  (data || []).forEach(c => mapa[c.id] = c);

  historialVentas = historialVentas.map(v => ({
    ...v,
    cliente: mapa[v.cliente_id] || null
  }));
}

function nombreClienteVenta(v) {
  const c = v.cliente || {};
  return (
    c.nombre_completo ||
    [c.nombre, c.apellido].filter(Boolean).join(" ") ||
    c.nombre ||
    v.cliente_nombre ||
    "Consumidor Final"
  );
}

function renderHistorialVentas() {
  const tabla = document.getElementById("ventasHistorialTabla");
  if (!tabla) return;

  if (!historialVentas.length) {
    tabla.innerHTML = `<tr><td colspan="7">No hay ventas registradas todavía.</td></tr>`;
    return;
  }

  tabla.innerHTML = historialVentas.map(v => `
    <tr>
      <td>${v.creado_en ? new Date(v.creado_en).toLocaleString("es-GT") : "-"}</td>
      <td><strong>${v.folio || v.id?.slice(0, 8) || "-"}</strong></td>
      <td>${nombreClienteVenta(v)}</td>
      <td><span class="badge info">${formatearTipoPagoVenta(v.tipo_pago)}</span></td>
      <td><strong>${fmt(v.total || 0)}</strong></td>
      <td><span class="badge ${estadoVentaClase(v.estado)}">${formatearEstadoVenta(v.estado)}</span></td>
      <td>
        <button class="btn btn-small" type="button" onclick="verDetalleVenta('${v.id}')">
          Ver detalle
        </button>
      </td>
    </tr>
  `).join("");
}

window.verDetalleVenta = async function(ventaId) {
  const venta = historialVentas.find(v => String(v.id) === String(ventaId));

  const { data, error } = await supabaseClient
    .from("detalle_ventas")
    .select("*")
    .eq("venta_id", ventaId);

  if (error) {
    alert("No se pudo cargar el detalle: " + error.message);
    return;
  }

  const detalles = data || [];

  document.getElementById("detalleVentaTitulo").textContent = `Venta ${venta?.folio || ventaId.slice(0, 8)}`;
  document.getElementById("detalleVentaSubtitulo").textContent = `${nombreClienteVenta(venta || {})} · ${venta?.creado_en ? new Date(venta.creado_en).toLocaleString("es-GT") : ""}`;

  document.getElementById("detalleVentaResumen").innerHTML = `
    <div class="summary-lines">
      <div><span>Cliente</span><strong>${nombreClienteVenta(venta || {})}</strong></div>
      <div><span>Tipo pago</span><strong>${formatearTipoPagoVenta(venta?.tipo_pago)}</strong></div>
      <div><span>Estado</span><strong>${formatearEstadoVenta(venta?.estado)}</strong></div>
      <div><span>Subtotal</span><strong>${fmt(venta?.subtotal || 0)}</strong></div>
      <div><span>Descuento</span><strong>${fmt(venta?.descuento || 0)}</strong></div>
      <div><span>Total</span><strong>${fmt(venta?.total || 0)}</strong></div>
    </div>
  `;

  const tabla = document.getElementById("detalleVentaProductosTabla");

  if (!detalles.length) {
    tabla.innerHTML = `<tr><td colspan="5">Esta venta no tiene productos en detalle_ventas.</td></tr>`;
  } else {
    tabla.innerHTML = detalles.map(d => {
      const nombre = d.nombre_producto || d.producto_nombre || d.nombre || "Producto";
      const cantidad = Number(d.cantidad || 0);
      const precio = Number(d.precio_unitario || d.precio || 0);
      const descuento = Number(d.descuento || 0);
      const total = Number(d.total || (cantidad * precio) - descuento || 0);

      return `
        <tr>
          <td><strong>${nombre}</strong><br><small>${d.producto_id || ""}</small></td>
          <td>${cantidad}</td>
          <td>${fmt(precio)}</td>
          <td>${fmt(descuento)}</td>
          <td><strong>${fmt(total)}</strong></td>
        </tr>
      `;
    }).join("");
  }

  document.getElementById("detalleVentaModal").hidden = false;
};

function cerrarDetalleVentaModal() {
  const modal = document.getElementById("detalleVentaModal");
  if (modal) modal.hidden = true;
}

function formatearTipoPagoVenta(tipo) {
  const map = {
    contado: "Contado",
    credito: "Crédito",
    contra_entrega: "Contra entrega"
  };
  return map[tipo] || tipo || "-";
}

function formatearEstadoVenta(estado) {
  const map = {
    pagada: "Pagada",
    pendiente: "Pendiente",
    anulada: "Anulada",
    devuelta: "Devuelta",
    completada: "Completada"
  };
  return map[estado] || estado || "-";
}

function estadoVentaClase(estado) {
  if (estado === "pagada" || estado === "completada") return "ok";
  if (estado === "pendiente") return "warning";
  if (estado === "devuelta" || estado === "anulada") return "danger";
  return "info";
}

function instalarHistorialVentasUI() {
  document.getElementById("recargarVentas")?.addEventListener("click", cargarHistorialVentas);
  document.getElementById("cerrarDetalleVenta")?.addEventListener("click", cerrarDetalleVentaModal);
  document.getElementById("cerrarDetalleVentaFooter")?.addEventListener("click", cerrarDetalleVentaModal);

  document.getElementById("detalleVentaModal")?.addEventListener("click", e => {
    if (e.target.id === "detalleVentaModal") cerrarDetalleVentaModal();
  });

  cargarHistorialVentas();
}

// Intentos seguros por si init ya corrió antes.
setTimeout(instalarHistorialVentasUI, 500);
setTimeout(cargarHistorialVentas, 1500);


/* =====================================================
   FIX COMPROBANTES / FACTURA INTERNA EN VENTAS
===================================================== */

let ultimoComprobanteHTMLVentas = "";
let ultimoComprobanteDataVentas = null;

function htmlComprobanteVentaSOC(doc = {}) {
  const items = Array.isArray(doc.items) ? doc.items : [];
  const fecha = doc.fecha ? new Date(doc.fecha).toLocaleString("es-GT") : new Date().toLocaleString("es-GT");
  const total = Number(doc.total || 0);
  const pagado = Number(doc.pagado || 0);
  const saldo = Number(doc.saldo || 0);

  const filas = items.length
    ? items.map(i => `
      <tr>
        <td>${i.nombre || i.producto_nombre || "Producto"}</td>
        <td style="text-align:center;">${Number(i.cantidad || 0)}</td>
        <td style="text-align:right;">Q ${Number(i.precio_unitario || 0).toFixed(2)}</td>
        <td style="text-align:right;">Q ${Number(i.descuento || 0).toFixed(2)}</td>
        <td style="text-align:right;"><strong>Q ${Number(i.total || 0).toFixed(2)}</strong></td>
      </tr>
    `).join("")
    : `
      <tr>
        <td>${doc.producto || "Producto / servicio"}</td>
        <td style="text-align:center;">${Number(doc.cantidad || 1)}</td>
        <td style="text-align:right;">Q ${Number(doc.precio_unitario || total).toFixed(2)}</td>
        <td style="text-align:right;">Q 0.00</td>
        <td style="text-align:right;"><strong>Q ${total.toFixed(2)}</strong></td>
      </tr>
    `;

  return `
    <div class="soc-ticket">
      <div class="soc-ticket-head">
        <div>
          <h1>Service Office</h1>
          <p>Soluciones tecnológicas para todos</p>
        </div>
        <div class="soc-ticket-folio">
          <strong>${doc.folio || "Comprobante"}</strong>
          <span>${fecha}</span>
        </div>
      </div>

      <div class="soc-ticket-info">
        <div><span>Cliente</span><strong>${doc.cliente || "Consumidor Final"}</strong></div>
        <div><span>NIT</span><strong>${doc.nit || "CF"}</strong></div>
        <div><span>Tipo pago</span><strong>${doc.tipo_pago || doc.metodo_pago || "-"}</strong></div>
        <div><span>Estado</span><strong>${doc.estado || (saldo > 0 ? "Pendiente" : "Pagado")}</strong></div>
      </div>

      <table class="soc-ticket-table">
        <thead>
          <tr>
            <th>Producto</th>
            <th style="text-align:center;">Cant.</th>
            <th style="text-align:right;">Precio</th>
            <th style="text-align:right;">Desc.</th>
            <th style="text-align:right;">Total</th>
          </tr>
        </thead>
        <tbody>${filas}</tbody>
      </table>

      <div class="soc-ticket-totals">
        <div><span>Total</span><strong>Q ${total.toFixed(2)}</strong></div>
        <div><span>Pagado</span><strong>Q ${pagado.toFixed(2)}</strong></div>
        <div><span>Saldo</span><strong>Q ${saldo.toFixed(2)}</strong></div>
      </div>

      <div class="soc-ticket-footer">
        <p>Documento generado automáticamente por Service Office Control.</p>
      </div>
    </div>
  `;
}

function abrirComprobanteVenta(doc = {}) {
  const modal = document.getElementById("comprobanteVentaModal");
  const preview = document.getElementById("comprobanteVentaPreview");
  const titulo = document.getElementById("comprobanteVentaTitulo");
  const sub = document.getElementById("comprobanteVentaSubtitulo");

  if (!modal || !preview) return;

  ultimoComprobanteDataVentas = doc;
  ultimoComprobanteHTMLVentas = htmlComprobanteVentaSOC(doc);
  preview.innerHTML = ultimoComprobanteHTMLVentas;
  if (titulo) titulo.textContent = doc.folio ? `Comprobante ${doc.folio}` : "Comprobante de venta";
  if (sub) sub.textContent = `${doc.cliente || "Consumidor Final"} · Q ${Number(doc.total || 0).toFixed(2)}`;

  modal.hidden = false;
}

function cerrarComprobanteVentaModal() {
  const modal = document.getElementById("comprobanteVentaModal");
  if (modal) modal.hidden = true;
}

function imprimirComprobanteVentaActual() {
  if (!ultimoComprobanteHTMLVentas) return;

  const w = window.open("", "_blank", "width=900,height=900");
  w.document.write(`
    <html>
      <head>
        <title>Comprobante Service Office</title>
        <style>
          body{font-family:Arial,sans-serif;padding:20px;background:#fff;color:#111}
          .soc-ticket{max-width:760px;margin:auto;border:1px solid #ddd;border-radius:16px;padding:24px}
          .soc-ticket-head{display:flex;justify-content:space-between;border-bottom:3px solid #e50914;padding-bottom:14px;margin-bottom:16px}
          .soc-ticket-head h1{margin:0;color:#e50914;text-transform:uppercase}
          .soc-ticket-head p{margin:4px 0;color:#555}
          .soc-ticket-folio{text-align:right;display:flex;flex-direction:column;gap:4px}
          .soc-ticket-info{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:16px 0}
          .soc-ticket-info div{background:#f7f7f7;padding:10px;border-radius:10px}
          .soc-ticket-info span{display:block;color:#666;font-size:12px}
          table{width:100%;border-collapse:collapse;margin-top:14px}
          th{background:#111;color:#fff;padding:9px;text-align:left}
          td{border-bottom:1px solid #eee;padding:9px}
          .soc-ticket-totals{margin-left:auto;margin-top:18px;max-width:300px;background:#f7f7f7;border-radius:12px;padding:12px}
          .soc-ticket-totals div{display:flex;justify-content:space-between;margin:6px 0}
          .soc-ticket-footer{margin-top:20px;text-align:center;color:#555;font-size:12px}
        </style>
      </head>
      <body>${ultimoComprobanteHTMLVentas}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}


function htmlTicketTermicoVenta(doc = {}) {
  const configTicket = getTicketConfig();
  const items = Array.isArray(doc.items) ? doc.items : [];
  const fecha = doc.fecha ? new Date(doc.fecha).toLocaleString("es-GT") : new Date().toLocaleString("es-GT");
  const total = Number(doc.total || 0);
  const pagado = Number(doc.pagado || 0);
  const saldo = Number(doc.saldo || 0);
  const filas = items.length ? items.map(i => `
    <div class="tt-item tt-product-row">
      <div class="tt-qty">${Number(i.cantidad || 1)}</div>
      <div class="tt-product-name"><strong>${i.nombre || i.producto_nombre || "Producto"}</strong>${(configTicket.mostrarSku && i.sku) ? `<small>SKU: ${i.sku}</small>` : ""}</div>
      <div class="tt-product-total"><strong>Q ${Number(i.total || 0).toFixed(2)}</strong></div>
    </div>
  `).join("") : `
    <div class="tt-item tt-product-row">
      <div class="tt-qty">1</div>
      <div class="tt-product-name"><strong>${doc.producto || "Producto / servicio"}</strong></div>
      <div class="tt-product-total"><strong>Q ${total.toFixed(2)}</strong></div>
    </div>
  `;
  const cajero = doc.cajero || doc.usuario || doc.vendedor || "-";
  const telefonoCliente = doc.telefono || doc.cliente_telefono || "-";
  return `
    <div class="thermal-ticket ticket-premium">
      ${ticketHeaderHtml(configTicket)}
      <div class="tt-line"></div>
      <div class="tt-row"><span>Folio:</span><strong>${doc.folio || "-"}</strong></div>
      <div class="tt-row"><span>Fecha:</span><span>${fecha}</span></div>
      ${configTicket.mostrarCajero ? `<div class="tt-row"><span>Cajero:</span><span>${cajero}</span></div>` : ""}
      <div class="tt-line"></div>
      ${configTicket.mostrarCliente ? `<div class="tt-row"><span>Cliente:</span><strong>${doc.cliente || "Consumidor Final"}</strong></div>` : ""}
      <div class="tt-row"><span>Teléfono:</span><span>${telefonoCliente}</span></div>
      ${configTicket.mostrarNit ? `<div class="tt-row"><span>NIT:</span><span>${doc.nit || "CF"}</span></div>` : ""}
      <div class="tt-line"></div>
      <div class="tt-head-row"><span>CANT.</span><span>DESCRIPCIÓN</span><span>TOTAL</span></div>
      ${filas}
      <div class="tt-line"></div>
      <div class="tt-row"><span>Subtotal:</span><strong>Q ${total.toFixed(2)}</strong></div>
      <div class="tt-row"><span>Descuento:</span><strong>Q ${Number(doc.descuento || 0).toFixed(2)}</strong></div>
      <div class="tt-row tt-total"><span>TOTAL:</span><strong>Q ${total.toFixed(2)}</strong></div>
      <div class="tt-line"></div>
      <div class="tt-row"><span>Forma de pago:</span><strong>${String(doc.tipo_pago || doc.metodo_pago || "-").toUpperCase()}</strong></div>
      ${Number(doc.recibido || 0) ? `<div class="tt-row"><span>Recibido:</span><strong>Q ${Number(doc.recibido || 0).toFixed(2)}</strong></div>` : ""}
      ${Number(doc.vuelto || 0) ? `<div class="tt-row"><span>Vuelto:</span><strong>Q ${Number(doc.vuelto || 0).toFixed(2)}</strong></div>` : ""}
      ${pagado ? `<div class="tt-row"><span>Pagado:</span><strong>Q ${pagado.toFixed(2)}</strong></div>` : ""}
      ${saldo ? `<div class="tt-balance"><span>Saldo pendiente:</span><strong>Q ${saldo.toFixed(2)}</strong></div>` : ""}
      <div class="tt-line"></div>
      ${ticketFooterHtml(configTicket)}
    </div>
  `;
}

function imprimirTicketTermicoVentaActual() {
  if (!ultimoComprobanteDataVentas) return alert("Primero abre o genera un comprobante.");
  const html = htmlTicketTermicoVenta(ultimoComprobanteDataVentas);
  imprimirHTMLTicketTermico("Ticket Service Office", html);
}

function imprimirHTMLTicketTermico(titulo, html) {
  const w = window.open("", "_blank", "width=420,height=720");
  w.document.write(`
    <html><head><title>${titulo}</title><style>${ticketPrintStyles()}</style></head><body>${html}<script>setTimeout(()=>window.print(),250)</script></body></html>
  `);
  w.document.close();
  w.focus();
}

function instalarModalComprobantesVentas() {
  document.getElementById("cerrarComprobanteVenta")?.addEventListener("click", cerrarComprobanteVentaModal);
  document.getElementById("cerrarComprobanteVentaFooter")?.addEventListener("click", cerrarComprobanteVentaModal);
  document.getElementById("imprimirComprobanteVenta")?.addEventListener("click", imprimirComprobanteVentaActual);
  document.getElementById("imprimirTicketTermicoVenta")?.addEventListener("click", imprimirTicketTermicoVentaActual);
  document.getElementById("comprobanteVentaModal")?.addEventListener("click", e => {
    if (e.target.id === "comprobanteVentaModal") cerrarComprobanteVentaModal();
  });
}

async function enriquecerComprobanteVentaDesdeBD(documento) {
  const contenido = documento?.contenido || {};
  const ventaId = documento?.referencia_id || contenido.venta_id || contenido.referencia_id || null;

  if (!ventaId) {
    return contenido;
  }

  let venta = null;
  try {
    const { data: ventaData } = await supabaseClient
      .from("ventas")
      .select("*")
      .eq("id", ventaId)
      .maybeSingle();
    venta = ventaData || null;
  } catch (err) {
    console.warn("No se pudo cargar la venta del comprobante:", err);
  }

  let cliente = null;
  const clienteId = venta?.cliente_id || contenido.cliente_id || documento?.cliente_id || null;
  if (clienteId) {
    try {
      const { data: clienteData } = await supabaseClient
        .from("clientes")
        .select("*")
        .eq("id", clienteId)
        .maybeSingle();
      cliente = clienteData || null;
    } catch (err) {
      console.warn("No se pudo cargar el cliente del comprobante:", err);
    }
  }

  let detalles = [];
  try {
    const { data: detallesData } = await supabaseClient
      .from("detalle_ventas")
      .select("*")
      .eq("venta_id", ventaId);
    detalles = detallesData || [];
  } catch (err) {
    console.warn("No se pudo cargar el detalle de venta del comprobante:", err);
  }

  const nombreClienteReal = cliente
    ? (cliente.nombre_completo || [cliente.nombre, cliente.apellido].filter(Boolean).join(" ") || cliente.nombre || "Consumidor Final")
    : (contenido.cliente || contenido.cliente_nombre || "Consumidor Final");

  const nitReal = cliente
    ? (cliente.nit || cliente.cui || "CF")
    : (contenido.nit || "CF");

  const items = detalles.length
    ? detalles.map(d => ({
        nombre: d.nombre_producto || d.producto_nombre || d.nombre || "Producto / servicio",
        producto_nombre: d.producto_nombre || d.nombre_producto || d.nombre || "Producto / servicio",
        cantidad: Number(d.cantidad || 1),
        precio_unitario: Number(d.precio_unitario || d.precio || 0),
        descuento: Number(d.descuento || 0),
        total: Number(d.total || 0)
      }))
    : (Array.isArray(contenido.items) ? contenido.items : []);

  return {
    ...contenido,
    venta_id: ventaId,
    folio: venta?.folio || contenido.folio || documento?.folio || "Comprobante",
    cliente: nombreClienteReal,
    nit: nitReal,
    total: Number(venta?.total ?? contenido.total ?? 0),
    saldo: Number(contenido.saldo ?? venta?.saldo ?? (venta?.tipo_pago === "credito" ? venta?.total : 0) ?? 0),
    pagado: Number(contenido.pagado ?? 0),
    tipo_pago: venta?.tipo_pago || contenido.tipo_pago || contenido.metodo_pago || "-",
    metodo_pago: venta?.tipo_pago || contenido.metodo_pago || contenido.tipo_pago || "-",
    estado: venta?.estado || contenido.estado || "-",
    fecha: venta?.creado_en || contenido.fecha || documento?.creado_en || new Date().toISOString(),
    items
  };
}

window.verComprobanteVenta = async function(id) {
  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (error || !data) {
    alert("No se pudo abrir el comprobante.");
    return;
  }

  const contenidoCorregido = await enriquecerComprobanteVentaDesdeBD(data);
  abrirComprobanteVenta(contenidoCorregido);
};

setTimeout(instalarModalComprobantesVentas, 500);
