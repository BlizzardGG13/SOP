import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";
import { htmlReciboAbonoCredito, abrirPDFDesdeHTML } from "./documentos-utils.js";

let user = null;
let perfil = null;
let creditos = [];
let clientes = [];
let ventas = [];
let abonos = [];
let cajaActual = null;
let creditoSeleccionado = null;

const $ = id => document.getElementById(id);
function folioAbonoCreditoSOC() {
  return "SO-AB-" + Date.now();
}

const fmt = n => (typeof money === "function" ? money(Number(n || 0)) : `Q${Number(n || 0).toFixed(2)}`);

async function init() {
  user = await requireAuth();
  if (!user) return;

  setupLogout();
  perfil = await protegerModulo(user, "creditos");
  if (!perfil) return;

  $("buscarCredito")?.addEventListener("input", renderCreditos);
  $("cerrarAbonoModal")?.addEventListener("click", cerrarAbonoModal);
  $("abonoModal")?.addEventListener("click", e => {
    if (e.target.id === "abonoModal") cerrarAbonoModal();
  });
  $("abonoForm")?.addEventListener("submit", registrarAbono);
  $("cerrarHistorial")?.addEventListener("click", () => {
    $("historialAbonosPanel").style.display = "none";
  });
  $("recargarHistorialClientes")?.addEventListener("click", renderHistorialClientes);
  $("cerrarDetalleClienteCredito")?.addEventListener("click", () => $("detalleClienteCreditoPanel").style.display = "none");
  $("cerrarAbonoClienteModal")?.addEventListener("click", cerrarAbonoClienteModal);
  $("abonoClienteModal")?.addEventListener("click", e => { if (e.target.id === "abonoClienteModal") cerrarAbonoClienteModal(); });
  $("abonoClienteForm")?.addEventListener("submit", registrarAbonoCliente);

  await cargarTodo();
  instalarNavegacionPremium();
}

async function cargarTodo() {
  await cargarCaja();
  await cargarCreditos();
  await cargarAbonos();
  resumen();
  renderHistorialClientes();
}

async function cargarCaja() {
  const { data, error } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    $("estadoCaja").textContent = "Error caja";
    $("estadoCaja").className = "status-pill danger";
    return;
  }

  cajaActual = data || null;

  if (cajaActual) {
    $("estadoCaja").textContent = "Caja abierta";
    $("estadoCaja").className = "status-pill ok";
  } else {
    $("estadoCaja").textContent = "Caja cerrada";
    $("estadoCaja").className = "status-pill danger";
  }
}

async function cargarCreditos() {
  const tabla = $("creditosTabla");

  const { data, error } = await supabaseClient
    .from("creditos")
    .select("*")
    .order("creado_en", { ascending: false });

  if (error) {
    tabla.innerHTML = `<tr><td colspan="7">No se pudieron cargar créditos: ${error.message}</td></tr>`;
    return;
  }

  creditos = data || [];

  await unirClientes();
  await unirVentas();

  renderCreditos();
}

async function unirClientes() {
  const ids = [...new Set(creditos.map(c => c.cliente_id).filter(Boolean))];
  if (!ids.length) return;

  const { data } = await supabaseClient
    .from("clientes")
    .select("*")
    .in("id", ids);

  clientes = data || [];
  const mapa = {};
  clientes.forEach(c => mapa[c.id] = c);

  creditos = creditos.map(c => ({ ...c, cliente: mapa[c.cliente_id] || null }));
}

async function unirVentas() {
  const ids = [...new Set(creditos.map(c => c.venta_id).filter(Boolean))];
  if (!ids.length) return;

  const { data } = await supabaseClient
    .from("ventas")
    .select("*")
    .in("id", ids);

  ventas = data || [];
  const mapa = {};
  ventas.forEach(v => mapa[v.id] = v);

  creditos = creditos.map(c => ({ ...c, venta: mapa[c.venta_id] || null }));
}

async function cargarAbonos() {
  const { data, error } = await supabaseClient
    .from("abonos_credito")
    .select("*")
    .order("creado_en", { ascending: false });

  if (error) {
    console.warn(error.message);
    abonos = [];
    return;
  }

  abonos = data || [];
}

function nombreCliente(c) {
  const cl = c.cliente || {};
  return cl.nombre_completo || [cl.nombre, cl.apellido].filter(Boolean).join(" ") || cl.nombre || "Cliente";
}

function nitCliente(c) {
  return c.cliente?.nit || "CF";
}

function montoTotalCredito(c) {
  return Number(c.monto_total ?? c.total ?? 0);
}

function saldoCredito(c) {
  const total = montoTotalCredito(c);
  const saldoRaw = c.monto_pendiente ?? c.saldo;

  // Corrección para créditos viejos creados con saldo 0 por error.
  // Si la venta es de tipo crédito y no hay abonos, el saldo debe ser el total.
  const abonosCredito = abonos.filter(a => String(a.credito_id) === String(c.id));
  const totalAbonos = abonosCredito.reduce((sum, a) => sum + Number(a.monto || 0), 0);
  const ventaTipo = (c.venta?.tipo_pago || c.venta?.tipo_venta || "").toLowerCase();

  if (Number(saldoRaw || 0) <= 0 && total > 0 && totalAbonos <= 0 && ventaTipo.includes("credito")) {
    return total;
  }

  return Math.max(Number(saldoRaw ?? total) - 0, 0);
}

function estadoCredito(c) {
  const saldo = saldoCredito(c);
  if (saldo <= 0) return "pagado";
  const estado = (c.estado || "").toLowerCase();
  if (estado === "pagado") return "pendiente";
  return c.estado || "pendiente";
}


function creditosPendientesCliente(clienteId) {
  return creditos
    .filter(c => String(c.cliente_id) === String(clienteId))
    .map(c => ({ ...c, saldoCalculado: saldoCredito(c) }))
    .filter(c => c.saldoCalculado > 0)
    .sort((a,b) => new Date(a.creado_en || 0) - new Date(b.creado_en || 0));
}

function resumenClientesCredito() {
  const mapa = new Map();
  creditos.forEach(c => {
    const saldo = saldoCredito(c);
    if (saldo <= 0 || !c.cliente_id) return;
    if (!mapa.has(c.cliente_id)) mapa.set(c.cliente_id, { cliente_id:c.cliente_id, cliente:c.cliente, deuda:0, pendientes:0 });
    const r = mapa.get(c.cliente_id);
    r.deuda += saldo;
    r.pendientes += 1;
  });
  return Array.from(mapa.values()).sort((a,b) => b.deuda - a.deuda);
}

function renderHistorialClientes() {
  const tabla = $("historialClientesTabla");
  if (!tabla) return;
  const lista = resumenClientesCredito();
  if (!lista.length) {
    tabla.innerHTML = `<tr><td colspan="5">No hay clientes con créditos pendientes.</td></tr>`;
    return;
  }
  tabla.innerHTML = lista.map(item => {
    const temp = { cliente: item.cliente };
    return `<tr>
      <td><strong>${nombreCliente(temp)}</strong></td>
      <td>${nitCliente(temp)}</td>
      <td>${item.pendientes}</td>
      <td><strong class="text-danger">${fmt(item.deuda)}</strong></td>
      <td class="actions">
        <button class="btn btn-small btn-secondary" type="button" onclick="verHistorialCliente('${item.cliente_id}')">Ver detalle</button>
        <button class="btn btn-small btn-primary" type="button" onclick="abrirAbonoClienteModal('${item.cliente_id}')">Abonar cliente</button>
      </td>
    </tr>`;
  }).join("");
}

window.verHistorialCliente = function(clienteId) {
  const lista = creditosPendientesCliente(clienteId);
  const total = lista.reduce((s,c) => s + Number(c.saldoCalculado || 0), 0);
  const cbase = creditos.find(c => String(c.cliente_id) === String(clienteId));
  const temp = { cliente: cbase?.cliente || null };
  $("detalleClienteTitulo").textContent = `Historial crediticio · ${nombreCliente(temp)}`;
  $("detalleClienteSubtitulo").textContent = `NIT: ${nitCliente(temp)}`;
  $("clienteDeudaTotal").textContent = fmt(total);
  $("clienteCreditosPendientes").textContent = lista.length;
  $("detalleClienteCreditosTabla").innerHTML = lista.length ? lista.map(c => `
    <tr>
      <td>${c.venta?.folio || c.venta_id?.slice(0,8) || c.id.slice(0,8)}</td>
      <td><strong>${fmt(montoTotalCredito(c))}</strong></td>
      <td><strong class="text-danger">${fmt(c.saldoCalculado)}</strong></td>
      <td><span class="badge warning">pendiente</span></td>
      <td>${c.creado_en ? new Date(c.creado_en).toLocaleString("es-GT") : "-"}</td>
    </tr>`).join("") : `<tr><td colspan="5">Sin créditos pendientes.</td></tr>`;
  $("detalleClienteCreditoPanel").style.display = "block";
  $("detalleClienteCreditoPanel").scrollIntoView({ behavior:"smooth" });
};

window.abrirAbonoClienteModal = function(clienteId) {
  const lista = creditosPendientesCliente(clienteId);
  if (!lista.length) return alert("Este cliente no tiene créditos pendientes.");
  const cbase = creditos.find(c => String(c.cliente_id) === String(clienteId));
  const temp = { cliente: cbase?.cliente || null };
  const deuda = lista.reduce((s,c) => s + Number(c.saldoCalculado || 0), 0);
  $("abonoClienteId").value = clienteId;
  $("abonoClienteNombre").textContent = `${nombreCliente(temp)} · Deuda total: ${fmt(deuda)}`;
  $("abonoClienteDeuda").value = fmt(deuda);
  $("abonoClienteMonto").value = "";
  $("abonoClienteNota").value = "";
  $("abonoClienteMsg").textContent = "";
  $("abonoClienteMsg").className = "message";
  $("abonoClienteModal").hidden = false;
};

function cerrarAbonoClienteModal(){ $("abonoClienteModal").hidden = true; }
function mostrarAbonoClienteMsg(t,tipo=""){ $("abonoClienteMsg").textContent=t; $("abonoClienteMsg").className=`message ${tipo}`; }

async function registrarAbonoCliente(e) {
  e.preventDefault();
  const clienteId = $("abonoClienteId").value;
  const montoOriginal = Number($("abonoClienteMonto").value || 0);
  const nota = $("abonoClienteNota").value.trim();

  if (montoOriginal <= 0) return mostrarAbonoClienteMsg("El monto debe ser mayor a Q0.00.", "error");
  await cargarCaja();
  if (!cajaActual) return mostrarAbonoClienteMsg("Primero debes abrir caja para registrar un abono.", "error");

  const lista = creditosPendientesCliente(clienteId);
  const deuda = lista.reduce((s,c) => s + Number(c.saldoCalculado || 0), 0);
  if (!lista.length) return mostrarAbonoClienteMsg("Este cliente ya no tiene créditos pendientes.", "error");
  if (montoOriginal > deuda) return mostrarAbonoClienteMsg(`El abono no puede ser mayor a la deuda total (${fmt(deuda)}).`, "error");

  let restante = montoOriginal;
  const distribucion = [];
  const abonosCreados = [];

  for (const credito of lista) {
    if (restante <= 0) break;
    const saldoAntes = saldoCredito(credito);
    const montoAplicado = Math.min(restante, saldoAntes);
    const nuevoSaldo = Math.max(0, saldoAntes - montoAplicado);
    const nuevoEstado = nuevoSaldo <= 0 ? "pagado" : "pendiente";

    const { data: abono, error: abonoError } = await supabaseClient.from("abonos_credito").insert([{
      credito_id: credito.id, cliente_id: credito.cliente_id, venta_id: credito.venta_id,
      usuario_id: user.id, caja_id: cajaActual.id, monto: montoAplicado,
      nota: nota || "Abono general a cuenta del cliente"
    }]).select().single();

    if (abonoError) return mostrarAbonoClienteMsg("No se pudo registrar abono: " + abonoError.message, "error");

    const { error: updError } = await supabaseClient.from("creditos").update({
      saldo: nuevoSaldo, monto_pendiente: nuevoSaldo, estado: nuevoEstado,
      pagado_en: nuevoEstado === "pagado" ? new Date().toISOString() : null
    }).eq("id", credito.id);

    if (updError) return mostrarAbonoClienteMsg("Abono creado, pero no se pudo actualizar crédito: " + updError.message, "error");

    abonosCreados.push(abono);
    distribucion.push({ credito_id:credito.id, venta_id:credito.venta_id, venta_folio:credito.venta?.folio || null, saldo_anterior:saldoAntes, monto_aplicado:montoAplicado, saldo_nuevo:nuevoSaldo });
    restante -= montoAplicado;
  }

  const cbase = creditos.find(c => String(c.cliente_id) === String(clienteId));
  const temp = { cliente: cbase?.cliente || null };

  const { error: cajaError } = await supabaseClient.from("movimientos_caja").insert([{
    caja_id:cajaActual.id, usuario_id:user.id, tipo:"ingreso", categoria:"abono_credito",
    persona:nombreCliente(temp), monto:montoOriginal,
    descripcion:`Abono general a cuenta del cliente ${nombreCliente(temp)}`,
    referencia_id:abonosCreados[0]?.id || null
  }]);
  if (cajaError) return mostrarAbonoClienteMsg("Abonos guardados, pero no se pudo sumar a caja: " + cajaError.message, "error");

  await supabaseClient.from("documentos_generados").insert([{
    tipo:"recibo_abono_cliente", referencia_id:clienteId, cliente_id:clienteId, usuario_id:user.id,
    folio:"SO-AC-" + Date.now(), titulo:"Recibo de abono a cuenta de cliente",
    contenido:{ cliente:nombreCliente(temp), nit:nitCliente(temp), monto:montoOriginal, deuda_anterior:deuda, deuda_nueva:deuda-montoOriginal, distribucion, nota, fecha:new Date().toISOString() }
  }]);

  await registrarAuditoria({ usuario:user, perfil, modulo:"creditos", accion:"abono_general_cliente", descripcion:`${nombreCliente(temp)} abonó ${fmt(montoOriginal)} a cuenta general`, referencia_id:clienteId });
  mostrarAbonoClienteMsg("Abono general registrado, distribuido y sumado a caja.", "success");
  setTimeout(() => cerrarAbonoClienteModal(), 700);
  await cargarTodo();
}


function renderCreditos() {
  const tabla = $("creditosTabla");
  const q = ($("buscarCredito")?.value || "").toLowerCase().trim();

  const filtrados = creditos.filter(c => {
    const texto = `${nombreCliente(c)} ${nitCliente(c)} ${estadoCredito(c)} ${c.venta?.folio || ""}`.toLowerCase();
    return texto.includes(q);
  });

  if (!filtrados.length) {
    tabla.innerHTML = `<tr><td colspan="7">No hay créditos registrados.</td></tr>`;
    return;
  }

  tabla.innerHTML = filtrados.map(c => {
    const saldo = saldoCredito(c);
    const total = montoTotalCredito(c);
    const estado = estadoCredito(c);

    return `
      <tr>
        <td><strong>${nombreCliente(c)}</strong><br><small>${nitCliente(c)}</small></td>
        <td>${c.venta?.folio || c.venta_id?.slice(0,8) || "-"}</td>
        <td><strong>${fmt(total)}</strong></td>
        <td><strong class="${saldo > 0 ? "text-danger" : "text-success"}">${fmt(saldo)}</strong></td>
        <td><span class="badge ${estado === "pagado" ? "ok" : "warning"}">${estado}</span></td>
        <td>${c.creado_en ? new Date(c.creado_en).toLocaleString("es-GT") : "-"}</td>
        <td class="actions">
          ${estado !== "pagado" && saldo > 0 ? `<button class="btn btn-small btn-primary" onclick="abrirAbonoModal('${c.id}')">Abonar</button>` : ""}
          <button class="btn btn-small btn-secondary" onclick="verAbonosCredito('${c.id}')">Historial</button>
        </td>
      </tr>
    `;
  }).join("");

  resumen();
}

function resumen() {
  const saldoPendiente = creditos.reduce((s,c)=>s+Math.max(0, saldoCredito(c)),0);
  const activos = creditos.filter(c=>saldoCredito(c)>0).length;
  const pagados = creditos.filter(c=>saldoCredito(c)<=0).length;
  const totalAbonos = abonos.reduce((s,a)=>s+Number(a.monto || a.cantidad || 0),0);

  $("saldoPendiente").textContent = fmt(saldoPendiente);
  $("creditosActivos").textContent = activos;
  $("creditosPagados").textContent = pagados;
  $("abonosRegistrados").textContent = fmt(totalAbonos);
}

window.abrirAbonoModal = function(id) {
  const c = creditos.find(x => String(x.id) === String(id));
  if (!c) return;

  if (estadoCredito(c) === "pagado" || saldoCredito(c) <= 0) {
    alert("Este crédito ya está pagado. No se puede registrar abono.");
    return;
  }

  creditoSeleccionado = c;
  $("abonoCreditoId").value = c.id;
  $("abonoClienteTexto").textContent = `${nombreCliente(c)} · Saldo: ${fmt(saldoCredito(c))}`;
  $("abonoSaldoActual").value = fmt(saldoCredito(c));
  $("abonoMonto").value = "";
  $("abonoNota").value = "";
  $("abonoMsg").textContent = "";
  $("abonoMsg").className = "message";

  $("abonoModal").hidden = false;
};

function cerrarAbonoModal() {
  $("abonoModal").hidden = true;
  creditoSeleccionado = null;
}


async function generarDocumentoAbonoCredito({ credito, abono, monto, saldoAnterior, saldoNuevo, nota }) {
  const folioDoc = folioAbonoCreditoSOC();

  const contenido = {
    folio: folioDoc,
    credito_id: credito.id,
    abono_id: abono.id,
    venta_id: credito.venta_id || null,
    venta_folio: credito.venta?.folio || null,
    cliente: nombreCliente(credito),
    nit: nitCliente(credito),
    monto,
    saldo_anterior: saldoAnterior,
    saldo_nuevo: saldoNuevo,
    nota,
    usuario: perfil?.nombre || user?.email || "Usuario",
    fecha: new Date().toISOString()
  };

  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .insert([{
      tipo: "recibo_abono_credito",
      referencia_id: abono.id,
      cliente_id: credito.cliente_id,
      usuario_id: user.id,
      folio: folioDoc,
      titulo: "Recibo de abono a crédito",
      contenido
    }])
    .select()
    .single();

  if (error) {
    console.warn("No se pudo guardar recibo de abono:", error.message);
    return null;
  }

  return data;
}

function abrirReciboAbonoCredito(documento) {
  if (!documento?.contenido) return;
  abrirPDFDesdeHTML("Recibo de abono", htmlReciboAbonoCredito(documento.contenido));
}


async function registrarAbono(e) {
  e.preventDefault();

  if (!creditoSeleccionado) return;

  await cargarCaja();

  if (!cajaActual) {
    mostrarAbonoMsg("Primero debes abrir caja para registrar un abono.", "error");
    return;
  }

  const monto = Number($("abonoMonto").value || 0);
  const nota = $("abonoNota").value.trim();
  const saldoActual = saldoCredito(creditoSeleccionado);

  if (monto <= 0) {
    mostrarAbonoMsg("El monto debe ser mayor a Q0.00.", "error");
    return;
  }

  if (monto > saldoActual) {
    mostrarAbonoMsg(`El abono no puede ser mayor al saldo (${fmt(saldoActual)}).`, "error");
    return;
  }

  const nuevoSaldo = Math.max(0, saldoActual - monto);
  const nuevoEstado = nuevoSaldo <= 0 ? "pagado" : "pendiente";

  const { data: abono, error: abonoError } = await supabaseClient
    .from("abonos_credito")
    .insert([{
      credito_id: creditoSeleccionado.id,
      cliente_id: creditoSeleccionado.cliente_id,
      venta_id: creditoSeleccionado.venta_id,
      usuario_id: user.id,
      caja_id: cajaActual.id,
      monto,
      nota
    }])
    .select()
    .single();

  if (abonoError) {
    mostrarAbonoMsg("No se pudo registrar el abono: " + abonoError.message, "error");
    return;
  }

  const { error: cajaError } = await supabaseClient
    .from("movimientos_caja")
    .insert([{
      caja_id: cajaActual.id,
      usuario_id: user.id,
      tipo: "ingreso",
      categoria: "abono_credito",
      persona: nombreCliente(creditoSeleccionado),
      monto,
      descripcion: `Abono a crédito de ${nombreCliente(creditoSeleccionado)}`,
      referencia_id: creditoSeleccionado.id
    }]);

  if (cajaError) {
    mostrarAbonoMsg("Abono guardado, pero no se pudo sumar a caja: " + cajaError.message, "error");
    return;
  }

  const { error: updateError } = await supabaseClient
    .from("creditos")
    .update({
      saldo: nuevoSaldo,
      monto_pendiente: nuevoSaldo,
      estado: nuevoEstado,
      pagado_en: nuevoEstado === "pagado" ? new Date().toISOString() : null
    })
    .eq("id", creditoSeleccionado.id);

  if (updateError) {
    mostrarAbonoMsg("Abono y caja guardados, pero no se pudo actualizar crédito: " + updateError.message, "error");
    return;
  }

  const documentoAbono = await generarDocumentoAbonoCredito({
    credito: creditoSeleccionado,
    abono,
    monto,
    saldoAnterior: saldoActual,
    saldoNuevo: nuevoSaldo,
    nota
  });

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "creditos",
    accion: "registrar_abono",
    descripcion: `${nombreCliente(creditoSeleccionado)} abonó ${fmt(monto)}`,
    referencia_id: creditoSeleccionado.id
  });

  if (documentoAbono) {
    abrirReciboAbonoCredito(documentoAbono);
  }

  mostrarAbonoMsg("Abono registrado, sumado a caja y recibo generado.", "success");

  setTimeout(() => {
    cerrarAbonoModal();
  }, 700);

  await cargarTodo();
}

function mostrarAbonoMsg(texto, tipo="") {
  $("abonoMsg").textContent = texto;
  $("abonoMsg").className = `message ${tipo}`;
}

window.verAbonosCredito = function(id) {
  const c = creditos.find(x => String(x.id) === String(id));
  const lista = abonos.filter(a => String(a.credito_id) === String(id));

  $("historialTitulo").textContent = `Historial de abonos · ${c ? nombreCliente(c) : ""}`;
  $("historialAbonosPanel").style.display = "block";

  const tabla = $("abonosTabla");

  if (!lista.length) {
    tabla.innerHTML = `<tr><td colspan="4">No hay abonos registrados para este crédito.</td></tr>`;
    $("historialAbonosPanel").scrollIntoView({ behavior: "smooth" });
    return;
  }

  tabla.innerHTML = lista.map(a => `
    <tr>
      <td>${a.creado_en ? new Date(a.creado_en).toLocaleString("es-GT") : "-"}</td>
      <td><strong>${fmt(a.monto || a.cantidad || 0)}</strong></td>
      <td>${a.nota || "-"}</td>
      <td>${a.caja_id ? "Registrado en caja" : "Sin caja"}</td>
    </tr>
  `).join("");

  $("historialAbonosPanel").scrollIntoView({ behavior: "smooth" });
};

init();
