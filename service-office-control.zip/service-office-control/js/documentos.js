import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";
import { htmlReciboAbonoCredito } from "./documentos-utils.js";
import { getTicketConfig, ticketHeaderHtml, ticketFooterHtml, ticketPrintStyles } from "./ticket-config-utils.js";

let user = null;
let perfil = null;
let clientes = [];
let documentosHistorial = [];
let filtroActual = "todos";
let ultimoHTMLDocumento = "";
let ultimoDocumentoData = null;

async function init(){
  user = await requireAuth();
  if(!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "documentos");
  if(!perfil) return;

  document.getElementById("documentoForm").addEventListener("submit", generarDocumento);
  document.getElementById("recargarDocumentosHistorial")?.addEventListener("click", cargarHistorialDocumentos);

  document.querySelectorAll(".doc-filter").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".doc-filter").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      filtroActual = btn.dataset.tipo || "todos";
      renderHistorialDocumentos();
    });
  });

  document.getElementById("cerrarDocumentoHistorial")?.addEventListener("click", cerrarModalDocumento);
  document.getElementById("cerrarDocumentoHistorialFooter")?.addEventListener("click", cerrarModalDocumento);
  document.getElementById("imprimirDocumentoHistorial")?.addEventListener("click", imprimirDocumentoActual);
  document.getElementById("imprimirTicketTermicoDocumento")?.addEventListener("click", imprimirTicketTermicoDocumentoActual);
  document.getElementById("documentoHistorialModal")?.addEventListener("click", e => {
    if(e.target.id === "documentoHistorialModal") cerrarModalDocumento();
  });

  await cargarClientes();
  await cargarHistorialDocumentos();
  instalarNavegacionPremium();
}

async function cargarClientes(){
  const { data } = await supabaseClient.from("clientes").select("*").order("nombre");
  clientes = data || [];
  const select = document.getElementById("clienteId");
  select.innerHTML = `<option value="">Seleccionar cliente</option>`;
  clientes.forEach(c => {
    const nombre = c.nombre_completo || [c.nombre, c.apellido].filter(Boolean).join(" ") || c.nombre || "Cliente";
    select.innerHTML += `<option value="${c.id}">${nombre}</option>`;
  });
}

async function generarDocumento(e){
  e.preventDefault();

  const tipo = document.getElementById("tipo").value;
  const cliente = clientes.find(c => c.id === document.getElementById("clienteId").value);
  const total = Number(document.getElementById("total").value || 0);
  const anticipo = Number(document.getElementById("anticipo").value || 0);
  const saldo = Math.max(total - anticipo, 0);
  const folio = `SO-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;

  const contenido = {
    cliente: nombreCliente(cliente) || "Cliente",
    nit: cliente?.nit || "CF",
    telefono: cliente?.telefono || "",
    direccion: cliente?.direccion || "",
    total,
    anticipo,
    saldo,
    detalle: document.getElementById("detalle").value.trim(),
    fecha: new Date().toISOString()
  };

  const titulo = document.getElementById("titulo").value.trim() || tituloTipo(tipo);

  const { error } = await supabaseClient.from("documentos_generados").insert([{
    tipo,
    cliente_id: cliente?.id || null,
    usuario_id: user.id,
    folio,
    titulo,
    contenido
  }]);

  if(error){
    mostrar(error.message, "error");
    return;
  }

  renderPreview({ tipo, folio, titulo, contenido });

  await registrarAuditoria({
    usuario:user,
    perfil,
    modulo:"documentos",
    accion:"generar_documento",
    descripcion:`${titulo} · ${folio}`
  });

  mostrar("Documento generado. Puedes imprimirlo o guardar como PDF.", "success");
  await cargarHistorialDocumentos();
}

async function cargarHistorialDocumentos(){
  const tabla = document.getElementById("documentosHistorialTabla");
  if(!tabla) return;

  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .select("*")
    .order("creado_en", { ascending:false })
    .limit(150);

  if(error){
    tabla.innerHTML = `<tr><td colspan="6">No se pudieron cargar documentos: ${error.message}</td></tr>`;
    return;
  }

  documentosHistorial = data || [];
  renderHistorialDocumentos();
}

function renderHistorialDocumentos(){
  const tabla = document.getElementById("documentosHistorialTabla");
  if(!tabla) return;

  const docs = filtroActual === "todos"
    ? documentosHistorial
    : documentosHistorial.filter(d => d.tipo === filtroActual);

  if(!docs.length){
    tabla.innerHTML = `<tr><td colspan="6">No hay documentos para mostrar.</td></tr>`;
    return;
  }

  tabla.innerHTML = docs.map(d => {
    const c = d.contenido || {};
    const cliente = c.cliente || c.cliente_nombre || d.cliente_nombre || "Consumidor Final";
    const total = c.total ?? c.monto ?? c.saldo_nuevo ?? 0;

    return `
      <tr>
        <td>${d.creado_en ? new Date(d.creado_en).toLocaleString("es-GT") : "-"}</td>
        <td><span class="badge info">${tipoBonito(d.tipo)}</span></td>
        <td><strong>${d.folio || "-"}</strong></td>
        <td>${cliente}</td>
        <td><strong>${money(Number(total || 0))}</strong></td>
        <td>
          <button class="btn btn-small btn-primary" type="button" onclick="verDocumentoHistorial('${d.id}')">Ver</button>
        </td>
      </tr>
    `;
  }).join("");
}

window.verDocumentoHistorial = async function(id){
  const doc = documentosHistorial.find(d => String(d.id) === String(id));
  if(!doc) return;

  const docCompleto = await enriquecerDocumentoConDetalleVenta(doc);
  const html = htmlDocumentoHistorial(docCompleto);
  ultimoDocumentoData = docCompleto;
  ultimoHTMLDocumento = html;

  document.getElementById("documentoHistorialTitulo").textContent = docCompleto.titulo || tipoBonito(docCompleto.tipo);
  document.getElementById("documentoHistorialSubtitulo").textContent = `${docCompleto.folio || "-"} · ${docCompleto.creado_en ? new Date(docCompleto.creado_en).toLocaleString("es-GT") : ""}`;
  document.getElementById("documentoHistorialPreview").innerHTML = html;
  document.getElementById("documentoHistorialModal").hidden = false;
};


function obtenerVentaIdDocumento(doc){
  const c = doc.contenido || {};
  if(doc.referencia_id) return doc.referencia_id;
  if(c.venta_id) return c.venta_id;
  if(c.referencia_id) return c.referencia_id;
  return null;
}

async function enriquecerDocumentoConDetalleVenta(doc){
  const ventaId = obtenerVentaIdDocumento(doc);
  const contenidoOriginal = doc.contenido || {};

  // Si el documento ya trae items guardados, no tocamos nada.
  if(Array.isArray(contenidoOriginal.items) && contenidoOriginal.items.length){
    return doc;
  }

  if(!ventaId){
    return doc;
  }

  const { data: detalles, error } = await supabaseClient
    .from("detalle_ventas")
    .select("id, venta_id, producto_id, nombre_producto, producto_nombre, cantidad, precio_unitario, total, descuento")
    .eq("venta_id", ventaId)
    .order("id", { ascending:true });

  if(error || !detalles?.length){
    return doc;
  }

  const items = detalles.map(d => ({
    nombre: d.nombre_producto || d.producto_nombre || "Producto / Servicio",
    producto_nombre: d.producto_nombre || d.nombre_producto || "Producto / Servicio",
    cantidad: Number(d.cantidad || 1),
    precio_unitario: Number(d.precio_unitario || 0),
    total: Number(d.total || 0),
    descuento: Number(d.descuento || 0)
  }));

  const clienteEncontrado = clientes.find(c => String(c.id) === String(contenidoOriginal.cliente_id || doc.cliente_id));

  return {
    ...doc,
    contenido: {
      ...contenidoOriginal,
      cliente: contenidoOriginal.cliente || contenidoOriginal.cliente_nombre || nombreCliente(clienteEncontrado) || "Consumidor Final",
      items
    }
  };
}

function htmlDocumentoHistorial(doc){
  if(doc.tipo === "recibo_abono_credito"){
    return htmlReciboAbonoCredito(doc.contenido || {});
  }

  if(typeof window.htmlDocumentoExtraSOC === "function"){
    const extra = window.htmlDocumentoExtraSOC(doc);
    if(extra) return extra;
  }

  const c = doc.contenido || {};
  const items = Array.isArray(c.items) ? c.items : [];
  const fecha = c.fecha ? new Date(c.fecha).toLocaleString("es-GT") : (doc.creado_en ? new Date(doc.creado_en).toLocaleString("es-GT") : new Date().toLocaleString("es-GT"));
  const total = Number(c.total || c.monto || 0);

  const itemsHTML = items.length ? `
    <table class="soc-doc-table">
      <thead>
        <tr>
          <th>Producto / Servicio</th>
          <th>Cant.</th>
          <th>Precio</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        ${items.map(i => `
          <tr>
            <td>${i.nombre || i.producto_nombre || i.servicio || "Producto"}</td>
            <td>${i.cantidad || 1}</td>
            <td>${money(Number(i.precio_unitario || 0))}</td>
            <td><strong>${money(Number(i.total || 0))}</strong></td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  ` : `
    <div class="soc-doc-detail">
      <p>${c.detalle || c.producto || c.servicio || c.notas || "Documento generado automáticamente."}</p>
    </div>
  `;

  return `
    <div class="soc-doc">
      <div class="soc-doc-head">
        <div>
          <h1>Service Office</h1>
          <p>${doc.titulo || tipoBonito(doc.tipo)}</p>
        </div>
        <div class="soc-doc-folio">
          <strong>${doc.folio || "-"}</strong>
          <span>${fecha}</span>
        </div>
      </div>

      <div class="soc-doc-info">
        <div><span>Cliente</span><strong>${c.cliente || c.cliente_nombre || "Consumidor Final"}</strong></div>
        <div><span>NIT</span><strong>${c.nit || "CF"}</strong></div>
        <div><span>Tipo</span><strong>${tipoBonito(doc.tipo)}</strong></div>
        <div><span>Estado</span><strong>${c.estado || "-"}</strong></div>
      </div>

      ${itemsHTML}

      <div class="soc-doc-totals">
        <div><span>Total</span><strong>${money(total)}</strong></div>
        ${c.anticipo !== undefined ? `<div><span>Anticipo</span><strong>${money(Number(c.anticipo || 0))}</strong></div>` : ""}
        ${c.pagado !== undefined ? `<div><span>Pagado</span><strong>${money(Number(c.pagado || 0))}</strong></div>` : ""}
        ${c.saldo !== undefined ? `<div><span>Saldo</span><strong>${money(Number(c.saldo || 0))}</strong></div>` : ""}
      </div>

      <p class="soc-doc-footer">Documento generado automáticamente por Service Office Control.</p>
    </div>
  `;
}


function htmlTicketTermicoDocumento(doc = {}) {
  const configTicket = getTicketConfig();
  const c = doc.contenido || {};
  const items = Array.isArray(c.items) ? c.items : [];
  const fecha = c.fecha ? new Date(c.fecha).toLocaleString("es-GT") : (doc.creado_en ? new Date(doc.creado_en).toLocaleString("es-GT") : new Date().toLocaleString("es-GT"));
  const total = Number(c.total || c.monto || 0);
  const filas = items.length ? items.map(i => `
    <div class="tt-item tt-product-row">
      <div class="tt-qty">${Number(i.cantidad || 1)}</div>
      <div class="tt-product-name"><strong>${i.nombre || i.producto_nombre || i.servicio || "Producto"}</strong>${(configTicket.mostrarSku && i.sku) ? `<small>SKU: ${i.sku}</small>` : ""}</div>
      <div class="tt-product-total"><strong>Q ${Number(i.total || 0).toFixed(2)}</strong></div>
    </div>
  `).join("") : `
    <div class="tt-item tt-product-row"><div class="tt-qty">1</div><div class="tt-product-name"><strong>${c.detalle || c.producto || c.servicio || doc.titulo || "Documento"}</strong></div><div class="tt-product-total"><strong>${money(total)}</strong></div></div>
  `;
  return `
    <div class="thermal-ticket ticket-premium">
      ${ticketHeaderHtml(configTicket)}
      <div class="tt-line"></div>
      <div class="tt-row"><span>Folio:</span><strong>${doc.folio || "-"}</strong></div>
      <div class="tt-row"><span>Fecha:</span><span>${fecha}</span></div>
      ${configTicket.mostrarCliente ? `<div class="tt-row"><span>Cliente:</span><strong>${c.cliente || c.cliente_nombre || "Consumidor Final"}</strong></div>` : ""}
      ${configTicket.mostrarNit ? `<div class="tt-row"><span>NIT:</span><span>${c.nit || "CF"}</span></div>` : ""}
      <div class="tt-line"></div>
      <div class="tt-head-row"><span>CANT.</span><span>DESCRIPCIÓN</span><span>TOTAL</span></div>
      ${filas}
      <div class="tt-line"></div>
      <div class="tt-row tt-total"><span>TOTAL:</span><strong>${money(total)}</strong></div>
      ${c.saldo !== undefined ? `<div class="tt-balance"><span>Saldo pendiente:</span><strong>${money(Number(c.saldo || 0))}</strong></div>` : ""}
      <div class="tt-line"></div>
      ${ticketFooterHtml(configTicket)}
    </div>
  `;
}

function imprimirTicketTermicoDocumentoActual(){
  if(!ultimoDocumentoData) return alert("Primero abre un documento.");
  imprimirHTMLTicketTermicoDocumento("Ticket Service Office", htmlTicketTermicoDocumento(ultimoDocumentoData));
}

function imprimirHTMLTicketTermicoDocumento(titulo, html) {
  const w = window.open("", "_blank", "width=420,height=720");
  w.document.write(`
    <html><head><title>${titulo}</title><style>${ticketPrintStyles()}</style></head><body>${html}<script>setTimeout(()=>window.print(),250)</script></body></html>
  `);
  w.document.close();
  w.focus();
}

function cerrarModalDocumento(){
  const modal = document.getElementById("documentoHistorialModal");
  if(modal) modal.hidden = true;
}

function imprimirDocumentoActual(){
  if(!ultimoHTMLDocumento) return;
  const w = window.open("", "_blank", "width=900,height=900");
  w.document.write(`
    <html>
      <head>
        <title>Documento Service Office</title>
        <style>
          body{font-family:Arial,sans-serif;padding:20px;background:#fff;color:#111}
          .soc-doc{max-width:760px;margin:auto;border:1px solid #ddd;border-radius:16px;padding:24px}
          .soc-doc-head{display:flex;justify-content:space-between;border-bottom:3px solid #e50914;padding-bottom:14px;margin-bottom:16px}
          .soc-doc-head h1{margin:0;color:#e50914;text-transform:uppercase}
          .soc-doc-info{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:16px 0}
          .soc-doc-info div{background:#f7f7f7;padding:10px;border-radius:10px}
          .soc-doc-info span{display:block;color:#666;font-size:12px}
          table{width:100%;border-collapse:collapse;margin-top:14px}
          th{background:#111;color:#fff;padding:9px;text-align:left}
          td{border-bottom:1px solid #eee;padding:9px}
          .soc-doc-totals{margin-left:auto;margin-top:18px;max-width:300px;background:#f7f7f7;border-radius:12px;padding:12px}
          .soc-doc-totals div{display:flex;justify-content:space-between;margin:6px 0}
          .soc-doc-footer{text-align:center;color:#666;margin-top:22px;font-size:12px}
        </style>
      </head>
      <body>${ultimoHTMLDocumento}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}

function tituloTipo(tipo){
  const map = {
    cotizacion:"Cotización",
    anticipo:"Comprobante de anticipo",
    orden_instalacion:"Orden de instalación",
    entrega:"Comprobante de entrega",
    recibo:"Recibo de pago"
  };
  return map[tipo] || "Documento";
}

function tipoBonito(tipo){
  const map = {
    cotizacion:"Cotización",
    anticipo:"Anticipo",
    orden_instalacion:"Orden instalación",
    entrega:"Entrega",
    recibo:"Recibo",
    comprobante_venta:"Venta",
    recibo_impresion:"Impresión",
    recibo_abono_credito:"Abono crédito",
    factura_interna:"Factura interna",
    devolucion:"Devolución",
    comprobante_devolucion:"Devolución"
  };
  return map[tipo] || tipo || "Documento";
}

function nombreCliente(c){
  if(!c) return "";
  return c.nombre_completo || [c.nombre, c.apellido].filter(Boolean).join(" ") || c.nombre || "";
}

function renderPreview(doc){
  document.getElementById("documentPreview").innerHTML = `
    <h2>Service Office</h2>
    <h3>${doc.titulo}</h3>
    <p><strong>Folio:</strong> ${doc.folio}</p>
    <p><strong>Fecha:</strong> ${new Date().toLocaleString("es-GT")}</p>
    <hr>
    <p><strong>Cliente:</strong> ${doc.contenido.cliente}</p>
    <p><strong>NIT:</strong> ${doc.contenido.nit}</p>
    <p><strong>Teléfono:</strong> ${doc.contenido.telefono || "-"}</p>
    <p><strong>Dirección:</strong> ${doc.contenido.direccion || "-"}</p>
    <hr>
    <p><strong>Detalle:</strong></p>
    <p>${doc.contenido.detalle || "-"}</p>
    <hr>
    <p><strong>Total:</strong> ${money(doc.contenido.total)}</p>
    <p><strong>Anticipo:</strong> ${money(doc.contenido.anticipo)}</p>
    <p><strong>Saldo:</strong> ${money(doc.contenido.saldo)}</p>
    <br>
    <p>Firma cliente: ______________________________</p>
  `;
}

function mostrar(txt,tipo){
  const el = document.getElementById("docMsg");
  el.textContent = txt;
  el.className = `message ${tipo}`;
}

init();
