import { supabaseClient, requireAuth, setupLogout } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";

let user = null;
let perfil = null;
let instalaciones = [];

async function init(){
  user = await requireAuth();
  if(!user) return;
  setupLogout();

  perfil = await protegerModulo(user, "instalaciones");
  if(!perfil) return;

  document.getElementById("buscarInstalacion").addEventListener("input", renderInstalaciones);
  document.getElementById("cerrarDetalle").addEventListener("click", () => document.getElementById("detallePanel").style.display = "none");
  document.getElementById("instalacionForm").addEventListener("submit", guardarInstalacion);

  aplicarVistaTecnico();
  await cargarInstalaciones();
}

async function cargarInstalaciones(){
  let query = supabaseClient
    .from("camaras_instalaciones")
    .select("*, clientes(nombre,telefono,direccion), camaras_cotizaciones(cantidad_camaras,resolucion,total)")
    .order("creado_en", { ascending:false });

  if(perfil.rol === "tecnico"){
    query = query.eq("tecnico_id", user.id);
  }

  const { data, error } = await query;

  if(error){
    alert(error.message);
    return;
  }

  instalaciones = data || [];
  renderInstalaciones();
  resumen();
}

function resumen(){
  document.getElementById("pendientesCount").textContent = instalaciones.filter(i => i.estado === "pendiente_instalar").length;
  document.getElementById("instalandoCount").textContent = instalaciones.filter(i => i.estado === "instalando" || i.estado === "en_camino").length;
  document.getElementById("instaladasCount").textContent = instalaciones.filter(i => i.estado === "instalado" || i.estado === "finalizado").length;
  document.getElementById("garantiasCount").textContent = instalaciones.filter(i => i.garantia_hasta).length;
}

function renderInstalaciones(){
  const q = document.getElementById("buscarInstalacion").value.toLowerCase().trim();
  const estados = [
    ["pendiente_instalar", "Pendiente"],
    ["en_camino", "En camino"],
    ["instalando", "Instalando"],
    ["instalado", "Instalado / Garantía"]
  ];

  const board = document.getElementById("instalacionesBoard");

  board.innerHTML = estados.map(([estado, titulo]) => {
    const items = instalaciones.filter(i => {
      const matchEstado = estado === "instalado"
        ? (i.estado === "instalado" || i.estado === "finalizado")
        : i.estado === estado;

      const txt = `${i.clientes?.nombre || ""} ${i.direccion || ""} ${i.estado || ""}`.toLowerCase();
      return matchEstado && txt.includes(q);
    });

    return `
      <div class="kanban-col">
        <h3>${titulo}</h3>
        ${items.length ? items.map(cardInstalacion).join("") : `<p class="muted">Sin registros.</p>`}
      </div>
    `;
  }).join("");
}

function cardInstalacion(i){
  const cot = i.camaras_cotizaciones;
  return `
    <div class="install-card">
      <strong>${i.clientes?.nombre || "Cliente"}</strong>
      <p>${cot ? `${cot.cantidad_camaras} cámaras · ${cot.resolucion}` : "Instalación"}</p>
      <small>${i.direccion || i.clientes?.direccion || "Sin dirección"}</small>
      <div class="actions" style="margin-top:10px;">
        <button class="btn btn-small" onclick="abrirDetalle('${i.id}')">Abrir</button>
      </div>
    </div>
  `;
}

window.abrirDetalle = function(id){
  const i = instalaciones.find(x => x.id === id);
  if(!i) return;

  document.getElementById("detallePanel").style.display = "block";
  document.getElementById("detalleTitulo").textContent = `Instalación de ${i.clientes?.nombre || "cliente"}`;
  document.getElementById("instalacionId").value = i.id;
  document.getElementById("estado").value = i.estado || "pendiente_instalar";
  document.getElementById("fechaInstalacion").value = i.fecha_instalacion || "";
  document.getElementById("garantiaHasta").value = i.garantia_hasta || "";
  document.getElementById("serialDvr").value = i.serial_dvr || "";
  document.getElementById("serialCamaras").value = i.serial_camaras || "";
  document.getElementById("usuarioApp").value = i.usuario_app || "";
  document.getElementById("claveApp").value = i.clave_app || "";
  document.getElementById("notas").value = i.notas || "";

  const chk = i.checklist || {};
  document.getElementById("chkCamaras").checked = !!chk.camaras;
  document.getElementById("chkCableado").checked = !!chk.cableado;
  document.getElementById("chkApp").checked = !!chk.app;
  document.getElementById("chkAudio").checked = !!chk.audio;
  document.getElementById("chkCliente").checked = !!chk.cliente;

  document.getElementById("detallePanel").scrollIntoView({ behavior:"smooth" });
};

async function guardarInstalacion(e){
  e.preventDefault();

  const id = document.getElementById("instalacionId").value;
  const estado = document.getElementById("estado").value;

  const payload = {
    estado,
    fecha_instalacion: document.getElementById("fechaInstalacion").value || null,
    garantia_hasta: document.getElementById("garantiaHasta").value || null,
    serial_dvr: document.getElementById("serialDvr").value.trim(),
    serial_camaras: document.getElementById("serialCamaras").value.trim(),
    usuario_app: document.getElementById("usuarioApp").value.trim(),
    clave_app: document.getElementById("claveApp").value.trim(),
    notas: document.getElementById("notas").value.trim(),
    checklist: {
      camaras: document.getElementById("chkCamaras").checked,
      cableado: document.getElementById("chkCableado").checked,
      app: document.getElementById("chkApp").checked,
      audio: document.getElementById("chkAudio").checked,
      cliente: document.getElementById("chkCliente").checked
    },
    actualizado_en: new Date().toISOString()
  };

  const { error } = await supabaseClient
    .from("camaras_instalaciones")
    .update(payload)
    .eq("id", id);

  if(error){
    mostrar("Error: " + error.message, "error");
    return;
  }

  await registrarAuditoria({
    usuario:user,
    perfil,
    modulo:"instalaciones",
    accion:"actualizar_instalacion",
    descripcion:`Estado: ${estado}`
  });

  mostrar("Instalación actualizada.", "success");
  aplicarVistaTecnico();
  await cargarInstalaciones();
}

function mostrar(txt,tipo){
  const el = document.getElementById("instalacionMsg");
  el.textContent = txt;
  el.className = `message ${tipo}`;
}

instalarNavegacionPremium();
init();


function aplicarVistaTecnico(){
  if(perfil?.rol !== "tecnico") return;

  const titulo = document.querySelector(".topbar h1");
  const desc = document.querySelector(".topbar p");
  if(titulo) titulo.textContent = "Mis instalaciones";
  if(desc) desc.textContent = "Trabajos asignados, avance, checklist y datos técnicos.";
}
