import { supabaseClient, requireAuth, setupLogout, money } from "./supabase.js";
import { protegerModulo, registrarAuditoria } from "./authz.js";
import { instalarNavegacionPremium } from "./app-ui.js";
import { folio, abrirPDFDesdeHTML, htmlReciboImpresion, subirComprobanteHTML, linkWhatsApp, linkCorreo } from "./documentos-utils.js";
import { getTicketConfig, ticketHeaderHtml, ticketFooterHtml, ticketPrintStyles } from "./ticket-config-utils.js";

let user = null;
let perfil = null;
let cajaActual = null;
let clientes = [];
let precios = [];
let impresiones = [];
let ultimoReciboHTML = "";
let ultimoReciboData = null;
let tipoCobroActivo = "todos";

async function init() {
  user = await requireAuth();
  if (!user) return;

  setupLogout();

  perfil = await protegerModulo(user, "impresiones");
  if (!perfil) return;

  document.getElementById("servicioId").addEventListener("change", actualizarPrecio);
  document.getElementById("cantidad").addEventListener("input", calcularTotal);
  document.getElementById("precioUnitario").addEventListener("input", calcularTotal);
  document.getElementById("recibidoImpresion")?.addEventListener("input", actualizarCambioImpresion);
  document.getElementById("impresionForm").addEventListener("submit", registrarImpresion);
  document.getElementById("metodoPago")?.addEventListener("change", () => { configurarCreditoImpresion(); actualizarCambioImpresion(); });
  configurarBotonesCambioImpresion();
  configurarCreditoImpresion();
  document.getElementById("imprimirRecibo")?.addEventListener("click", () => {
    if (!ultimoReciboHTML) return alert("Primero genera un recibo.");
    abrirPDFDesdeHTML("Recibo de impresión", ultimoReciboHTML);
  });
  document.getElementById("imprimirTicketTermicoImpresion")?.addEventListener("click", () => {
    if (!ultimoReciboData) return alert("Primero genera un recibo.");
    imprimirTicketTermicoImpresion(ultimoReciboData);
  });

  document.getElementById("nuevoPrecioBtn").addEventListener("click", nuevoPrecio);
  document.getElementById("precioForm").addEventListener("submit", guardarPrecio);
  document.getElementById("cancelarPrecio").addEventListener("click", ocultarPrecioForm);
  document.getElementById("buscarServicioCatalogo")?.addEventListener("input", renderPrecios);
  document.querySelectorAll(".tipo-cobro-tab").forEach(btn => {
    btn.addEventListener("click", () => cambiarTipoCobro(btn.dataset.tipoCobro || "todos"));
  });
  document.getElementById("verTodosServiciosBtn")?.addEventListener("click", () => {
    document.getElementById("preciosPanel")?.scrollIntoView({ behavior: "smooth" });
  });
  document.getElementById("irHistorialBtn")?.addEventListener("click", () => {
    document.getElementById("historialImpresionesPanel")?.scrollIntoView({ behavior: "smooth" });
  });

  if (perfil.rol !== "admin") {
    document.getElementById("nuevoPrecioBtn").style.display = "none";
  }

  await cargarCaja();
  await cargarClientes();
  await cargarPrecios();
  await cargarImpresiones();
}

async function cargarCaja() {
  const { data } = await supabaseClient
    .from("cajas")
    .select("*")
    .eq("estado", "abierta")
    .order("abierta_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  cajaActual = data;

  const el = document.getElementById("estadoCaja");
  el.textContent = cajaActual ? "Caja abierta" : "Caja cerrada";
  el.className = cajaActual ? "status-pill ok" : "status-pill danger";
}

async function cargarClientes() {
  const { data } = await supabaseClient
    .from("clientes")
    .select("*")
    .eq("activo", true)
    .order("nombre", { ascending: true });

  clientes = data || [];

  const select = document.getElementById("clienteId");
  select.innerHTML = `<option value="">Cliente CF / sin cliente</option>`;
  clientes.forEach(c => select.innerHTML += `<option value="${c.id}">${c.nombre}</option>`);
}


function claseServicio(p) {
  const clase = (p.clase || p.tipo_item || p.tipo_servicio || "").toLowerCase();
  if (clase === "servicio" || clase === "tramite" || clase === "trámite") return "servicio";
  if (clase === "impresion" || clase === "impresión") return "impresion";

  const t = `${p.nombre || ""} ${p.tipo || ""}`.toLowerCase();
  if (t.includes("antecedente") || t.includes("sat") || t.includes("renap") || t.includes("partida") || t.includes("tramite") || t.includes("trámite")) return "servicio";
  return "impresion";
}

function etiquetaClaseServicio(p) {
  return claseServicio(p) === "servicio" ? "Servicio / Trámite" : "Impresión";
}

function iconoServicio(p) {
  const clase = claseServicio(p);
  const t = `${p.nombre || ""} ${p.tipo || ""}`.toLowerCase();
  if (clase === "servicio") {
    if (t.includes("sat")) return "🏛️";
    if (t.includes("renap") || t.includes("partida")) return "📜";
    if (t.includes("antecedente")) return "🪪";
    return "🧾";
  }
  if (t.includes("color")) return "🖨️";
  if (t.includes("fotocopia")) return "📄";
  if (t.includes("escaneo") || t.includes("scan")) return "📠";
  if (t.includes("emplastic") || t.includes("lamina")) return "🧾";
  if (t.includes("curriculum") || t.includes("diseño")) return "📝";
  return "🖨️";
}

function categoriaServicio(p) {
  const t = `${p.nombre || ""} ${p.tipo || ""}`.toLowerCase();
  if (claseServicio(p) === "servicio") {
    if (t.includes("sat")) return "SAT";
    if (t.includes("renap") || t.includes("partida")) return "RENAP";
    if (t.includes("antecedente")) return "Antecedentes";
    return "Trámites";
  }
  if (t.includes("fotocopia")) return "Fotocopias";
  if (t.includes("escaneo") || t.includes("scan")) return "Escaneos";
  if (t.includes("emplastic") || t.includes("lamina") || t.includes("encuadern")) return "Acabados";
  if (t.includes("diseño") || t.includes("curriculum")) return "Diseño";
  return "Impresiones";
}

function costoEstimadoServicio(p) {
  return Number(p.costo ?? p.costo_unitario ?? p.costo_estimado ?? 0);
}

function precioVariableServicio(p) {
  return p.precio_variable === true || p.precio_variable === "true" || p.tipo_precio === "variable" || p.modo_precio === "variable";
}

function gananciaEstimadaServicio(p) {
  const costo = costoEstimadoServicio(p);
  const precio = Number(p.precio || 0);
  return precio - costo;
}

function seleccionarServicioRapido(id) {
  const select = document.getElementById("servicioId");
  if (!select) return;
  select.value = id;
  actualizarPrecio();
  document.getElementById("cantidad")?.focus();
}

window.seleccionarServicioRapido = seleccionarServicioRapido;

function cambiarTipoCobro(tipo) {
  tipoCobroActivo = tipo;
  document.querySelectorAll(".tipo-cobro-tab").forEach(btn => {
    btn.classList.toggle("active", (btn.dataset.tipoCobro || "todos") === tipo);
  });
  renderServiciosRapidos();
  renderSelectServicios();
}

function serviciosActivosFiltrados() {
  return precios.filter(p => p.activo && (tipoCobroActivo === "todos" || claseServicio(p) === tipoCobroActivo));
}

function renderSelectServicios() {
  const select = document.getElementById("servicioId");
  if (!select) return;
  select.innerHTML = `<option value="">Seleccionar impresión o servicio</option>`;

  const activos = serviciosActivosFiltrados();
  const impresiones = activos.filter(p => claseServicio(p) === "impresion");
  const servicios = activos.filter(p => claseServicio(p) === "servicio");

  const addGroup = (label, lista) => {
    if (!lista.length) return;
    const optgroup = document.createElement("optgroup");
    optgroup.label = label;
    lista.forEach(p => {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = precioVariableServicio(p) ? `${p.nombre} - precio variable` : `${p.nombre} - ${money(p.precio)}`;
      optgroup.appendChild(opt);
    });
    select.appendChild(optgroup);
  };

  addGroup("Impresiones", impresiones);
  addGroup("Servicios / Trámites", servicios);
}

function renderServiciosRapidos() {
  const cont = document.getElementById("serviciosRapidos");
  if (!cont) return;

  const activos = serviciosActivosFiltrados().slice(0, 8);

  if (!activos.length) {
    cont.innerHTML = `<div class="quick-service-skeleton">No hay servicios activos.</div>`;
    return;
  }

  cont.innerHTML = activos.map((p, idx) => `
    <button class="quick-service-card ${idx === 0 ? "most-used" : ""}" type="button" onclick="seleccionarServicioRapido('${p.id}')">
      ${idx === 0 ? `<span class="quick-tag">Más usado</span>` : ""}
      <span class="quick-icon">${iconoServicio(p)}</span>
      <strong>${p.nombre}</strong>
      <small>${precioVariableServicio(p) ? "Precio variable" : money(p.precio)}</small>
    </button>
  `).join("");
}

function renderHistorialReciente() {
  const cont = document.getElementById("historialRecienteImpresiones");
  if (!cont) return;

  const lista = impresiones.slice(0, 8);

  if (!lista.length) {
    cont.innerHTML = `<div class="muted">No hay impresiones registradas.</div>`;
    return;
  }

  cont.innerHTML = lista.map(i => {
    const credito = i.metodo_pago === "credito" || i.estado === "credito_pendiente";
    return `
      <div class="recent-print-row">
        <div>
          <strong>${i.servicio_nombre || "Servicio"}</strong>
          <small>${i.creado_en ? new Date(i.creado_en).toLocaleString("es-GT") : "-"}</small>
        </div>
        <div class="recent-print-total">
          <strong>${money(i.total)}</strong>
          <span class="badge ${credito ? "warning" : "ok"}">${credito ? "Crédito" : "Pagado"}</span>
        </div>
      </div>
    `;
  }).join("");
}

function renderServiciosTopHoy(hoyLista) {
  const cont = document.getElementById("serviciosTopHoy");
  if (!cont) return;

  const conteo = {};
  hoyLista.forEach(i => conteo[i.servicio_nombre] = (conteo[i.servicio_nombre] || 0) + 1);
  const lista = Object.entries(conteo).sort((a,b) => b[1] - a[1]).slice(0, 5);
  const max = lista[0]?.[1] || 1;

  if (!lista.length) {
    cont.innerHTML = `<div class="muted">Sin servicios registrados hoy.</div>`;
    return;
  }

  cont.innerHTML = lista.map(([nombre, cantidad], idx) => `
    <div class="service-top-row">
      <span>${idx + 1}. ${nombre}</span>
      <div class="service-top-bar"><i style="width:${Math.max(12, (cantidad / max) * 100)}%"></i></div>
      <strong>${cantidad}</strong>
    </div>
  `).join("");
}


async function cargarPrecios() {
  const { data, error } = await supabaseClient
    .from("precios_impresion")
    .select("*")
    .order("nombre", { ascending: true });

  if (error) {
    mostrar("Error cargando precios: " + error.message, "error");
    return;
  }

  precios = data || [];

  renderSelectServicios();
  renderPrecios();
  renderServiciosRapidos();
}

function renderPrecios() {
  const tbody = document.getElementById("preciosTabla");
  const q = (document.getElementById("buscarServicioCatalogo")?.value || "").toLowerCase().trim();

  const filtrados = precios.filter(p => {
    const texto = `${p.nombre || ""} ${p.tipo || ""} ${categoriaServicio(p)} ${etiquetaClaseServicio(p)}`.toLowerCase();
    return texto.includes(q);
  });

  if (!filtrados.length) {
    tbody.innerHTML = `<tr><td colspan="5">No hay impresiones o servicios registrados.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtrados.map(p => {
    const categoria = categoriaServicio(p);
    const ganancia = gananciaEstimadaServicio(p);
    const detallePrecio = precioVariableServicio(p)
      ? `<small class="muted">Precio variable al cobrar · Costo manual ${money(costoEstimadoServicio(p))}</small>`
      : `<small class="muted">Costo manual ${money(costoEstimadoServicio(p))}${perfil?.rol === "admin" ? ` · Utilidad ${money(ganancia)}` : ""}</small>`;
    return `
      <tr>
        <td>
          <div class="service-name-cell">
            <span>${iconoServicio(p)}</span>
            <div><strong>${p.nombre}</strong><small>${categoria}</small></div>
          </div>
        </td>
        <td><span class="service-category-pill ${claseServicio(p) === "servicio" ? "service-pill-tramite" : ""}">${etiquetaClaseServicio(p)}</span></td>
        <td><strong>${precioVariableServicio(p) ? "Variable" : money(p.precio)}</strong><br>${detallePrecio}</td>
        <td><span class="badge ${p.activo ? "ok" : "danger"}">${p.activo ? "Activo" : "Inactivo"}</span></td>
        <td class="actions">
          ${perfil?.rol === "admin"
            ? `<button class="btn btn-small" onclick="editarPrecio('${p.id}')">Editar</button><button class="btn btn-small ${p.activo ? "btn-outline" : "btn-secondary"}" onclick="toggleServicioActivo('${p.id}')">${p.activo ? "Desactivar" : "Reactivar"}</button>`
            : `<span class="muted">Solo admin</span>`}
        </td>
      </tr>
    `;
  }).join("");
}

function nuevoPrecio() {
  if (perfil?.rol !== "admin") return alert("Solo admin puede crear precios.");
  document.getElementById("precioForm").style.display = "grid";
  document.getElementById("precioForm").reset();
  document.getElementById("precioId").value = "";
  document.getElementById("precioActivo").checked = true;
  document.getElementById("precioClase").value = "impresion";
  document.getElementById("precioModo").value = "fijo";
}

window.editarPrecio = function(id) {
  if (perfil?.rol !== "admin") return alert("Solo admin puede modificar precios.");

  const p = precios.find(x => x.id === id);
  if (!p) return;

  document.getElementById("precioForm").style.display = "grid";
  document.getElementById("precioId").value = p.id;
  document.getElementById("precioNombre").value = p.nombre || "";
  document.getElementById("precioClase").value = claseServicio(p);
  document.getElementById("precioTipo").value = p.tipo || "";
  document.getElementById("precioCosto").value = costoEstimadoServicio(p);
  document.getElementById("precioValor").value = p.precio || 0;
  document.getElementById("precioModo").value = precioVariableServicio(p) ? "variable" : "fijo";
  document.getElementById("precioActivo").checked = !!p.activo;
};

window.toggleServicioActivo = async function(id) {
  if (perfil?.rol !== "admin") return alert("Solo admin puede activar o desactivar servicios.");
  const p = precios.find(x => x.id === id);
  if (!p) return;
  const nuevoEstado = !p.activo;
  const { error } = await supabaseClient
    .from("precios_impresion")
    .update({ activo: nuevoEstado, actualizado_en: new Date().toISOString() })
    .eq("id", id);
  if (error) return mostrar(error.message, "error");
  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "impresiones",
    accion: nuevoEstado ? "reactivar_servicio" : "desactivar_servicio",
    descripcion: `${p.nombre} · ${etiquetaClaseServicio(p)}`
  });
  await cargarPrecios();
};

async function guardarPrecio(e) {
  e.preventDefault();

  if (perfil?.rol !== "admin") return alert("Solo admin puede guardar precios.");

  const id = document.getElementById("precioId").value;
  const payload = {
    nombre: document.getElementById("precioNombre").value.trim(),
    clase: document.getElementById("precioClase").value || "impresion",
    tipo_item: document.getElementById("precioClase").value || "impresion",
    tipo: document.getElementById("precioTipo").value.trim() || (document.getElementById("precioClase").value === "servicio" ? "tramite" : "impresion"),
    costo: Number(document.getElementById("precioCosto").value || 0),
    costo_unitario: Number(document.getElementById("precioCosto").value || 0),
    precio: Number(document.getElementById("precioValor").value || 0),
    precio_variable: document.getElementById("precioModo").value === "variable",
    tipo_precio: document.getElementById("precioModo").value === "variable" ? "variable" : "fijo",
    activo: document.getElementById("precioActivo").checked,
    actualizado_en: new Date().toISOString()
  };

  if (!payload.nombre || payload.precio < 0) {
    mostrar("Nombre y precio válido son obligatorios.", "error");
    return;
  }

  const result = id
    ? await supabaseClient.from("precios_impresion").update(payload).eq("id", id)
    : await supabaseClient.from("precios_impresion").insert([payload]);

  if (result.error) {
    mostrar(result.error.message, "error");
    return;
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "impresiones",
    accion: id ? "editar_precio_impresion" : "crear_precio_impresion",
    descripcion: `${payload.nombre} · ${money(payload.precio)}`
  });

  ocultarPrecioForm();
  await cargarPrecios();
}

function ocultarPrecioForm() {
  document.getElementById("precioForm").style.display = "none";
}

function actualizarPrecio() {
  const id = document.getElementById("servicioId").value;
  const p = precios.find(x => x.id === id);
  const precioInput = document.getElementById("precioUnitario");
  const hint = document.getElementById("precioVariableHint");

  if (!p) {
    precioInput.value = "";
    precioInput.setAttribute("readonly", "readonly");
    if (hint) hint.style.display = "none";
    calcularTotal();
    return;
  }

  if (precioVariableServicio(p)) {
    precioInput.removeAttribute("readonly");
    precioInput.value = "";
    precioInput.placeholder = "Precio variable Q";
    if (hint) hint.style.display = "block";
    precioInput.focus();
  } else {
    precioInput.value = Number(p.precio || 0).toFixed(2);
    precioInput.setAttribute("readonly", "readonly");
    precioInput.placeholder = "Precio unitario Q";
    if (hint) hint.style.display = "none";
  }

  calcularTotal();
}

function calcularTotal() {
  const cantidad = Number(document.getElementById("cantidad").value || 0);
  const precio = Number(document.getElementById("precioUnitario").value || 0);
  document.getElementById("total").value = (cantidad * precio).toFixed(2);
  actualizarCambioImpresion();
}

function estadoCambioImpresion() {
  const total = Number(document.getElementById("total")?.value || 0);
  const metodoPago = document.getElementById("metodoPago")?.value || "contado";
  const recibido = Number(document.getElementById("recibidoImpresion")?.value || 0);
  const vuelto = Math.max(0, recibido - total);
  const faltante = Math.max(0, total - recibido);
  return { total, metodoPago, recibido, vuelto, faltante };
}

function actualizarCambioImpresion() {
  const bloque = document.getElementById("bloqueCambioImpresion");
  if (!bloque) return;
  const { total, metodoPago, recibido, vuelto, faltante } = estadoCambioImpresion();
  const aplica = metodoPago === "contado";
  bloque.style.display = aplica ? "block" : "none";

  const box = document.getElementById("vueltoImpresionBox");
  const monto = document.getElementById("vueltoImpresion");
  const texto = document.getElementById("vueltoImpresionTexto");
  if (!box || !monto || !texto) return;

  box.classList.remove("falta", "exacto");
  if (!aplica) return;

  if (total <= 0) {
    monto.textContent = money(0);
    texto.textContent = "Selecciona un servicio para calcular el vuelto.";
    return;
  }

  if (recibido <= 0) {
    monto.textContent = money(0);
    texto.textContent = "Escribe cuánto entregó el cliente para calcular el vuelto.";
    return;
  }

  if (faltante > 0) {
    box.classList.add("falta");
    monto.textContent = money(faltante);
    texto.textContent = `Faltan ${money(faltante)} para completar el pago.`;
    return;
  }

  if (vuelto === 0) {
    box.classList.add("exacto");
    monto.textContent = money(0);
    texto.textContent = "Pago exacto.";
    return;
  }

  monto.textContent = money(vuelto);
  texto.textContent = `Vuelto a entregar: ${money(vuelto)}.`;
}

function configurarBotonesCambioImpresion() {
  document.querySelectorAll('.soc-billetes-rapidos[data-target="recibidoImpresion"] button').forEach(btn => {
    btn.addEventListener("click", () => {
      const input = document.getElementById("recibidoImpresion");
      if (!input) return;
      input.value = Number(btn.dataset.monto || 0).toFixed(2);
      actualizarCambioImpresion();
    });
  });
}


function configurarCreditoImpresion() {
  const metodo = document.getElementById("metodoPago")?.value;
  const bloque = document.getElementById("bloqueCreditoImpresion");
  const btn = document.getElementById("btnRegistrarImpresion");

  if (bloque) bloque.style.display = metodo === "credito" ? "block" : "none";

  if (btn) {
    btn.textContent = metodo === "credito"
      ? "Registrar impresión a crédito"
      : "Cobrar y registrar en caja";
  }
  actualizarCambioImpresion();
}

async function crearCreditoImpresion({ impresionId, clienteId, total, nota }) {
  const payload = {
    cliente_id: clienteId,
    usuario_id: user.id,
    total,
    saldo: total,
    monto_total: total,
    monto_pendiente: total,
    estado: "pendiente",
    nota: nota || "Crédito generado desde módulo Impresiones"
  };

  const { data, error } = await supabaseClient
    .from("creditos")
    .insert([payload])
    .select()
    .single();

  if (error) {
    throw new Error("La impresión se registró, pero no se pudo crear el crédito: " + error.message);
  }

  // Si la tabla impresiones tiene columna credito_id, intentamos enlazarlo.
  await supabaseClient
    .from("impresiones")
    .update({ credito_id: data.id })
    .eq("id", impresionId);

  return data;
}


async function registrarImpresion(e) {
  e.preventDefault();

  const servicio = precios.find(p => p.id === document.getElementById("servicioId").value);
  if (!servicio) return mostrar("Selecciona un servicio.", "error");

  const clienteId = document.getElementById("clienteId").value || null;
  const cliente = clientes.find(c => c.id === clienteId);
  const cantidad = Number(document.getElementById("cantidad").value || 1);
  const precioUnitario = precioVariableServicio(servicio)
    ? Number(document.getElementById("precioUnitario").value || 0)
    : Number(servicio.precio || 0);
  const total = cantidad * precioUnitario;
  const metodoPago = document.getElementById("metodoPago").value;
  const notas = document.getElementById("notas").value.trim();
  const notaCredito = document.getElementById("notaCreditoImpresion")?.value.trim() || "";

  if (total <= 0) return mostrar("El total debe ser mayor a Q0.00.", "error");

  const recibidoImpresion = metodoPago === "contado" ? Number(document.getElementById("recibidoImpresion")?.value || 0) : 0;
  const vueltoImpresion = metodoPago === "contado" ? Math.max(0, recibidoImpresion - total) : 0;

  if (metodoPago === "contado" && recibidoImpresion > 0 && recibidoImpresion < total) {
    return mostrar(`Faltan ${money(total - recibidoImpresion)} para completar el pago.`, "error");
  }

  if (metodoPago === "credito" && !clienteId) {
    return mostrar("Para registrar una impresión a crédito debes seleccionar un cliente.", "error");
  }

  if (metodoPago !== "credito") {
    await cargarCaja();
    if (!cajaActual) return mostrar("Primero debes abrir caja para cobrar impresiones.", "error");
  }

  const { data: imp, error } = await supabaseClient
    .from("impresiones")
    .insert([{
      cliente_id: clienteId,
      usuario_id: user.id,
      caja_id: metodoPago === "credito" ? null : cajaActual.id,
      servicio_id: servicio.id,
      servicio_nombre: servicio.nombre,
      tipo_item: claseServicio(servicio),
      tipo_servicio: claseServicio(servicio),
      costo_unitario: costoEstimadoServicio(servicio),
      costo_total: costoEstimadoServicio(servicio) * cantidad,
      ganancia: total - (costoEstimadoServicio(servicio) * cantidad),
      precio_variable: precioVariableServicio(servicio),
      cantidad,
      precio_unitario: precioUnitario,
      total,
      metodo_pago: metodoPago,
      notas,
      estado: metodoPago === "credito" ? "credito_pendiente" : "pagado"
    }])
    .select()
    .single();

  if (error) return mostrar(error.message, "error");

  let creditoCreado = null;

  if (metodoPago === "credito") {
    try {
      creditoCreado = await crearCreditoImpresion({
        impresionId: imp.id,
        clienteId,
        total,
        nota: notaCredito || notas
      });
    } catch (err) {
      return mostrar(err.message, "error");
    }
  } else {
    const { error: cajaError } = await supabaseClient
      .from("movimientos_caja")
      .insert([{
        caja_id: cajaActual.id,
        usuario_id: user.id,
        tipo: "ingreso",
        categoria: claseServicio(servicio) === "servicio" ? "servicios_tramites" : "impresiones",
        descripcion: `${etiquetaClaseServicio(servicio)}: ${servicio.nombre}`,
        monto: total,
        referencia_id: imp.id
      }]);

    if (cajaError) return mostrar("Se guardó la impresión, pero falló caja: " + cajaError.message, "error");
  }

  const folioImp = folio("SO-I");

  const contenido = {
    cliente: cliente?.nombre || cliente?.nombre_completo || "Consumidor final",
    servicio: servicio.nombre,
    tipo_item: etiquetaClaseServicio(servicio),
    precio_variable: precioVariableServicio(servicio),
    cantidad,
    precio_unitario: precioUnitario,
    total,
    recibido: recibidoImpresion,
    vuelto: vueltoImpresion,
    metodo_pago: metodoPago,
    estado: metodoPago === "credito" ? "Crédito pendiente" : "Pagado",
    credito_id: creditoCreado?.id || null,
    notas,
    fecha: new Date().toISOString()
  };

  // Corrección v13: el recibo/documento ya no se ignora silenciosamente.
  // Si falla, mostramos el error para evitar ventas/impresiones sin historial en Documentos.
  const { data: documentoExistente } = await supabaseClient
    .from("documentos_generados")
    .select("id")
    .eq("referencia_id", imp.id)
    .eq("tipo", "recibo_impresion")
    .maybeSingle();

  let documentoGuardado = documentoExistente || null;

  if (!documentoGuardado) {
    const { data: docNuevo, error: docError } = await supabaseClient
      .from("documentos_generados")
      .insert([{
        tipo: "recibo_impresion",
        referencia_id: imp.id,
        cliente_id: clienteId,
        usuario_id: user.id,
        folio: folioImp,
        titulo: metodoPago === "credito" ? "Recibo de impresión/servicio a crédito" : "Recibo de impresión/servicio",
        contenido
      }])
      .select()
      .single();

    if (docError) {
      return mostrar("Se registró la impresión/servicio, pero no se pudo generar el documento: " + docError.message, "error");
    }

    documentoGuardado = docNuevo;
  }

  if (documentoGuardado) {
    const htmlInicial = htmlReciboImpresion({ folio: folioImp, ...contenido });
    const publicUrl = await subirComprobanteHTML({
      documentoId: documentoGuardado.id,
      tipo: "recibo_impresion",
      folio: folioImp,
      html: htmlInicial
    });

    if (publicUrl) {
      contenido.public_url = publicUrl;
      await supabaseClient
        .from("documentos_generados")
        .update({ contenido })
        .eq("id", documentoGuardado.id);
    }
  }

  await registrarAuditoria({
    usuario: user,
    perfil,
    modulo: "impresiones",
    accion: metodoPago === "credito" ? "registrar_impresion_credito" : "cobrar_impresion",
    descripcion: `${servicio.nombre} · ${money(total)} · ${metodoPago}`
  });

  mostrarRecibo({ folio: folioImp, ...contenido });
  mostrar(
    metodoPago === "credito"
      ? `Impresión registrada a crédito. Aparece en Créditos por ${money(total)}`
      : `Impresión cobrada y registrada en caja. Total: ${money(total)}`,
    "success"
  );

  e.target.reset();
  document.getElementById("precioUnitario").value = "";
  document.getElementById("precioUnitario").setAttribute("readonly", "readonly");
  document.getElementById("precioVariableHint") && (document.getElementById("precioVariableHint").style.display = "none");
  document.getElementById("total").value = "";
  document.getElementById("recibidoImpresion") && (document.getElementById("recibidoImpresion").value = "");
  configurarCreditoImpresion();
  actualizarCambioImpresion();

  await cargarImpresiones();
}

async function cargarImpresiones() {
  const { data } = await supabaseClient
    .from("impresiones")
    .select("*")
    .order("creado_en", { ascending: false })
    .limit(50);

  impresiones = data || [];
  renderImpresiones();
  resumen();
}

function resumen() {
  const hoy = new Date().toISOString().slice(0, 10);
  const hoyLista = impresiones.filter(i => String(i.creado_en).slice(0, 10) === hoy);
  const pagadas = hoyLista.filter(i => i.estado !== "credito_pendiente" && i.metodo_pago !== "credito");
  const creditos = hoyLista.filter(i => i.estado === "credito_pendiente" || i.metodo_pago === "credito");

  const total = pagadas.reduce((s, i) => s + Number(i.total || 0), 0);
  const totalCredito = creditos.reduce((s, i) => s + Number(i.total || 0), 0);
  const gananciaEstimada = pagadas.reduce((s, i) => s + Number(i.ganancia || 0), 0);

  document.getElementById("totalImpresiones").textContent = money(total);
  document.getElementById("trabajosHoy").textContent = hoyLista.length;
  document.getElementById("creditosImpresionHoy").textContent = money(totalCredito);
  document.getElementById("creditosImpresionCount").textContent = `${creditos.length} trabajos pendientes`;
  document.getElementById("gananciaImpresionEstimada").textContent = money(gananciaEstimada);

  const conteo = {};
  hoyLista.forEach(i => conteo[i.servicio_nombre] = (conteo[i.servicio_nombre] || 0) + 1);
  const top = Object.entries(conteo).sort((a, b) => b[1] - a[1])[0];

  document.getElementById("servicioTop") && (document.getElementById("servicioTop").textContent = top ? top[0] : "-");

  renderServiciosTopHoy(hoyLista);
  renderHistorialReciente();
}

function renderImpresiones() {
  const tbody = document.getElementById("impresionesTabla");

  if (!impresiones.length) {
    tbody.innerHTML = `<tr><td colspan="6">No hay cobros de impresiones.</td></tr>`;
    return;
  }

  tbody.innerHTML = impresiones.map(i => {
    const credito = i.metodo_pago === "credito" || i.estado === "credito_pendiente";
    return `
      <tr>
        <td>${new Date(i.creado_en).toLocaleString("es-GT")}</td>
        <td><strong>${i.servicio_nombre}</strong><br><small class="muted">${i.tipo_item === "servicio" || i.tipo_servicio === "servicio" ? "Servicio / Trámite" : "Impresión"}</small></td>
        <td>${i.cantidad}</td>
        <td><strong>${money(i.total)}</strong></td>
        <td><span class="badge ${credito ? "warning" : "ok"}">${credito ? "Crédito pendiente" : "Pagado"}</span></td>
        <td><button class="btn btn-small" onclick="reimprimirImpresion('${i.id}')">Buscar recibo</button></td>
      </tr>
    `;
  }).join("");
}

window.reimprimirImpresion = async function(id) {
  const { data, error } = await supabaseClient
    .from("documentos_generados")
    .select("*")
    .eq("referencia_id", id)
    .eq("tipo", "recibo_impresion")
    .order("creado_en", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error || !data) return alert("No se encontró recibo para este cobro.");

  const doc = { folio: data.folio, ...(data.contenido || {}) };
  ultimoReciboData = doc;
  ultimoReciboData = doc;
  ultimoReciboHTML = htmlReciboImpresion(doc);
  abrirPDFDesdeHTML("Recibo de impresión", ultimoReciboHTML);
};

function mostrarRecibo(doc) {
  const panel = document.getElementById("reciboPanel");
  const preview = document.getElementById("reciboImpresion");

  panel.style.display = "block";
  ultimoReciboData = doc;
  ultimoReciboHTML = htmlReciboImpresion(doc);
  preview.innerHTML = ultimoReciboHTML;
  panel.scrollIntoView({ behavior: "smooth" });
}


function imprimirTicketTermicoImpresion(doc = {}) {
  const configTicket = getTicketConfig();
  const total = Number(doc.total || 0);
  const cantidad = Number(doc.cantidad || 1);
  const precio = Number(doc.precio_unitario || doc.precio || (cantidad ? total / cantidad : total) || 0);
  const fecha = doc.fecha ? new Date(doc.fecha).toLocaleString("es-GT") : new Date().toLocaleString("es-GT");
  const html = `
    <div class="thermal-ticket ticket-premium">
      ${ticketHeaderHtml(configTicket)}
      <div class="tt-line"></div>
      <div class="tt-row"><span>Folio:</span><strong>${doc.folio || "-"}</strong></div>
      <div class="tt-row"><span>Fecha:</span><span>${fecha}</span></div>
      ${configTicket.mostrarCliente ? `<div class="tt-row"><span>Cliente:</span><strong>${doc.cliente || doc.cliente_nombre || "Consumidor Final"}</strong></div>` : ""}
      <div class="tt-line"></div>
      <div class="tt-head-row"><span>CANT.</span><span>DESCRIPCIÓN</span><span>TOTAL</span></div>
      <div class="tt-item tt-product-row">
        <div class="tt-qty">${cantidad}</div>
        <div class="tt-product-name"><strong>${doc.servicio_nombre || doc.servicio || doc.nombre || "Servicio"}</strong></div>
        <div class="tt-product-total"><strong>Q ${total.toFixed(2)}</strong></div>
      </div>
      <div class="tt-line"></div>
      <div class="tt-row"><span>Subtotal:</span><strong>Q ${total.toFixed(2)}</strong></div>
      <div class="tt-row tt-total"><span>TOTAL:</span><strong>Q ${total.toFixed(2)}</strong></div>
      <div class="tt-line"></div>
      <div class="tt-row"><span>Forma de pago:</span><strong>${String(doc.metodo_pago || doc.tipo_pago || "-").toUpperCase()}</strong></div>
      ${Number(doc.recibido || 0) ? `<div class="tt-row"><span>Recibido:</span><strong>Q ${Number(doc.recibido || 0).toFixed(2)}</strong></div>` : ""}
      ${Number(doc.vuelto || 0) ? `<div class="tt-row"><span>Vuelto:</span><strong>Q ${Number(doc.vuelto || 0).toFixed(2)}</strong></div>` : ""}
      ${doc.saldo ? `<div class="tt-balance"><span>Saldo pendiente:</span><strong>Q ${Number(doc.saldo || 0).toFixed(2)}</strong></div>` : ""}
      <div class="tt-line"></div>
      ${ticketFooterHtml(configTicket)}
    </div>
  `;
  const w = window.open("", "_blank", "width=420,height=720");
  w.document.write(`
    <html><head><title>Ticket térmico</title><style>${ticketPrintStyles()}</style></head><body>${html}<script>setTimeout(()=>window.print(),250)</script></body></html>
  `);
  w.document.close();
  w.focus();
}

function mostrar(txt, tipo) {
  const el = document.getElementById("impresionMsg");
  el.textContent = txt;
  el.className = `message ${tipo}`;
}

instalarNavegacionPremium();
init();
