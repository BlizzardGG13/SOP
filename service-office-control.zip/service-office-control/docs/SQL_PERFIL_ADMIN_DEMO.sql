-- Ejecutar en Supabase DEMO después de crear el usuario en Authentication.
-- Cambia UUID_DE_AUTH y CORREO_DEMO por los datos reales.

-- 1) Ver el UUID real del usuario:
select id, email
from auth.users
where email = 'CORREO_DEMO';

-- 2) Crear o corregir perfil en usuarios_perfiles:
insert into public.usuarios_perfiles (
  id,
  nombre,
  email,
  correo,
  rol,
  activo,
  creado_en,
  actualizado_en
)
values (
  'UUID_DE_AUTH',
  'Administrador Demo',
  'CORREO_DEMO',
  'CORREO_DEMO',
  'admin',
  true,
  now(),
  now()
)
on conflict (id) do update set
  nombre = excluded.nombre,
  email = excluded.email,
  correo = excluded.correo,
  rol = excluded.rol,
  activo = excluded.activo,
  actualizado_en = now();

-- 3) Crear o corregir respaldo en perfiles:
insert into public.perfiles (
  id,
  nombre,
  email,
  rol,
  role,
  activo,
  creado_en,
  actualizado_en
)
values (
  'UUID_DE_AUTH',
  'Administrador Demo',
  'CORREO_DEMO',
  'admin',
  'admin',
  true,
  now(),
  now()
)
on conflict (id) do update set
  nombre = excluded.nombre,
  email = excluded.email,
  rol = excluded.rol,
  role = excluded.role,
  activo = excluded.activo,
  actualizado_en = now();
