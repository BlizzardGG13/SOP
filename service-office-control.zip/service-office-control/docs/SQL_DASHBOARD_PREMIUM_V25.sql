-- SERVICE OFFICE CONTROL - DASHBOARD PREMIUM V25
-- Ejecutar una sola vez en Supabase antes de probar ventas/ganancias.

alter table public.detalle_ventas
add column if not exists costo_unitario numeric default 0,
add column if not exists ganancia_unitaria numeric default 0,
add column if not exists ganancia_total numeric default 0;

alter table public.ventas
add column if not exists ganancia_total numeric default 0;

-- Recomendado: permitir nombre_producto vacío solo si alguna venta antigua quedó incompleta.
-- En la versión corregida ya se manda nombre_producto desde el código.
alter table public.detalle_ventas
alter column nombre_producto drop not null;
